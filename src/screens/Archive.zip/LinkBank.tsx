import React, { useCallback, useEffect, useMemo, useState } from "react";
import {
  View,
  Text,
  Alert,
  StyleSheet,
  TouchableOpacity,
  ActivityIndicator,
  ScrollView,
} from "react-native";
import {
  create,
  open,
  LinkSuccess,
  LinkExit,
} from "react-native-plaid-link-sdk";
import { supabase } from "../supabase";

const GREEN = "#77B777";
const BLUE = "#3B82F6";
const ORANGE = "#F59E0B";
const RED = "#D9534F";
const BG = "#F5F7F9";
const GREEN_DARK = "#5F9F5F";

type BankLinkState = {
  linked: boolean;
  providerLabel: string | null;
  accountMask: string | null;
  achStatus: string | null;
};

type ProfileReadResult = {
  linked: boolean;
  providerLabel: string | null;
  accountMask: string | null;
  achStatus: string | null;
};

type ExchangeAccount = {
  plaid_account_id: string;
  account_name: string | null;
  official_name: string | null;
  mask: string | null;
  type: string | null;
  subtype: string | null;
  verification_status: string | null;
  is_active: boolean;
};

export default function LinkBank({ route, navigation }: any) {
  const returnTo = route?.params?.returnTo ?? null;
  const paymentId = route?.params?.paymentId ?? null;
  const iouId =
    route?.params?.iouId ??
    route?.params?.iou_id ??
    route?.params?.loanId ??
    route?.params?.loan_id ??
    null;

  const [loading, setLoading] = useState(true);
  const [linking, setLinking] = useState(false);
  const [removing, setRemoving] = useState(false);
  const [state, setState] = useState<BankLinkState>({
    linked: false,
    providerLabel: null,
    accountMask: null,
    achStatus: null,
  });

  const getCurrentUserId = useCallback(async () => {
    const { data: auth } = await supabase.auth.getUser();
    const me = auth.user?.id;
    if (!me) throw new Error("No signed-in user.");
    return me;
  }, []);

  const getAccessToken = useCallback(async () => {
    const { data, error } = await supabase.auth.getSession();
    if (error) throw new Error(error.message);
    const accessToken = data.session?.access_token;
    if (!accessToken) throw new Error("No active session token.");
    return accessToken;
  }, []);

  const readProfileBankState = useCallback(async (userId: string) => {
    const selectAttempts = [
      "bank_linked, plaid_linked, bank_provider, bank_account_mask, plaid_institution_name, account_mask, ach_status",
      "bank_linked, plaid_linked, bank_provider, bank_account_mask, plaid_institution_name, account_mask",
      "plaid_linked, plaid_institution_name, account_mask",
      "bank_linked, bank_provider, bank_account_mask",
    ];

    for (const sel of selectAttempts) {
      const { data, error } = await supabase
        .from("profiles")
        .select(sel)
        .eq("id", userId)
        .single();

      if (!error && data) {
        const raw = data as any;

        const linked = !!(raw.bank_linked ?? raw.plaid_linked);
        const providerLabel =
          raw.bank_provider ?? raw.plaid_institution_name ?? null;
        const accountMask = raw.bank_account_mask ?? raw.account_mask ?? null;
        const achStatus =
          typeof raw.ach_status === "string"
            ? raw.ach_status
            : linked
              ? "ready"
              : null;

        const result: ProfileReadResult = {
          linked,
          providerLabel,
          accountMask,
          achStatus,
        };

        return result;
      }
    }

    return {
      linked: false,
      providerLabel: null,
      accountMask: null,
      achStatus: null,
    } as ProfileReadResult;
  }, []);

  const loadBankState = useCallback(async () => {
    setLoading(true);

    try {
      const me = await getCurrentUserId();
      const nextState = await readProfileBankState(me);
      setState(nextState);
    } catch (e: any) {
      Alert.alert("Load failed", e?.message ?? "Could not load bank status.");
    } finally {
      setLoading(false);
    }
  }, [getCurrentUserId, readProfileBankState]);

  useEffect(() => {
    void loadBankState();
  }, [loadBankState]);

  const connectionLabel = useMemo(() => {
    if (!state.linked) return "No bank connected";
    const provider = state.providerLabel || "Connected Bank";
    const mask = state.accountMask ? ` •••• ${state.accountMask}` : "";
    return `${provider}${mask}`;
  }, [state]);

  const statusTone = useMemo(() => {
    if (state.linked) {
      return {
        bg: "#EAF8EA",
        border: "#D8EFD8",
        title: GREEN,
        text: "#2F4F2F",
      };
    }

    return {
      bg: "#FFF7ED",
      border: "#FED7AA",
      title: ORANGE,
      text: "#7C2D12",
    };
  }, [state.linked]);

  const readinessChecks = useMemo(() => {
    return [
      { label: "Signed-in user found", pass: true },
      { label: "Bank provider linked", pass: state.linked },
      {
        label: "ACH handoff ready",
        pass: state.linked && state.achStatus !== "blocked",
      },
    ];
  }, [state]);

  const readyCount = readinessChecks.filter((x) => x.pass).length;

  const saveLinkedBankToProfile = useCallback(
    async (
      providerLabel: string | null,
      accountMask: string | null,
      selectedPlaidAccountId: string | null
    ) => {
      const me = await getCurrentUserId();

      const safeProvider = providerLabel || "Connected Bank";
      const safeMask = accountMask || "0000";

      const updateAttempts = [
        {
          bank_linked: true,
          plaid_linked: true,
          bank_provider: safeProvider,
          bank_account_mask: safeMask,
          ach_status: "ready",
          plaid_institution_name: safeProvider,
          plaid_account_id: selectedPlaidAccountId,
          account_mask: safeMask,
          bank_name: safeProvider,
        },
        {
          bank_linked: true,
          plaid_linked: true,
          bank_provider: safeProvider,
          bank_account_mask: safeMask,
          plaid_institution_name: safeProvider,
          plaid_account_id: selectedPlaidAccountId,
          account_mask: safeMask,
          bank_name: safeProvider,
        },
        {
          plaid_linked: true,
          plaid_institution_name: safeProvider,
          plaid_account_id: selectedPlaidAccountId,
          account_mask: safeMask,
          ach_status: "ready",
        },
        {
          plaid_linked: true,
          plaid_institution_name: safeProvider,
          plaid_account_id: selectedPlaidAccountId,
          account_mask: safeMask,
        },
        {
          bank_linked: true,
          bank_provider: safeProvider,
          bank_account_mask: safeMask,
        },
      ];

      let success = false;
      let lastError: any = null;

      for (const payload of updateAttempts) {
        const { error } = await supabase
          .from("profiles")
          .update(payload)
          .eq("id", me);

        if (!error) {
          success = true;
          break;
        }

        lastError = error;
      }

      if (!success) {
        throw lastError ?? new Error("Could not save linked bank.");
      }
    },
    [getCurrentUserId]
  );

  const upsertBankAccounts = useCallback(
    async (
      accounts: ExchangeAccount[],
      institutionName: string | null,
      plaidItemId: string
    ) => {
      const me = await getCurrentUserId();

      if (!accounts.length) return;

      const rows = accounts.map((acct) => ({
        user_id: me,
        plaid_item_id: plaidItemId,
        plaid_account_id: acct.plaid_account_id,
        account_name: acct.account_name,
        official_name: acct.official_name,
        mask: acct.mask,
        type: acct.type,
        subtype: acct.subtype,
        verification_status: acct.verification_status,
        is_active: acct.is_active !== false,
        institution_name: institutionName,
        updated_at: new Date().toISOString(),
      }));

      const { error } = await supabase
        .from("bank_accounts")
        .upsert(rows, { onConflict: "plaid_account_id" });

      if (error) {
        throw new Error(error.message);
      }
    },
    [getCurrentUserId]
  );

  const setDefaultPaymentAccount = useCallback(
    async (account: ExchangeAccount, institutionName: string | null) => {
      const me = await getCurrentUserId();

      const { error: clearError } = await supabase
        .from("bank_accounts")
        .update({
          is_default_payment: false,
          updated_at: new Date().toISOString(),
        })
        .eq("user_id", me);

      if (clearError) {
        throw new Error(clearError.message);
      }

      const { error: setError } = await supabase
        .from("bank_accounts")
        .update({
          is_default_payment: true,
          updated_at: new Date().toISOString(),
        })
        .eq("user_id", me)
        .eq("plaid_account_id", account.plaid_account_id);

      if (setError) {
        throw new Error(setError.message);
      }

      await saveLinkedBankToProfile(
        institutionName,
        account.mask ?? "0000",
        account.plaid_account_id
      );
    },
    [getCurrentUserId, saveLinkedBankToProfile]
  );

  const attachDwollaFundingSource = useCallback(
    async (plaidAccountId: string) => {
      const { data, error } = await supabase.functions.invoke(
        "dwolla-attach-funding-source",
        {
          body: {
            plaid_account_id: plaidAccountId,
          },
        }
      );

      if (error) {
        throw new Error(
          error.message || "Failed to attach Dwolla funding source."
        );
      }

      if (!data?.ok) {
        throw new Error(
          data?.error || "Dwolla funding source could not be attached."
        );
      }

      return data;
    },
    []
  );

  const clearLinkedBankFromProfile = useCallback(async () => {
    const me = await getCurrentUserId();

    const resetAttempts = [
      {
        bank_linked: false,
        plaid_linked: false,
        bank_provider: null,
        bank_account_mask: null,
        ach_status: null,
        plaid_institution_name: null,
        plaid_account_id: null,
        account_mask: null,
        bank_name: null,
      },
      {
        bank_linked: false,
        plaid_linked: false,
        bank_provider: null,
        bank_account_mask: null,
        plaid_institution_name: null,
        plaid_account_id: null,
        account_mask: null,
        bank_name: null,
      },
      {
        plaid_linked: false,
        plaid_institution_name: null,
        plaid_account_id: null,
        account_mask: null,
        ach_status: null,
      },
      {
        plaid_linked: false,
        plaid_institution_name: null,
        plaid_account_id: null,
        account_mask: null,
      },
      {
        bank_linked: false,
        bank_provider: null,
        bank_account_mask: null,
      },
    ];

    let success = false;
    let lastError: any = null;

    for (const payload of resetAttempts) {
      const { error } = await supabase
        .from("profiles")
        .update(payload)
        .eq("id", me);

      if (!error) {
        success = true;
        break;
      }

      lastError = error;
    }

    if (!success) {
      throw lastError ?? new Error("Could not remove linked bank.");
    }
  }, [getCurrentUserId]);

  const goNext = useCallback(() => {
    if (returnTo === "ConfirmPayment") {
      navigation.navigate("ConfirmPayment", {
        paymentId,
        iouId,
        iou_id: iouId,
        loanId: iouId,
        loan_id: iouId,
      });
      return;
    }

    if (iouId) {
      navigation.navigate("LoanDetail", {
        iouId,
        iou_id: iouId,
      });
      return;
    }

    if (navigation.canGoBack()) {
      navigation.goBack();
      return;
    }

    navigation.replace("Home");
  }, [navigation, returnTo, paymentId, iouId]);

  const handlePlaidSuccess = useCallback(
    async (success: LinkSuccess) => {
      try {
        const institutionName =
          success?.metadata?.institution?.name ?? "Plaid Connected Bank";

        const accessToken = await getAccessToken();
        const me = await getCurrentUserId();

        const { data: exchangeDataRaw, error: exchangeError } =
          await supabase.functions.invoke("exchange-token", {
            body: {
              public_token: success.publicToken,
              institution_name: institutionName,
              user_id: me,
              metadata_accounts: success?.metadata?.accounts ?? [],
            },
            headers: {
              Authorization: `Bearer ${accessToken}`,
            },
          });

        let exchangeData: any = exchangeDataRaw;

        if (typeof exchangeDataRaw === "string") {
          try {
            exchangeData = JSON.parse(exchangeDataRaw);
          } catch {
            exchangeData = exchangeDataRaw;
          }
        }

        if (exchangeError) {
          const errorAny = exchangeError as any;
          const response = errorAny?.context;

          let body: any = null;

          try {
            if (response && typeof response.text === "function") {
              const text = await response.text();

              try {
                body = JSON.parse(text);
              } catch {
                body = text;
              }
            }
          } catch (e: any) {
            body = {
              failed_to_read: true,
              message: e?.message ?? "unknown",
            };
          }

          Alert.alert(
            "🚨 BACKEND ERROR",
            JSON.stringify(
              {
                stage: body?.stage ?? null,
                error: body?.error ?? null,
                details: body?.details ?? null,
                debug: body?.debug ?? null,
                status: response?.status ?? null,
              },
              null,
              2
            )
          );

          throw new Error(
            body?.details?.message ||
              body?.details ||
              body?.error ||
              errorAny?.message ||
              "Exchange failed"
          );
        }

        const plaidItemId =
          exchangeData?.item_id ??
          exchangeData?.data?.item_id ??
          exchangeData?.itemId ??
          exchangeData?.data?.itemId ??
          null;

        if (!plaidItemId) {
          throw new Error("Failed to retrieve item_id from backend.");
        }

        const accounts: ExchangeAccount[] = Array.isArray(exchangeData?.accounts)
          ? exchangeData.accounts
          : Array.isArray(exchangeData?.data?.accounts)
            ? exchangeData.data.accounts
            : [];

        await upsertBankAccounts(accounts, institutionName, plaidItemId);

        const eligibleAccounts = accounts.filter(
          (acct) =>
            acct.is_active !== false &&
            acct.type === "depository" &&
            (acct.subtype === "checking" ||
              acct.subtype === "savings" ||
              acct.subtype == null)
        );

        const checkingAccounts = eligibleAccounts.filter(
          (acct) => acct.subtype === "checking"
        );

        if (checkingAccounts.length === 1 && eligibleAccounts.length === 1) {
          const account = checkingAccounts[0];

          await setDefaultPaymentAccount(account, institutionName);
          await attachDwollaFundingSource(account.plaid_account_id);
          await loadBankState();

          Alert.alert(
            "Bank linked",
            "Your bank was linked and is now ready for payments.",
            [
              {
                text: "OK",
                onPress: () => goNext(),
              },
            ]
          );
          return;
        }

        if (eligibleAccounts.length > 1) {
          await saveLinkedBankToProfile(
            institutionName,
            eligibleAccounts[0]?.mask ?? "0000",
            null
          );

          navigation.navigate("SelectBankAccount", {
            accounts: eligibleAccounts,
            institutionName,
            plaidItemId,
            returnTo,
            paymentId,
            iouId,
            iou_id: iouId,
            loanId: iouId,
            loan_id: iouId,
          });
          return;
        }

        if (accounts.length === 1) {
          const account = accounts[0];

          await setDefaultPaymentAccount(account, institutionName);
          await attachDwollaFundingSource(account.plaid_account_id);
          await loadBankState();

          Alert.alert(
            "Bank linked",
            "Your bank is now connected and ready for payments.",
            [
              {
                text: "OK",
                onPress: () => goNext(),
              },
            ]
          );
          return;
        }

        await saveLinkedBankToProfile(institutionName, "0000", null);
        await loadBankState();

        Alert.alert(
          "Bank linked",
          accounts.length > 0
            ? `Your bank was linked. ${accounts.length} account(s) were returned.`
            : "Plaid connected, but no eligible accounts were returned.",
          [
            {
              text: "OK",
              onPress: () => goNext(),
            },
          ]
        );
      } catch (e: any) {
        Alert.alert(
          "Save failed",
          e?.message ?? "Plaid connected, but the bank could not be saved."
        );
      } finally {
        setLinking(false);
      }
    },
    [
      attachDwollaFundingSource,
      getAccessToken,
      getCurrentUserId,
      goNext,
      iouId,
      loadBankState,
      navigation,
      paymentId,
      returnTo,
      saveLinkedBankToProfile,
      setDefaultPaymentAccount,
      upsertBankAccounts,
    ]
  );

  const handlePlaidExit = useCallback((exit: LinkExit) => {
    const exitMessage =
      exit?.error?.displayMessage || exit?.error?.errorMessage || null;

    if (exitMessage) {
      Alert.alert("Plaid closed", exitMessage);
    }

    setLinking(false);
  }, []);

  const handleOpenPlaid = useCallback(async () => {
    try {
      setLinking(true);

      const me = await getCurrentUserId();

      const { data, error } = await supabase.functions.invoke("rapid-worker", {
        body: {
          client_user_id: me,
        },
      });

      if (error) {
        throw new Error(error.message || "Could not create link token.");
      }

      if (!data?.link_token) {
        throw new Error("No link token returned.");
      }

      create({ token: data.link_token });

      open({
        onSuccess: handlePlaidSuccess,
        onExit: handlePlaidExit,
      });
    } catch (e: any) {
      setLinking(false);
      Alert.alert("Link failed", e?.message ?? "Could not open Plaid.");
    }
  }, [getCurrentUserId, handlePlaidExit, handlePlaidSuccess]);

  const handleRemoveBank = async () => {
    Alert.alert(
      "Remove linked bank?",
      "This will clear the current bank connection and send this flow back to the unlinked state.",
      [
        { text: "Cancel", style: "cancel" },
        {
          text: "Remove",
          style: "destructive",
          onPress: async () => {
            try {
              setRemoving(true);

              const me = await getCurrentUserId();

              const { error: bankAccountsError } = await supabase
                .from("bank_accounts")
                .delete()
                .eq("user_id", me);

              if (bankAccountsError) {
                throw new Error(bankAccountsError.message);
              }

              await clearLinkedBankFromProfile();
              await loadBankState();

              Alert.alert("Bank removed", "The linked bank has been cleared.");
            } catch (e: any) {
              Alert.alert(
                "Remove failed",
                e?.message ?? "Could not remove linked bank."
              );
            } finally {
              setRemoving(false);
            }
          },
        },
      ]
    );
  };

  const handleContinue = () => {
    goNext();
  };

  return (
    <ScrollView
      style={s.screen}
      contentContainerStyle={s.content}
      showsVerticalScrollIndicator={false}
    >
      <View style={s.card}>
        <Text style={s.eyebrow}>Phase 4</Text>
        <Text style={s.title}>Link bank</Text>
        <Text style={s.subtitle}>
          This is the first real bridge into bank-linked payments.
        </Text>

        {loading ? (
          <View style={s.loadingWrap}>
            <ActivityIndicator />
            <Text style={s.loadingText}>Loading bank connection…</Text>
          </View>
        ) : (
          <>
            <View
              style={[
                s.statusCard,
                {
                  backgroundColor: statusTone.bg,
                  borderColor: statusTone.border,
                },
              ]}
            >
              <Text style={[s.statusCardTitle, { color: statusTone.title }]}>
                Connection status
              </Text>
              <Text style={s.statusPrimary}>{connectionLabel}</Text>
              <Text style={[s.statusSecondary, { color: statusTone.text }]}>
                {state.linked
                  ? "This account can now flow into ConfirmPayment."
                  : "No active bank link found yet. Connect one to continue."}
              </Text>
            </View>

            <View style={s.readinessCard}>
              <Text style={s.readinessTitle}>Phase 4 readiness</Text>
              <Text style={s.readinessSubtitle}>
                {readyCount} / {readinessChecks.length} checks ready
              </Text>

              <View style={s.checklistWrap}>
                {readinessChecks.map((item) => (
                  <View key={item.label} style={s.checkRow}>
                    <Text
                      style={[
                        s.checkIcon,
                        item.pass ? s.goodText : s.pendingText,
                      ]}
                    >
                      {item.pass ? "✓" : "•"}
                    </Text>
                    <Text style={s.checkText}>{item.label}</Text>
                  </View>
                ))}
              </View>
            </View>

            <View style={s.infoCard}>
              <Text style={s.infoTitle}>What this screen does now</Text>
              <Text style={s.infoText}>
                This now opens Plaid Link and prepares the connected accounts for
                payment account selection.
              </Text>
            </View>

            <View style={s.infoCard}>
              <Text style={s.infoTitle}>Next live hookup</Text>
              <Text style={s.infoText}>
                Plaid Link → public token → backend exchange → account sync →
                default payment account → payment rail.
              </Text>
            </View>

            {!state.linked ? (
              <TouchableOpacity
                style={[s.primaryBtn, linking && s.btnDisabled]}
                onPress={handleOpenPlaid}
                disabled={linking || removing}
                activeOpacity={0.9}
              >
                {linking ? (
                  <ActivityIndicator color="#fff" />
                ) : (
                  <Text style={s.primaryBtnText}>Connect bank with Plaid</Text>
                )}
              </TouchableOpacity>
            ) : (
              <>
                <TouchableOpacity
                  style={[s.primaryBtn, linking && s.btnDisabled]}
                  onPress={handleOpenPlaid}
                  disabled={linking || removing}
                  activeOpacity={0.9}
                >
                  {linking ? (
                    <ActivityIndicator color="#fff" />
                  ) : (
                    <Text style={s.primaryBtnText}>Replace bank</Text>
                  )}
                </TouchableOpacity>

                <TouchableOpacity
                  style={[s.removeBtn, removing && s.btnDisabled]}
                  onPress={handleRemoveBank}
                  disabled={removing || linking}
                  activeOpacity={0.9}
                >
                  {removing ? (
                    <ActivityIndicator color="#fff" />
                  ) : (
                    <Text style={s.removeBtnText}>Remove bank</Text>
                  )}
                </TouchableOpacity>
              </>
            )}

            <TouchableOpacity
              style={[
                s.secondaryBtn,
                !state.linked && s.secondaryBtnDisabled,
              ]}
              onPress={handleContinue}
              activeOpacity={0.9}
            >
              <Text
                style={[
                  s.secondaryBtnText,
                  !state.linked && s.secondaryBtnTextDisabled,
                ]}
              >
                {state.linked ? "Continue" : "Back"}
              </Text>
            </TouchableOpacity>
          </>
        )}
      </View>
    </ScrollView>
  );
}

const s = StyleSheet.create({
  screen: {
    flex: 1,
    backgroundColor: BG,
  },

  content: {
    padding: 16,
    flexGrow: 1,
    justifyContent: "center",
  },

  card: {
    backgroundColor: "#fff",
    borderRadius: 18,
    padding: 18,
    borderWidth: 1,
    borderColor: "#EAEAEA",
  },

  eyebrow: {
    fontSize: 12,
    fontWeight: "800",
    textTransform: "uppercase",
    color: GREEN,
    letterSpacing: 0.5,
    marginBottom: 8,
  },

  title: {
    fontSize: 28,
    fontWeight: "800",
    color: "#111",
  },

  subtitle: {
    marginTop: 8,
    color: "#666",
    lineHeight: 21,
  },

  loadingWrap: {
    marginTop: 18,
    alignItems: "center",
    justifyContent: "center",
    paddingVertical: 20,
  },

  loadingText: {
    marginTop: 10,
    color: "#666",
  },

  statusCard: {
    marginTop: 18,
    borderWidth: 1,
    borderRadius: 14,
    padding: 14,
  },

  statusCardTitle: {
    fontSize: 12,
    fontWeight: "800",
    textTransform: "uppercase",
    marginBottom: 8,
  },

  statusPrimary: {
    fontSize: 18,
    fontWeight: "800",
    color: "#111",
  },

  statusSecondary: {
    marginTop: 6,
    lineHeight: 20,
    fontSize: 14,
  },

  readinessCard: {
    marginTop: 18,
    backgroundColor: "#F6F8FA",
    borderWidth: 1,
    borderColor: "#E8EBEF",
    borderRadius: 14,
    padding: 14,
  },

  readinessTitle: {
    color: "#111",
    fontWeight: "800",
    fontSize: 14,
    marginBottom: 4,
  },

  readinessSubtitle: {
    color: GREEN_DARK,
    fontWeight: "800",
    fontSize: 13,
    marginBottom: 10,
  },

  checklistWrap: {
    gap: 10,
  },

  checkRow: {
    flexDirection: "row",
    alignItems: "center",
  },

  checkIcon: {
    width: 20,
    fontSize: 16,
    fontWeight: "900",
  },

  checkText: {
    color: "#333",
    fontSize: 14,
    fontWeight: "700",
  },

  infoCard: {
    marginTop: 18,
    backgroundColor: "#F8FBFF",
    borderWidth: 1,
    borderColor: "#D9E7FF",
    borderRadius: 14,
    padding: 14,
  },

  infoTitle: {
    color: BLUE,
    fontWeight: "800",
    fontSize: 12,
    textTransform: "uppercase",
    marginBottom: 6,
  },

  infoText: {
    color: "#4D4D4D",
    lineHeight: 20,
    fontSize: 14,
  },

  primaryBtn: {
    marginTop: 20,
    height: 54,
    borderRadius: 14,
    backgroundColor: BLUE,
    alignItems: "center",
    justifyContent: "center",
  },

  removeBtn: {
    marginTop: 10,
    height: 54,
    borderRadius: 14,
    backgroundColor: RED,
    alignItems: "center",
    justifyContent: "center",
  },

  btnDisabled: {
    opacity: 0.7,
  },

  primaryBtnText: {
    color: "#fff",
    fontSize: 17,
    fontWeight: "800",
  },

  removeBtnText: {
    color: "#fff",
    fontSize: 17,
    fontWeight: "800",
  },

  secondaryBtn: {
    marginTop: 10,
    height: 50,
    borderRadius: 14,
    backgroundColor: "#EEF2F5",
    alignItems: "center",
    justifyContent: "center",
  },

  secondaryBtnDisabled: {
    backgroundColor: "#F3F4F6",
  },

  secondaryBtnText: {
    color: "#222",
    fontSize: 16,
    fontWeight: "700",
  },

  secondaryBtnTextDisabled: {
    color: "#667085",
  },

  goodText: {
    color: "#16A34A",
  },

  pendingText: {
    color: "#B45309",
  },
});