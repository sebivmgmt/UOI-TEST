// src/screens/Profile.tsx
import React, { useEffect, useState, useCallback, useMemo } from "react";
import {
  View,
  Text,
  TextInput,
  StyleSheet,
  TouchableOpacity,
  ActivityIndicator,
  Alert,
  ScrollView,
} from "react-native";
import { supabase } from "../supabase";

const GREEN = "#77B777";
const GREEN_DARK = "#5F9F5F";
const RED = "#D9534F";
const BLUE = "#3B82F6";
const BG = "#F5F7F9";
const AMBER = "#B7791F";

type ProfileRow = {
  id: string;
  full_name: string | null;
  email: string | null;
  phone: string | null;
  phone_verified: boolean | null;
  iou_score?: number | null;
  active_exposure_points?: number | null;
  score_last_updated_at?: string | null;

  identity_status?: string | null;
  identity_verified_at?: string | null;
  dwolla_customer_id?: string | null;
  dwolla_customer_status?: string | null;
};

type ScoreEventRow = {
  id: string;
  event_type: string;
  delta: number;
  description: string | null;
  created_at: string;
};

export default function Profile({ navigation }: any) {
  const [meId, setMeId] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [row, setRow] = useState<ProfileRow | null>(null);
  const [fullName, setFullName] = useState<string>("");
  const [scoreEvents, setScoreEvents] = useState<ScoreEventRow[]>([]);

  const load = useCallback(async () => {
    setLoading(true);
    const me = (await supabase.auth.getUser()).data.user;
    setMeId(me?.id ?? null);

    if (!me?.id) {
      setLoading(false);
      return;
    }

    const withScoreAndIdentitySelect =
      "id, full_name, email, phone, phone_verified, iou_score, active_exposure_points, score_last_updated_at, identity_status, identity_verified_at, dwolla_customer_id, dwolla_customer_status";
    const withScoreSelect =
      "id, full_name, email, phone, phone_verified, iou_score, active_exposure_points, score_last_updated_at";
    const baseSelect = "id, full_name, email, phone, phone_verified";

    let data: any = null;
    let error: any = null;

    const withScoreAndIdentityRes = await supabase
      .from("profiles")
      .select(withScoreAndIdentitySelect)
      .eq("id", me.id)
      .single();

    if (withScoreAndIdentityRes.error) {
      const withScoreRes = await supabase
        .from("profiles")
        .select(withScoreSelect)
        .eq("id", me.id)
        .single();

      if (withScoreRes.error) {
        const fallbackRes = await supabase
          .from("profiles")
          .select(baseSelect)
          .eq("id", me.id)
          .single();

        data = fallbackRes.data;
        error = fallbackRes.error;
      } else {
        data = withScoreRes.data;
        error = withScoreRes.error;
      }
    } else {
      data = withScoreAndIdentityRes.data;
      error = withScoreAndIdentityRes.error;
    }

    if (error) {
      Alert.alert("Load failed", error.message);
      setLoading(false);
      return;
    }

    const merged: ProfileRow = {
      id: data.id,
      full_name: data.full_name,
      email: data.email ?? me.email ?? null,
      phone: data.phone,
      phone_verified: data.phone_verified ?? false,
      iou_score: typeof data.iou_score === "number" ? data.iou_score : null,
      active_exposure_points:
        typeof data.active_exposure_points === "number"
          ? data.active_exposure_points
          : 0,
      score_last_updated_at: data.score_last_updated_at ?? null,

      identity_status: data.identity_status ?? null,
      identity_verified_at: data.identity_verified_at ?? null,
      dwolla_customer_id: data.dwolla_customer_id ?? null,
      dwolla_customer_status: data.dwolla_customer_status ?? null,
    };

    setRow(merged);
    setFullName(merged.full_name ?? "");

    const scoreQueries = [
      supabase
        .from("score_events")
        .select("id, event_type, delta, description, created_at")
        .eq("user_id", me.id)
        .order("created_at", { ascending: false })
        .limit(5),
      supabase
        .from("score_history")
        .select("id, event_type, delta, description, created_at")
        .eq("user_id", me.id)
        .order("created_at", { ascending: false })
        .limit(5),
    ];

    for (const query of scoreQueries) {
      const { data: history, error: historyError } = await query;
      if (!historyError) {
        setScoreEvents((history ?? []) as ScoreEventRow[]);
        setLoading(false);
        return;
      }
    }

    setScoreEvents([]);
    setLoading(false);
  }, []);

  useEffect(() => {
    void load();
  }, [load]);

  async function save() {
    if (!meId) return;

    setSaving(true);
    const { error } = await supabase
      .from("profiles")
      .update({ full_name: fullName.trim() || null })
      .eq("id", meId);

    setSaving(false);

    if (error) {
      return Alert.alert("Save failed", error.message);
    }

    Alert.alert("Saved", "Profile updated.");
    void load();
  }

  async function sendPasswordReset() {
    const me = (await supabase.auth.getUser()).data.user;
    if (!me?.email) return Alert.alert("No email on file");

    const { error } = await supabase.auth.resetPasswordForEmail(me.email);
    if (error) return Alert.alert("Reset failed", error.message);

    Alert.alert("Email sent", "Check your inbox for password reset.");
  }

  async function signOut() {
    await supabase.auth.signOut();
    try {
      navigation.navigate("Auth");
    } catch {}
  }

  const openScoreHistory = () => {
    navigation.navigate("ScoreHistory");
  };

  const normalizedIdentityStatus = useMemo(() => {
    const raw = (row?.identity_status || row?.dwolla_customer_status || "")
      .toString()
      .trim()
      .toLowerCase();

    if (
      raw === "verified" ||
      raw === "approved" ||
      raw === "active" ||
      raw === "identity_verified"
    ) {
      return "verified";
    }

    if (
      raw === "retry" ||
      raw === "document" ||
      raw === "documents_needed" ||
      raw === "document_needed" ||
      raw === "suspended" ||
      raw === "flagged"
    ) {
      return "action_needed";
    }

    if (
      raw === "pending" ||
      raw === "review" ||
      raw === "in_review" ||
      raw === "received"
    ) {
      return "pending";
    }

    return "unverified";
  }, [row]);

  const identityStatusUi = useMemo(() => {
    if (normalizedIdentityStatus === "verified") {
      return {
        label: "Identity Verified",
        shortLabel: "Verified",
        bg: "#EAF8EA",
        color: GREEN,
        description:
          "Your identity is verified and ready for compliant money movement.",
      };
    }

    if (normalizedIdentityStatus === "pending") {
      return {
        label: "Identity Pending",
        shortLabel: "Pending",
        bg: "#FFF7E6",
        color: AMBER,
        description:
          "Your identity has been submitted and is waiting on review.",
      };
    }

    if (normalizedIdentityStatus === "action_needed") {
      return {
        label: "Identity Needs Action",
        shortLabel: "Needs action",
        bg: "#FDECEC",
        color: RED,
        description:
          "More information may be needed before money movement can go live.",
      };
    }

    return {
      label: "Identity Unverified",
      shortLabel: "Unverified",
      bg: "#FDECEC",
      color: RED,
      description:
        "Verify your identity before enabling live ACH and compliance flows.",
    };
  }, [normalizedIdentityStatus]);

  const completionChecks = useMemo(() => {
    const items = [
      { label: "Full name added", done: !!(fullName.trim() || row?.full_name) },
      { label: "Email on file", done: !!row?.email },
      { label: "Phone added", done: !!row?.phone },
      { label: "Phone verified", done: !!row?.phone_verified },
      {
        label: "Identity verified",
        done: normalizedIdentityStatus === "verified",
      },
    ];

    const completed = items.filter((i) => i.done).length;
    const percent = Math.round((completed / items.length) * 100);

    return { items, completed, total: items.length, percent };
  }, [fullName, row, normalizedIdentityStatus]);

  const scoreValue = useMemo(() => {
    if (typeof row?.iou_score === "number") {
      return Math.max(0, Math.round(row.iou_score));
    }
    return null;
  }, [row]);

  const activeExposureValue = useMemo(() => {
    if (typeof row?.active_exposure_points === "number") {
      return Math.max(0, Math.round(row.active_exposure_points));
    }
    return 0;
  }, [row]);

  const visibleTrustScore = useMemo(() => {
    if (scoreValue === null) return null;
    return Math.max(0, scoreValue - activeExposureValue);
  }, [scoreValue, activeExposureValue]);

  const scoreLabel = useMemo(() => {
    if (scoreValue === null) return "Not live yet";
    if (scoreValue >= 1400) return "Lending";
    if (scoreValue >= 1000) return "Strong";
    if (scoreValue >= 800) return "Rising";
    if (scoreValue >= 700) return "Starter";
    if (scoreValue >= 500) return "Watch";
    return "Critical";
  }, [scoreValue]);

  const scoreColor = useMemo(() => {
    if (scoreValue === null) return "#111";
    if (scoreValue >= 1000) return GREEN_DARK;
    if (scoreValue >= 800) return GREEN;
    if (scoreValue >= 700) return BLUE;
    if (scoreValue >= 500) return "#B7791F";
    return RED;
  }, [scoreValue]);

  const scoreUpdatedLabel = useMemo(() => {
    if (!row?.score_last_updated_at) return null;

    const date = new Date(row.score_last_updated_at);
    if (Number.isNaN(date.getTime())) return null;

    return date.toLocaleString();
  }, [row]);

  const identityUpdatedLabel = useMemo(() => {
    if (!row?.identity_verified_at) return null;

    const date = new Date(row.identity_verified_at);
    if (Number.isNaN(date.getTime())) return null;

    return date.toLocaleString();
  }, [row]);

  const formatScoreEventTitle = useCallback((event: ScoreEventRow) => {
    switch (event.event_type) {
      case "payment_on_time":
        return "On-time payment";
      case "payment_early":
        return "Early payment";
      case "payment_late":
        return "Late payment";
      case "loan_completion":
        return "Loan completed";
      case "exposure_removed":
        return "Exposure removed";
      case "strike_1":
        return "Strike 1";
      case "strike_2":
        return "Strike 2";
      case "strike_3":
        return "Strike 3";
      default:
        return event.event_type.replace(/_/g, " ");
    }
  }, []);

  const formatScoreEventDate = useCallback((value: string) => {
    const date = new Date(value);
    if (Number.isNaN(date.getTime())) return "";
    return date.toLocaleString();
  }, []);

  if (loading) {
    return (
      <View style={s.center}>
        <ActivityIndicator />
      </View>
    );
  }

  if (!row) {
    return (
      <View style={s.center}>
        <Text>Not signed in.</Text>
      </View>
    );
  }

  return (
    <ScrollView
      style={s.screen}
      contentContainerStyle={s.content}
      showsVerticalScrollIndicator={false}
    >
      <View style={s.heroCard}>
        <Text style={s.eyebrow}>Your account</Text>
        <Text style={s.h1}>{row.full_name || "Profile"}</Text>
        <Text style={s.heroSub}>{row.email ?? "No email on file"}</Text>

        <View style={s.heroStatusRow}>
          <View
            style={[
              s.statusPill,
              { backgroundColor: row.phone_verified ? "#EAF8EA" : "#FDECEC" },
            ]}
          >
            <Text
              style={[
                s.statusPillText,
                { color: row.phone_verified ? GREEN : RED },
              ]}
            >
              {row.phone_verified ? "Phone Verified" : "Phone Unverified"}
            </Text>
          </View>

          <View
            style={[
              s.statusPill,
              { backgroundColor: identityStatusUi.bg },
            ]}
          >
            <Text
              style={[
                s.statusPillText,
                { color: identityStatusUi.color },
              ]}
            >
              {identityStatusUi.label}
            </Text>
          </View>

          <View style={[s.statusPill, { backgroundColor: "#EEF4FF" }]}>
            <Text style={[s.statusPillText, { color: BLUE }]}>
              {completionChecks.percent}% complete
            </Text>
          </View>
        </View>
      </View>

      <TouchableOpacity
        activeOpacity={0.95}
        style={s.scoreHeroCard}
        onPress={openScoreHistory}
      >
        <View style={s.rowBetweenTop}>
          <Text style={s.scoreHeroTitle}>IOU Score</Text>
          <View style={[s.scoreBadge, { backgroundColor: "#EEF7EE" }]}>
            <Text style={[s.scoreBadgeText, { color: scoreColor }]}>
              {scoreLabel}
            </Text>
          </View>
        </View>

        <Text style={[s.scoreHeroValue, { color: scoreColor }]}>
          {scoreValue === null ? "—" : scoreValue}
        </Text>

        <Text style={s.scoreHeroHint}>
          {scoreValue === null
            ? "Waiting for live score fields."
            : "Your base IOU trust score."}
        </Text>

        <View style={s.exposureRow}>
          <View style={s.metricBox}>
            <Text style={s.metricLabel}>Visible trust</Text>
            <Text style={s.metricValue}>
              {visibleTrustScore === null ? "—" : visibleTrustScore}
            </Text>
          </View>

          <View style={s.metricBox}>
            <Text style={s.metricLabel}>Active exposure</Text>
            <Text
              style={[
                s.metricValue,
                activeExposureValue > 0
                  ? { color: "#B45309" }
                  : { color: GREEN_DARK },
              ]}
            >
              {activeExposureValue > 0 ? `-${activeExposureValue}` : "0"}
            </Text>
          </View>
        </View>

        {scoreUpdatedLabel && (
          <Text style={s.scoreUpdatedText}>Updated {scoreUpdatedLabel}</Text>
        )}

        <View style={s.scoreBox}>
          <Text style={s.scoreBoxTitle}>What feeds your score</Text>
          <Text style={s.scoreBoxText}>
            On-time payments, completed agreements, account age, verified
            identity, and active loan exposure.
          </Text>
        </View>

        <View style={s.scoreHistoryCtaRow}>
          <Text style={s.scoreHistoryCtaText}>Open full score history</Text>
          <Text style={s.scoreHistoryArrow}>→</Text>
        </View>
      </TouchableOpacity>

      <View style={s.card}>
        <View style={s.rowBetween}>
          <Text style={s.sectionTitle}>Score Activity</Text>
          <TouchableOpacity onPress={openScoreHistory} activeOpacity={0.8}>
            <Text style={s.viewAllText}>View all</Text>
          </TouchableOpacity>
        </View>

        {scoreEvents.length === 0 && (
          <Text style={s.emptyActivityText}>No activity yet.</Text>
        )}

        {scoreEvents.map((event) => (
          <View key={event.id} style={s.activityRow}>
            <View
              style={[
                s.activityDeltaWrap,
                event.delta > 0
                  ? s.activityDeltaPositiveBg
                  : event.delta < 0
                  ? s.activityDeltaNegativeBg
                  : s.activityDeltaNeutralBg,
              ]}
            >
              <Text
                style={[
                  s.activityDelta,
                  event.delta > 0
                    ? { color: GREEN_DARK }
                    : event.delta < 0
                    ? { color: RED }
                    : { color: "#667085" },
                ]}
              >
                {event.delta > 0 ? `+${event.delta}` : `${event.delta}`}
              </Text>
            </View>

            <View style={s.activityCopy}>
              <Text style={s.activityReason}>
                {formatScoreEventTitle(event)}
              </Text>

              {!!event.description && (
                <Text style={s.activityDescription}>{event.description}</Text>
              )}

              <Text style={s.activityDate}>
                {formatScoreEventDate(event.created_at)}
              </Text>
            </View>
          </View>
        ))}
      </View>

      <View style={s.card}>
        <Text style={s.sectionTitle}>Profile details</Text>

        <Text style={s.label}>Full name</Text>
        <TextInput
          style={s.input}
          value={fullName}
          onChangeText={setFullName}
          placeholder="Your name"
        />

        <Text style={s.label}>Email</Text>
        <Text style={s.value}>{row.email ?? "—"}</Text>

        <Text style={s.label}>Phone</Text>
        <View style={s.rowBetween}>
          <Text style={s.value}>{row.phone ?? "Not set"}</Text>
          <Text
            style={{
              fontWeight: "800",
              color: row.phone_verified ? GREEN : RED,
            }}
          >
            {row.phone_verified ? "Verified" : "Unverified"}
          </Text>
        </View>

        <TouchableOpacity
          style={[s.btn, { backgroundColor: BLUE }]}
          onPress={() => navigation.navigate("VerifyPhone")}
        >
          <Text style={s.btnTxt}>
            {row.phone_verified ? "Change phone" : "Verify phone"}
          </Text>
        </TouchableOpacity>

        <Text style={s.label}>Identity verification</Text>
        <View style={s.rowBetween}>
          <Text style={s.value}>{identityStatusUi.shortLabel}</Text>
          <Text
            style={{
              fontWeight: "800",
              color: identityStatusUi.color,
            }}
          >
            {identityStatusUi.shortLabel}
          </Text>
        </View>

        <Text style={s.helperText}>{identityStatusUi.description}</Text>

        {!!row.dwolla_customer_id && (
          <Text style={s.metaText}>Dwolla customer connected</Text>
        )}

        {!!identityUpdatedLabel && (
          <Text style={s.metaText}>Verified {identityUpdatedLabel}</Text>
        )}

        <TouchableOpacity
          style={[
            s.btn,
            {
              backgroundColor:
                normalizedIdentityStatus === "verified" ? GREEN_DARK : GREEN,
            },
          ]}
          onPress={() => navigation.navigate("VerifyIdentity")}
        >
          <Text style={s.btnTxt}>
            {normalizedIdentityStatus === "verified"
              ? "View identity details"
              : normalizedIdentityStatus === "pending"
              ? "Continue identity review"
              : normalizedIdentityStatus === "action_needed"
              ? "Fix identity info"
              : "Verify identity"}
          </Text>
        </TouchableOpacity>

        <TouchableOpacity
          style={[s.btn, { backgroundColor: GREEN }]}
          onPress={save}
          disabled={saving}
        >
          <Text style={s.btnTxt}>{saving ? "Saving…" : "Save profile"}</Text>
        </TouchableOpacity>
      </View>

      <View style={s.card}>
        <View style={s.rowBetween}>
          <Text style={s.sectionTitle}>Profile completeness</Text>
          <Text style={s.percentText}>{completionChecks.percent}%</Text>
        </View>

        <View style={s.progressTrack}>
          <View
            style={[
              s.progressFill,
              { width: `${completionChecks.percent}%` },
            ]}
          />
        </View>

        <View style={s.checklist}>
          {completionChecks.items.map((item) => (
            <View key={item.label} style={s.checkRow}>
              <Text style={s.checkIcon}>{item.done ? "✓" : "○"}</Text>
              <Text
                style={[
                  s.checkText,
                  item.done && { color: "#222", fontWeight: "700" },
                ]}
              >
                {item.label}
              </Text>
            </View>
          ))}
        </View>
      </View>

      <View style={s.card}>
        <Text style={s.sectionTitle}>Security</Text>

        <TouchableOpacity
          style={[s.btn, { backgroundColor: "#444" }]}
          onPress={sendPasswordReset}
        >
          <Text style={s.btnTxt}>Email me a password reset link</Text>
        </TouchableOpacity>

        <TouchableOpacity
          style={[s.btn, { backgroundColor: RED }]}
          onPress={signOut}
        >
          <Text style={s.btnTxt}>Sign out</Text>
        </TouchableOpacity>
      </View>
    </ScrollView>
  );
}

const s = StyleSheet.create({
  screen: { flex: 1, backgroundColor: BG },
  content: { padding: 20, paddingBottom: 28 },
  center: { flex: 1, alignItems: "center", justifyContent: "center" },

  heroCard: {
    backgroundColor: "#fff",
    borderRadius: 16,
    padding: 16,
    marginBottom: 14,
    borderWidth: StyleSheet.hairlineWidth,
    borderColor: "#e5e7eb",
  },

  scoreHeroCard: {
    backgroundColor: "#fff",
    borderRadius: 16,
    padding: 16,
    marginBottom: 14,
    borderWidth: StyleSheet.hairlineWidth,
    borderColor: "#e5e7eb",
  },

  eyebrow: {
    fontSize: 12,
    fontWeight: "800",
    textTransform: "uppercase",
    color: GREEN,
    marginBottom: 6,
    letterSpacing: 0.4,
  },

  h1: { fontSize: 24, fontWeight: "800", color: "#111" },

  heroSub: { marginTop: 6, color: "#666", fontSize: 15 },

  heroStatusRow: {
    flexDirection: "row",
    flexWrap: "wrap",
    gap: 8,
    marginTop: 14,
  },

  statusPill: {
    borderRadius: 999,
    paddingHorizontal: 10,
    paddingVertical: 6,
  },

  statusPillText: { fontWeight: "800", fontSize: 12 },

  card: {
    backgroundColor: "#fff",
    borderRadius: 12,
    padding: 14,
    marginBottom: 14,
    borderWidth: StyleSheet.hairlineWidth,
    borderColor: "#e5e7eb",
  },

  sectionTitle: {
    fontSize: 18,
    fontWeight: "800",
    color: "#111",
    marginBottom: 4,
  },

  scoreHeroTitle: { fontSize: 18, fontWeight: "800", color: "#111" },

  scoreHeroValue: {
    fontSize: 52,
    lineHeight: 58,
    fontWeight: "900",
    marginTop: 8,
  },

  scoreHeroHint: { color: "#666", marginTop: 2, fontSize: 15 },

  exposureRow: { flexDirection: "row", gap: 10, marginTop: 14 },

  metricBox: {
    flex: 1,
    backgroundColor: "#F6F8FA",
    borderRadius: 12,
    padding: 12,
    borderWidth: 1,
    borderColor: "#E8EBEF",
  },

  metricLabel: {
    fontSize: 12,
    fontWeight: "800",
    color: "#667085",
    textTransform: "uppercase",
    marginBottom: 6,
  },

  metricValue: { fontSize: 24, fontWeight: "900", color: "#111" },

  label: { fontWeight: "800", color: "#333", marginTop: 10 },

  input: {
    borderWidth: 1,
    borderColor: "#e5e7eb",
    borderRadius: 10,
    paddingHorizontal: 12,
    paddingVertical: 10,
    marginTop: 6,
    backgroundColor: "#f9fafb",
  },

  value: { marginTop: 6, color: "#444" },

  helperText: {
    marginTop: 6,
    color: "#555",
    lineHeight: 20,
  },

  metaText: {
    marginTop: 6,
    color: "#667085",
    fontSize: 13,
    fontWeight: "600",
  },

  rowBetween: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
  },

  rowBetweenTop: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "flex-start",
  },

  btn: {
    marginTop: 12,
    borderRadius: 10,
    paddingVertical: 12,
    alignItems: "center",
  },

  btnTxt: { color: "#fff", fontWeight: "800" },

  percentText: { fontSize: 16, fontWeight: "800", color: GREEN },

  progressTrack: {
    marginTop: 10,
    height: 10,
    borderRadius: 999,
    backgroundColor: "#EAEAEA",
    overflow: "hidden",
  },

  progressFill: {
    height: "100%",
    borderRadius: 999,
    backgroundColor: GREEN,
  },

  checklist: { marginTop: 14, gap: 10 },

  checkRow: { flexDirection: "row", alignItems: "center" },

  checkIcon: {
    width: 22,
    fontSize: 16,
    fontWeight: "800",
    color: GREEN,
  },

  checkText: { color: "#666", fontSize: 14 },

  scoreUpdatedText: {
    color: "#666",
    marginTop: 10,
    fontSize: 13,
    fontWeight: "600",
  },

  scoreBadge: {
    borderRadius: 999,
    paddingHorizontal: 10,
    paddingVertical: 6,
  },

  scoreBadgeText: { fontWeight: "800", fontSize: 12 },

  scoreBox: {
    marginTop: 14,
    backgroundColor: "#F1FFF1",
    borderRadius: 12,
    padding: 12,
    borderWidth: 1,
    borderColor: "#D8EFD8",
  },

  scoreBoxTitle: {
    fontWeight: "800",
    color: "#1F1F1F",
    marginBottom: 6,
  },

  scoreBoxText: { color: "#4D4D4D", lineHeight: 20 },

  scoreHistoryCtaRow: {
    marginTop: 14,
    paddingTop: 12,
    borderTopWidth: StyleSheet.hairlineWidth,
    borderTopColor: "#E5E7EB",
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
  },

  scoreHistoryCtaText: {
    color: BLUE,
    fontWeight: "800",
    fontSize: 15,
  },

  scoreHistoryArrow: {
    color: BLUE,
    fontWeight: "900",
    fontSize: 18,
  },

  viewAllText: {
    color: BLUE,
    fontWeight: "800",
    fontSize: 14,
  },

  emptyActivityText: {
    color: "#666",
    marginTop: 6,
  },

  activityRow: {
    flexDirection: "row",
    alignItems: "flex-start",
    marginTop: 12,
    gap: 10,
  },

  activityDeltaWrap: {
    minWidth: 68,
    borderRadius: 999,
    paddingHorizontal: 10,
    paddingVertical: 8,
    alignItems: "center",
    justifyContent: "center",
  },

  activityDeltaPositiveBg: {
    backgroundColor: "#EAF8EA",
  },

  activityDeltaNegativeBg: {
    backgroundColor: "#FDECEC",
  },

  activityDeltaNeutralBg: {
    backgroundColor: "#EEF2F6",
  },

  activityDelta: {
    fontWeight: "900",
    fontSize: 16,
  },

  activityCopy: {
    flex: 1,
  },

  activityReason: {
    color: "#111",
    fontSize: 15,
    fontWeight: "800",
  },

  activityDescription: {
    color: "#555",
    fontSize: 14,
    marginTop: 2,
    lineHeight: 19,
  },

  activityDate: {
    color: "#777",
    fontSize: 12,
    marginTop: 4,
    fontWeight: "600",
  },
});