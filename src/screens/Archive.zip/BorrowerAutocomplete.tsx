// src/components/BorrowerAutocomplete.tsx
import React, { useEffect, useMemo, useRef, useState } from "react";
import { View, TextInput, FlatList, TouchableOpacity, Text, ActivityIndicator, StyleSheet } from "react-native";
import { supabase } from "../supabase";

export type ProfileLite = {
  id: string;
  full_name: string | null;
  email: string | null;
  phone: string | null;
  phone_verified: boolean | null;
};

function digitsOnly(s: string) { return (s || "").replace(/\D/g, ""); }
const isUuid = (s: string) =>
  /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test((s||"").trim());

type Props = {
  placeholder?: string;
  value: ProfileLite | null;                // selected borrower (or null)
  onChange: (p: ProfileLite | null) => void;
  onInvite?: () => void;                    // optional: open your invite flow
  initialQuery?: string;
};

export default function BorrowerAutocomplete({
  placeholder = "Search email / phone / user id / name",
  value,
  onChange,
  onInvite,
  initialQuery = "",
}: Props) {
  const [q, setQ] = useState(initialQuery);
  const [loading, setLoading] = useState(false);
  const [results, setResults] = useState<ProfileLite[]>([]);
  const [open, setOpen] = useState(false);
  const timer = useRef<ReturnType<typeof setTimeout> | null>(null);

  // do a fast, exact email hit first; fallback to fuzzy OR search
  const runSearch = async (term: string) => {
    const t = term.trim();
    if (!t) { setResults([]); return; }
    setLoading(true);

    try {
      // Exact email first (fast path)
      if (t.includes("@")) {
        const { data: exact } = await supabase
          .from("profiles")
          .select("id, full_name, email, phone, phone_verified")
          .eq("email", t)
          .limit(1);
        if (exact && exact.length) {
          setResults(exact as ProfileLite[]);
          return;
        }
      }

      // Fuzzy fallback
      const parts: string[] = [];
      const d = digitsOnly(t);
      parts.push(`full_name.ilike.%${t}%`);
      if (t.includes("@")) parts.push(`email.ilike.%${t}%`);
      if (d) parts.push(`phone_digits.ilike.%${d}%`);
      if (isUuid(t)) parts.push(`id.eq.${t}`);

      const { data, error } = await supabase
        .from("profiles")
        .select("id, full_name, email, phone, phone_verified")
        .or(parts.join(","))
        .limit(8);

      if (!error) setResults((data ?? []) as ProfileLite[]);
    } finally {
      setLoading(false);
    }
  };

  // debounce typing (250ms)
  useEffect(() => {
    if (timer.current) clearTimeout(timer.current);
    timer.current = setTimeout(() => runSearch(q), 250);
    return () => { if (timer.current) clearTimeout(timer.current); };
  }, [q]);

  const showInvite = useMemo(() => !loading && results.length === 0 && q.trim().length > 2, [loading, results, q]);

  if (value) {
    // Selected state
    return (
      <View style={styles.selectedCard}>
        <View style={{ flex: 1 }}>
          <Text style={{ fontWeight: "800" }}>{value.full_name || "Unnamed"}</Text>
          <Text style={{ color: "#666" }}>{value.email || value.phone || value.id}</Text>
        </View>
        <TouchableOpacity onPress={() => onChange(null)}>
          <Text style={{ color: "#d00", fontWeight: "800" }}>Clear</Text>
        </TouchableOpacity>
      </View>
    );
  }

  return (
    <View>
      <TextInput
        placeholder={placeholder}
        value={q}
        onChangeText={(t) => { setQ(t); setOpen(true); }}
        autoCapitalize="none"
        style={styles.input}
      />

      {open && (
        <View style={styles.dropdown}>
          {loading ? (
            <View style={styles.loadingRow}><ActivityIndicator /></View>
          ) : results.length > 0 ? (
            <FlatList
              keyboardShouldPersistTaps="handled"
              data={results}
              keyExtractor={(r) => r.id}
              ItemSeparatorComponent={() => <View style={{ height: StyleSheet.hairlineWidth, backgroundColor: "#eee" }} />}
              renderItem={({ item }) => (
                <TouchableOpacity style={styles.row} onPress={() => { onChange(item); setOpen(false); }}>
                  <View style={{ flex: 1 }}>
                    <Text style={{ fontWeight: "700" }}>{item.full_name || "Unnamed"}</Text>
                    <Text style={{ color: "#666" }}>{item.email || item.phone || item.id}</Text>
                  </View>
                  {!!item.phone_verified && <Text style={{ color: "#2e7d32", fontWeight: "800" }}>Verified</Text>}
                </TouchableOpacity>
              )}
            />
          ) : showInvite ? (
            <TouchableOpacity style={styles.inviteRow} onPress={onInvite}>
              <Text style={{ color: "#1555d6", fontWeight: "800" }}>Invite “{q.trim()}”</Text>
            </TouchableOpacity>
          ) : null}
        </View>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  input: {
    borderWidth: 1, borderColor: "#ddd", borderRadius: 10, paddingHorizontal: 14, paddingVertical: 12, fontSize: 16, backgroundColor: "#fff",
  },
  dropdown: {
    marginTop: 6, borderWidth: 1, borderColor: "#e5e7eb", backgroundColor: "#fff", borderRadius: 10, maxHeight: 220, overflow: "hidden",
  },
  row: { paddingHorizontal: 12, paddingVertical: 10, flexDirection: "row", alignItems: "center" },
  loadingRow: { padding: 12, alignItems: "center", justifyContent: "center" },
  inviteRow: { padding: 12, alignItems: "center", justifyContent: "center" },
  selectedCard: {
    marginTop: 8, borderWidth: 1, borderColor: "#cbd5e1", backgroundColor: "#f8fafc",
    borderRadius: 10, padding: 12, flexDirection: "row", alignItems: "center", gap: 12,
  },
});