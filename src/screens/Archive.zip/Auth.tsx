// src/screens/Auth.tsx
import React, { useState } from "react";
import { View, Text, TextInput, Button, Alert, ActivityIndicator } from "react-native";
import { supabase } from "../supabase";

export default function Auth() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [busy, setBusy] = useState(false);

  const signIn = async () => {
    setBusy(true);
    try {
      const { error } = await supabase.auth.signInWithPassword({ email: email.trim(), password });
      if (error) throw error;
      // session listener in routes.ts will take over and route into the app
    } catch (e: any) {
      Alert.alert("Sign in failed", e.message ?? String(e));
    } finally {
      setBusy(false);
    }
  };

  const signUp = async () => {
    setBusy(true);
    try {
      const { error } = await supabase.auth.signUp({ email: email.trim(), password });
      if (error) throw error;
      Alert.alert("Check your inbox", "Confirm the email to finish sign up.");
    } catch (e: any) {
      Alert.alert("Sign up failed", e.message ?? String(e));
    } finally {
      setBusy(false);
    }
  };

  const reset = async () => {
    setBusy(true);
    try {
      const { error } = await supabase.auth.resetPasswordForEmail(email.trim(), {
        redirectTo: "io.expo.client://auth-callback", // adjust later if you use deep links
      });
      if (error) throw error;
      Alert.alert("Sent", "Password reset link emailed.");
    } catch (e: any) {
      Alert.alert("Reset failed", e.message ?? String(e));
    } finally {
      setBusy(false);
    }
  };

  return (
    <View style={{ flex: 1, padding: 20, justifyContent: "center" }}>
      <Text style={{ fontSize: 26, fontWeight: "800", marginBottom: 12 }}>Sign in to IOU</Text>

      <TextInput
        style={{ borderWidth: 1, borderColor: "#ddd", borderRadius: 10, padding: 12, marginBottom: 10 }}
        placeholder="Email"
        autoCapitalize="none"
        keyboardType="email-address"
        value={email}
        onChangeText={setEmail}
      />
      <TextInput
        style={{ borderWidth: 1, borderColor: "#ddd", borderRadius: 10, padding: 12, marginBottom: 16 }}
        placeholder="Password"
        secureTextEntry
        value={password}
        onChangeText={setPassword}
      />

      {busy ? <ActivityIndicator /> : <Button title="Sign In" onPress={signIn} />}

      <View style={{ height: 10 }} />

      <Button title="Create account" onPress={signUp} />
      <View style={{ height: 10 }} />
      <Button title="Forgot password" onPress={reset} />
    </View>
  );
}