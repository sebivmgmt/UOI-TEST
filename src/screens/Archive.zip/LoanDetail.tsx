// src/screens/LoanDetail.tsx

import React, { useCallback, useEffect, useMemo, useState } from 'react';
import {
  View,
  Text,
  Alert,
  ActivityIndicator,
  FlatList,
  TouchableOpacity,
  StyleSheet,
  RefreshControl,
  Share,
} from 'react-native';
import { useFocusEffect } from '@react-navigation/native';
import Swipeable from 'react-native-gesture-handler/Swipeable';
import { RectButton } from 'react-native-gesture-handler';
import { supabase } from '../supabase';

// ---------------------------------------------
// TYPES
// ---------------------------------------------

type Frequency = 'weekly' | 'biweekly' | 'monthly';
type ViewDirection = 'in' | 'out';

type Iou = {
  id: string;
  title: string | null;
  lender_id: string;
  borrower_id: string | null;
  principal_cents: number;
  apr_bps: number;
  start_date: string | null;
  term_months: number;
  frequency: Frequency;
  status: 'draft' | 'open' | 'late' | 'paid' | 'archived' | string;
  archived_at: string | null;
  deleted_at: string | null;
  activated_at: string | null;
  total_installments?: number | null;
  paid_installments?: number | null;
  progress_percent?: number | null;
};

type PaymentRow = {
  id: string;
  iou_id: string;
  amount_cents: number;
  status: 'scheduled' | 'pending_confirmation' | 'paid' | 'late' | string;
  paid_at: string | null;
  due: string;
};

type BorrowerProfile = {
  iou_score?: number | null;
  active_exposure_points?: number | null;
  full_name?: string | null;
  repayment_streak?: number | null;
} | null;

// ---------------------------------------------
// CONSTANTS
// ---------------------------------------------

const GREEN = '#77B777';
const BLUE = '#3b82f6';
const ORANGE = '#f59e0b';
const SOFT_BG = '#F5F7F9';

const EARLY_REWARD = 27;
const ON_TIME_REWARD = 7;
const COMPLETION_REWARD = 77;

const currency = (c: number) => `$${(c / 100).toFixed(2)}`;

// ---------------------------------------------
// SCREEN
// ---------------------------------------------

export default function LoanDetail({ route, navigation }: any) {
  // -------------------------------------------
  // ROUTE PARAMS
  // -------------------------------------------

  const iouId: string | undefined =
    route?.params?.iouId ??
    route?.params?.iou_id ??
    route?.params?.loanId ??
    route?.params?.loan_id ??
    route?.params?.id;

  const routeDirection: ViewDirection | undefined =
    route?.params?.direction === 'in' || route?.params?.direction === 'out'
      ? route.params.direction
      : undefined;

  // -------------------------------------------
  // STATE
  // -------------------------------------------

  const [me, setMe] = useState<string | null>(null);
  const [iou, setIou] = useState<Iou | null>(null);
  const [rows, setRows] = useState<PaymentRow[]>([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [borrowerProfile, setBorrowerProfile] = useState<BorrowerProfile>(null);

  // -------------------------------------------
  // AUTH
  // -------------------------------------------

  useEffect(() => {
    supabase.auth.getUser().then(({ data }) => {
      setMe(data.user?.id ?? null);
    });
  }, []);

  // -------------------------------------------
  // DATA FETCHING
  // -------------------------------------------

  const fetchIou = useCallback(async () => {
    if (!iouId) return;

    const { data, error } = await supabase
      .from('ious')
      .select('*')
      .eq('id', iouId)
      .single();

    if (error) throw error;

    const nextIou = data as Iou;
    setIou(nextIou);

    if (!nextIou?.borrower_id) {
      setBorrowerProfile(null);
      return;
    }

    let profile: any = null;

    const streakSelects = [
      'iou_score, active_exposure_points, full_name, repayment_streak',
      'iou_score, active_exposure_points, full_name, on_time_streak',
      'iou_score, active_exposure_points, full_name',
    ];

    for (const sel of streakSelects) {
      const { data: profileData, error: profileError } = await supabase
        .from('profiles')
        .select(sel)
        .eq('id', nextIou.borrower_id)
        .single();

      if (!profileError && profileData) {
        profile = profileData;
        break;
      }
    }

    if (!profile) {
      setBorrowerProfile(null);
      return;
    }

    setBorrowerProfile({
      iou_score:
        typeof profile.iou_score === 'number' ? profile.iou_score : null,
      active_exposure_points:
        typeof profile.active_exposure_points === 'number'
          ? profile.active_exposure_points
          : null,
      full_name: profile.full_name ?? null,
      repayment_streak:
        typeof profile.repayment_streak === 'number'
          ? profile.repayment_streak
          : typeof profile.on_time_streak === 'number'
            ? profile.on_time_streak
            : null,
    });
  }, [iouId]);

  const fetchPayments = useCallback(async () => {
    if (!iouId) return;

    const selects = [
      'id, iou_id, amount_cents, status, paid_at, due_date',
      'id, iou_id, amount_cents, status, paid_at, due_at',
      'id, iou_id, amount_cents, status, paid_at, scheduled_at',
    ];

    let lastErr: any = null;

    for (const sel of selects) {
      const orderCol =
        sel.includes('due_date')
          ? 'due_date'
          : sel.includes('due_at')
            ? 'due_at'
            : 'scheduled_at';

      const { data, error } = await supabase
        .from('payments')
        .select(sel)
        .eq('iou_id', iouId)
        .order(orderCol as any, { ascending: true });

      if (!error) {
        const normalized: PaymentRow[] = (data ?? []).map((p: any) => ({
          id: p.id,
          iou_id: p.iou_id,
          amount_cents: p.amount_cents,
          status: p.status,
          paid_at: p.paid_at,
          due:
            p.due_date ??
            (typeof p.due_at === 'string' ? p.due_at.slice(0, 10) : null) ??
            (typeof p.scheduled_at === 'string'
              ? p.scheduled_at.slice(0, 10)
              : null) ??
            '',
        }));

        setRows(normalized);
        return;
      }

      lastErr = error;
    }

    throw lastErr;
  }, [iouId]);

  const fetchAll = useCallback(async () => {
    if (!iouId) return;

    setLoading(true);

    try {
      await Promise.all([fetchIou(), fetchPayments()]);
    } catch (e: any) {
      Alert.alert('Load failed', e?.message ?? String(e));
    } finally {
      setLoading(false);
    }
  }, [fetchIou, fetchPayments, iouId]);

  useFocusEffect(
    useCallback(() => {
      void fetchAll();
    }, [fetchAll])
  );

  useEffect(() => {
    if (!iouId) return;

    const ch = supabase
      .channel(`loan-${iouId}`)
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'payments',
          filter: `iou_id=eq.${iouId}`,
        },
        () => {
          void fetchPayments();
        }
      )
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'ious',
          filter: `id=eq.${iouId}`,
        },
        () => {
          void fetchIou();
        }
      )
      .subscribe();

    return () => {
      void supabase.removeChannel(ch);
    };
  }, [iouId, fetchIou, fetchPayments]);

  // -------------------------------------------
  // DERIVED STATE
  // -------------------------------------------

  const isArchived = !!iou?.archived_at;
  const isDeleted = !!iou?.deleted_at;
  const isLender = !!me && !!iou && me === iou.lender_id;
  const isBorrower = !!me && !!iou && me === iou.borrower_id;

  const isIncomingView = routeDirection
    ? routeDirection === 'in'
    : isLender && !isBorrower;

  const isOutgoingView = routeDirection
    ? routeDirection === 'out'
    : isBorrower;

  const flowLabel = isIncomingView
    ? 'Incoming to you'
    : isOutgoingView
      ? 'Outgoing from you'
      : 'Loan';

  const paidTotal = useMemo(
    () =>
      rows
        .filter((r) => !!r.paid_at)
        .reduce((sum, r) => sum + r.amount_cents, 0),
    [rows]
  );

  const scheduledTotal = useMemo(
    () => rows.reduce((sum, r) => sum + r.amount_cents, 0),
    [rows]
  );

  const remainingTotal = Math.max(0, scheduledTotal - paidTotal);

  const totalInstallments = useMemo(() => {
    const dbTotal =
      typeof iou?.total_installments === 'number' && iou.total_installments > 0
        ? iou.total_installments
        : 0;

    return Math.max(dbTotal, rows.length);
  }, [iou, rows.length]);

  const paidInstallments = useMemo(() => {
    return rows.filter((r) => !!r.paid_at).length;
  }, [rows]);

  const progressPercent = useMemo(() => {
    if (!totalInstallments) return 0;
    return Math.round((paidInstallments / totalInstallments) * 100);
  }, [paidInstallments, totalInstallments]);

  const paymentsRemaining = useMemo(() => {
    return Math.max(
      0,
      Math.max(totalInstallments, rows.length) - paidInstallments
    );
  }, [paidInstallments, rows.length, totalInstallments]);

  const completionRewardText = useMemo(() => {
    if (paymentsRemaining === 0) {
      return `Loan completed. The +${COMPLETION_REWARD} completion reward is already earned.`;
    }

    if (paymentsRemaining === 1) {
      return `One payment left. Completing this loan unlocks the +${COMPLETION_REWARD} completion reward.`;
    }

    return `Finish all ${paymentsRemaining} remaining payments to unlock the +${COMPLETION_REWARD} completion reward.`;
  }, [paymentsRemaining]);

  const repaymentStreakValue = useMemo(() => {
    if (typeof borrowerProfile?.repayment_streak === 'number') {
      return Math.max(0, borrowerProfile.repayment_streak);
    }
    return null;
  }, [borrowerProfile]);

  const borrowerTrustLabel = useMemo(() => {
    if (typeof borrowerProfile?.iou_score !== 'number') return 'No score yet';
    if (borrowerProfile.iou_score >= 1000) return 'Strong';
    if (borrowerProfile.iou_score >= 850) return 'Rising';
    if (borrowerProfile.iou_score >= 700) return 'Starter';
    return 'Watch';
  }, [borrowerProfile]);

  const repaymentStreakText = useMemo(() => {
    if (repaymentStreakValue === null) {
      return 'Repayment streak not live yet.';
    }

    if (repaymentStreakValue === 0) {
      return 'No active on-time streak right now.';
    }

    if (repaymentStreakValue === 1) {
      return '1 on-time payment in a row.';
    }

    return `${repaymentStreakValue} on-time payments in a row.`;
  }, [repaymentStreakValue]);

  // -------------------------------------------
  // REWARD PREVIEW HELPERS
  // -------------------------------------------

  const getTimingType = useCallback((due: string) => {
    const parsed = new Date(due);
    if (Number.isNaN(parsed.getTime())) return 'unknown';

    const now = new Date();
    const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
    const dueDate = new Date(
      parsed.getFullYear(),
      parsed.getMonth(),
      parsed.getDate()
    );

    if (today.getTime() < dueDate.getTime()) return 'early';
    if (today.getTime() === dueDate.getTime()) return 'on_time';
    return 'late';
  }, []);

  const getRewardPreviewText = useCallback(
    (item: PaymentRow, index: number) => {
      if (item.paid_at) return null;
      if (!isOutgoingView) return null;
      if (!(item.status === 'scheduled' || item.status === 'late')) return null;

      const timing = getTimingType(item.due);
      const isFinal =
        index + 1 >= Math.max(totalInstallments, rows.length) &&
        Math.max(totalInstallments, rows.length) > 0;

      if (timing === 'early') {
        if (isFinal) {
          return `Early payment: +${EARLY_REWARD}. Final payoff also unlocks +${COMPLETION_REWARD}.`;
        }
        return `Early payment preview: +${EARLY_REWARD}.`;
      }

      if (timing === 'on_time') {
        if (isFinal) {
          return `On-time payment: +${ON_TIME_REWARD}. Final payoff also unlocks +${COMPLETION_REWARD}.`;
        }
        return `On-time payment preview: +${ON_TIME_REWARD}.`;
      }

      if (timing === 'late') {
        if (isFinal) {
          return `Late timing earns no timing reward. Final completion can still unlock +${COMPLETION_REWARD}.`;
        }
        return 'Late timing earns no early/on-time reward.';
      }

      if (isFinal) {
        return `Final payment can unlock +${COMPLETION_REWARD} on completion.`;
      }

      return null;
    },
    [getTimingType, isOutgoingView, rows.length, totalInstallments]
  );

  // -------------------------------------------
  // NAVIGATION / ACTIONS
  // -------------------------------------------

  const navigateToPersonProfile = useCallback(() => {
    if (!iou?.borrower_id) {
      Alert.alert(
        'Missing borrower',
        'This loan does not have a borrower profile linked yet.'
      );
      return;
    }

    const state = navigation?.getState?.();
    const routeNames: string[] = Array.isArray(state?.routeNames)
      ? state.routeNames
      : [];

    if (routeNames.includes('Person')) {
      navigation.navigate('Person', {
        personId: iou.borrower_id,
      });
      return;
    }

    Alert.alert(
      'Profile unavailable',
      'The borrower profile screen is not registered in this navigator yet.'
    );
  }, [iou?.borrower_id, navigation]);

  const goToPayScreen = (item: PaymentRow) => {
    navigation.navigate('ConfirmPayment', {
      paymentId: item.id,
      amount: item.amount_cents,
      iouId,
      iou_id: iouId,
      loanId: iouId,
      loan_id: iouId,
    });
  };

  const openFullLoan = () => {
    if (!iouId) {
      Alert.alert('Missing loan', 'This loan is missing its contract reference.');
      return;
    }

    navigation.navigate('PreviewSign', {
      id: iouId,
    });
  };

  const confirmIncomingPayment = async (item: PaymentRow) => {
    try {
      const { data, error } = await supabase.rpc('pay_and_receipt', {
        p_payment_id: item.id,
      });

      if (error) throw error;

      let hashPreview = '';
      if (Array.isArray(data) && data[0]?.hash_hex) {
        hashPreview = data[0].hash_hex;
      } else if ((data as any)?.hash_hex) {
        hashPreview = (data as any).hash_hex;
      }

      await Promise.all([fetchIou(), fetchPayments()]);

      Alert.alert(
        'Payment confirmed',
        hashPreview
          ? `Receipt: ${hashPreview.slice(0, 12)}…`
          : 'Payment confirmed successfully.',
        [
          {
            text: 'View receipt',
            onPress: () =>
              navigation.navigate('Receipt', {
                paymentId: item.id,
                iouId,
                iou_id: iouId,
                loanId: iouId,
                loan_id: iouId,
              }),
          },
          { text: 'OK' },
        ]
      );
    } catch (e: any) {
      Alert.alert('Confirm failed', e?.message ?? 'Could not confirm payment.');
    }
  };

  const sendReminder = async (item: PaymentRow) => {
    try {
      const title = iou?.title || 'Loan';
      const amount = currency(item.amount_cents);

      await Share.share({
        message: `Reminder: ${title} payment of ${amount} is due ${item.due} in IOU.`,
      });
    } catch (e: any) {
      Alert.alert('Reminder failed', e?.message ?? 'Could not open share sheet.');
    }
  };

  const onRefresh = async () => {
    setRefreshing(true);
    try {
      await Promise.all([fetchIou(), fetchPayments()]);
    } finally {
      setRefreshing(false);
    }
  };

  const openPaidReceipt = (item: PaymentRow) => {
    navigation.navigate('Receipt', {
      paymentId: item.id,
      iouId,
      iou_id: iouId,
      loanId: iouId,
      loan_id: iouId,
    });
  };

  const openIncomingPending = (item: PaymentRow) => {
    Alert.alert(
      'Confirm incoming payment',
      `Borrower marked ${currency(item.amount_cents)} as sent.\n\nConfirm once you’ve received it.`,
      [
        { text: 'Close', style: 'cancel' },
        {
          text: 'Confirm',
          onPress: () => {
            void confirmIncomingPayment(item);
          },
        },
      ]
    );
  };

  const openIncomingScheduled = (item: PaymentRow) => {
    Alert.alert(
      'Incoming payment',
      `${currency(item.amount_cents)} due ${item.due}`,
      [
        { text: 'Close', style: 'cancel' },
        {
          text: 'Remind borrower',
          onPress: () => {
            void sendReminder(item);
          },
        },
      ]
    );
  };

  const openOutgoingPending = () => {
    Alert.alert(
      'Pending confirmation',
      'Your payment has been started and is waiting for lender confirmation.'
    );
  };

  // -------------------------------------------
  // SMALL UI COMPONENTS
  // -------------------------------------------

  const StatusPill = ({ value }: { value: string }) => {
    const bg =
      value === 'paid'
        ? '#C8E6C9'
        : value === 'pending_confirmation'
          ? '#BBDEFB'
          : value === 'late'
            ? '#FFCDD2'
            : '#E0E0E0';

    return (
      <View style={[s.pill, { backgroundColor: bg }]}>
        <Text style={s.pillTxt}>
          {value === 'pending_confirmation' ? 'PENDING' : value.toUpperCase()}
        </Text>
      </View>
    );
  };

  const PaymentRowView = ({
    item,
    index,
  }: {
    item: PaymentRow;
    index: number;
  }) => {
    const canPay =
      isOutgoingView &&
      !isArchived &&
      !isDeleted &&
      !item.paid_at &&
      (item.status === 'scheduled' || item.status === 'late');

    const canRemind =
      isIncomingView &&
      !isArchived &&
      !isDeleted &&
      !item.paid_at &&
      item.status !== 'pending_confirmation';

    const canConfirm =
      isIncomingView &&
      !isArchived &&
      !isDeleted &&
      !item.paid_at &&
      item.status === 'pending_confirmation';

    const rewardPreviewText = getRewardPreviewText(item, index);

    const leftActions = () => (
      <RectButton style={s.leftAction} onPress={openFullLoan}>
        <Text style={s.leftActionText}>Full loan</Text>
      </RectButton>
    );

    const rightActions = () => {
      if (canPay) {
        return (
          <RectButton
            style={s.rightActionPay}
            onPress={() => goToPayScreen(item)}
          >
            <Text style={s.rightActionText}>Pay now</Text>
          </RectButton>
        );
      }

      if (canRemind) {
        return (
          <RectButton
            style={s.rightActionRemind}
            onPress={() => void sendReminder(item)}
          >
            <Text style={s.rightActionText}>Remind</Text>
          </RectButton>
        );
      }

      if (canConfirm) {
        return (
          <RectButton
            style={s.rightActionConfirm}
            onPress={() => void confirmIncomingPayment(item)}
          >
            <Text style={s.rightActionText}>Confirm</Text>
          </RectButton>
        );
      }

      return <View />;
    };

    return (
      <Swipeable
        renderLeftActions={leftActions}
        renderRightActions={rightActions}
        overshootLeft={false}
        overshootRight={false}
      >
        <TouchableOpacity
          activeOpacity={item.paid_at ? 0.85 : 0.9}
          onPress={() => {
            if (item.paid_at) {
              openPaidReceipt(item);
              return;
            }

            if (isIncomingView && item.status === 'pending_confirmation') {
              openIncomingPending(item);
              return;
            }

            if (isIncomingView && !item.paid_at) {
              openIncomingScheduled(item);
              return;
            }

            if (isOutgoingView && item.status === 'pending_confirmation') {
              openOutgoingPending();
              return;
            }

            if (isOutgoingView && canPay) {
              goToPayScreen(item);
            }
          }}
        >
          <View style={s.payRow}>
            <View style={s.rowTop}>
              <View style={{ flex: 1 }}>
                <Text style={s.paymentIndexText}>
                  Payment {index + 1} of {Math.max(totalInstallments, rows.length)}
                </Text>

                <Text style={s.amountText}>{currency(item.amount_cents)}</Text>
                <Text style={s.dueText}>Due {item.due}</Text>

                {!!rewardPreviewText && (
                  <Text style={s.rewardPreviewText}>{rewardPreviewText}</Text>
                )}

                {!item.paid_at && canPay && (
                  <Text style={s.swipeGuide}>
                    ← Full loan info   •   Swipe   •   Pay now →
                  </Text>
                )}

                {!item.paid_at && canRemind && (
                  <Text style={s.swipeGuide}>
                    ← Full loan info   •   Tap / Swipe   •   Remind →
                  </Text>
                )}

                {!item.paid_at && canConfirm && (
                  <Text style={[s.swipeGuide, { color: BLUE }]}>
                    ← Full loan info   •   Tap / Swipe   •   Confirm →
                  </Text>
                )}

                {!!item.paid_at && (
                  <Text style={[s.swipeGuide, { color: GREEN }]}>
                    Paid {new Date(item.paid_at).toLocaleDateString()}
                  </Text>
                )}
              </View>

              <View style={s.statusWrap}>
                <StatusPill
                  value={item.paid_at ? 'paid' : item.status || 'scheduled'}
                />
              </View>
            </View>
          </View>
        </TouchableOpacity>
      </Swipeable>
    );
  };

  // -------------------------------------------
  // LOADING / EMPTY STATES
  // -------------------------------------------

  if (!iouId) {
    return (
      <View style={s.center}>
        <Text>Missing loan id.</Text>
      </View>
    );
  }

  if (loading) {
    return (
      <View style={s.center}>
        <ActivityIndicator />
      </View>
    );
  }

  if (!iou) {
    return (
      <View style={s.center}>
        <Text>Loan not found.</Text>
      </View>
    );
  }

  // -------------------------------------------
  // RENDER
  // -------------------------------------------

  return (
    <View style={{ flex: 1, backgroundColor: SOFT_BG }}>
      <FlatList
        data={rows}
        keyExtractor={(p) => p.id}
        renderItem={({ item, index }) => (
          <PaymentRowView item={item} index={index} />
        )}
        contentContainerStyle={{ padding: 16, paddingBottom: 96 }}
        ItemSeparatorComponent={() => <View style={{ height: 10 }} />}
        ListHeaderComponent={
          <View style={s.header}>
            <Text style={s.h1}>{iou.title || 'Loan'}</Text>

            <TouchableOpacity
              activeOpacity={0.92}
              style={s.borrowerCard}
              onPress={navigateToPersonProfile}
            >
              <View style={s.borrowerCardHeader}>
                <Text style={s.borrowerCardTitle}>Borrower</Text>
                <Text style={s.borrowerCardLink}>View profile →</Text>
              </View>

              <Text style={s.borrowerNameText}>
                {borrowerProfile?.full_name || 'Borrower'}
              </Text>

              <Text style={s.borrowerScoreLine}>
                {typeof borrowerProfile?.iou_score === 'number'
                  ? borrowerProfile.iou_score
                  : '—'}{' '}
                <Text style={s.borrowerScoreMeta}>
                  {typeof borrowerProfile?.iou_score === 'number'
                    ? `· ${borrowerTrustLabel}`
                    : ''}
                </Text>
              </Text>

              <Text style={s.streakText}>{repaymentStreakText}</Text>
            </TouchableOpacity>

            <Text style={s.subhead}>
              {flowLabel} · {rows.length} payment{rows.length === 1 ? '' : 's'}
            </Text>

            <Text style={s.subhead}>
              Paid {currency(paidTotal)} · Remaining {currency(remainingTotal)}
            </Text>

            <View style={s.progressSection}>
              <View style={s.progressHeaderRow}>
                <Text style={s.progressLabel}>Loan progress</Text>
                <Text style={s.progressValue}>{Math.round(progressPercent)}%</Text>
              </View>

              <View style={s.progressTrack}>
                <View
                  style={[
                    s.progressFill,
                    { width: `${Math.max(0, Math.min(100, progressPercent))}%` },
                  ]}
                />
              </View>

              <Text style={s.progressSubtext}>
                {paidInstallments} / {Math.max(totalInstallments, rows.length)} payments
                completed
              </Text>
            </View>

            <View style={s.rewardCard}>
              <Text style={s.rewardTitle}>Completion reward</Text>
              <Text style={s.rewardText}>{completionRewardText}</Text>
            </View>

            <TouchableOpacity style={s.fullLoanBtn} onPress={openFullLoan}>
              <Text style={s.fullLoanBtnText}>View full loan</Text>
            </TouchableOpacity>
          </View>
        }
        ListEmptyComponent={
          <View style={s.emptyWrap}>
            <Text style={s.emptyText}>No payments found.</Text>
          </View>
        }
        refreshControl={
          <RefreshControl refreshing={refreshing} onRefresh={onRefresh} />
        }
      />
    </View>
  );
}

// ---------------------------------------------
// STYLES
// ---------------------------------------------

const s = StyleSheet.create({
  center: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
  },

  header: {
    marginBottom: 12,
  },

  h1: {
    fontSize: 22,
    fontWeight: '800',
    marginBottom: 2,
  },

  subhead: {
    color: '#666',
    marginTop: 4,
  },

  borrowerCard: {
    marginTop: 12,
    backgroundColor: '#fff',
    borderRadius: 14,
    padding: 14,
    borderWidth: 1,
    borderColor: '#E5E7EB',
  },

  borrowerCardHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },

  borrowerCardTitle: {
    fontSize: 12,
    fontWeight: '800',
    color: '#777',
    textTransform: 'uppercase',
  },

  borrowerCardLink: {
    color: BLUE,
    fontWeight: '800',
    fontSize: 13,
  },

  borrowerNameText: {
    marginTop: 8,
    color: '#111827',
    fontSize: 16,
    fontWeight: '800',
  },

  borrowerScoreLine: {
    fontSize: 30,
    fontWeight: '900',
    color: GREEN,
    marginTop: 6,
  },

  borrowerScoreMeta: {
    fontSize: 15,
    fontWeight: '800',
    color: '#667085',
  },

  streakText: {
    marginTop: 6,
    color: '#4D4D4D',
    fontSize: 14,
    fontWeight: '700',
  },

  progressSection: {
    marginTop: 14,
    backgroundColor: '#fff',
    borderRadius: 14,
    padding: 14,
    borderWidth: 1,
    borderColor: '#E5E7EB',
  },

  progressHeaderRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },

  progressLabel: {
    fontSize: 13,
    fontWeight: '800',
    color: '#444',
    textTransform: 'uppercase',
  },

  progressValue: {
    fontSize: 13,
    fontWeight: '800',
    color: GREEN,
  },

  progressTrack: {
    marginTop: 8,
    height: 10,
    borderRadius: 999,
    backgroundColor: '#EAEAEA',
    overflow: 'hidden',
  },

  progressFill: {
    height: '100%',
    borderRadius: 999,
    backgroundColor: GREEN,
  },

  progressSubtext: {
    marginTop: 8,
    color: '#666',
    fontSize: 13,
    fontWeight: '700',
  },

  rewardCard: {
    marginTop: 14,
    backgroundColor: '#F1FFF1',
    borderRadius: 12,
    padding: 12,
    borderWidth: 1,
    borderColor: '#D8EFD8',
  },

  rewardTitle: {
    fontSize: 12,
    fontWeight: '800',
    color: '#2E7D32',
    textTransform: 'uppercase',
    marginBottom: 6,
  },

  rewardText: {
    color: '#4D4D4D',
    lineHeight: 20,
    fontSize: 14,
    fontWeight: '600',
  },

  fullLoanBtn: {
    marginTop: 14,
    alignSelf: 'flex-start',
    backgroundColor: '#EEF7EE',
    paddingHorizontal: 14,
    paddingVertical: 10,
    borderRadius: 10,
  },

  fullLoanBtnText: {
    color: '#2E7D32',
    fontWeight: '800',
    fontSize: 15,
  },

  payRow: {
    padding: 16,
    borderRadius: 18,
    backgroundColor: '#fff',
    borderWidth: 1,
    borderColor: '#E9E9E9',
  },

  rowTop: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    justifyContent: 'space-between',
    gap: 12,
  },

  paymentIndexText: {
    fontSize: 12,
    fontWeight: '800',
    color: '#666',
    textTransform: 'uppercase',
    marginBottom: 4,
  },

  amountText: {
    fontSize: 28,
    fontWeight: '800',
    color: '#111',
  },

  dueText: {
    color: '#666',
    marginTop: 6,
    fontSize: 16,
  },

  rewardPreviewText: {
    marginTop: 8,
    color: '#2E7D32',
    fontSize: 13,
    fontWeight: '700',
    lineHeight: 18,
  },

  swipeGuide: {
    color: '#7A7A7A',
    marginTop: 10,
    fontSize: 13,
    fontWeight: '700',
  },

  statusWrap: {
    alignItems: 'flex-end',
  },

  pill: {
    paddingHorizontal: 10,
    paddingVertical: 5,
    borderRadius: 999,
  },

  pillTxt: {
    fontSize: 12,
    fontWeight: '800',
    color: '#111',
  },

  leftAction: {
    width: 150,
    marginVertical: 2,
    marginLeft: 4,
    borderRadius: 18,
    backgroundColor: BLUE,
    justifyContent: 'center',
    alignItems: 'center',
  },

  leftActionText: {
    color: '#fff',
    fontWeight: '800',
    fontSize: 16,
  },

  rightActionPay: {
    width: 150,
    marginVertical: 2,
    marginRight: 4,
    borderRadius: 18,
    backgroundColor: GREEN,
    justifyContent: 'center',
    alignItems: 'center',
  },

  rightActionRemind: {
    width: 150,
    marginVertical: 2,
    marginRight: 4,
    borderRadius: 18,
    backgroundColor: ORANGE,
    justifyContent: 'center',
    alignItems: 'center',
  },

  rightActionConfirm: {
    width: 150,
    marginVertical: 2,
    marginRight: 4,
    borderRadius: 18,
    backgroundColor: BLUE,
    justifyContent: 'center',
    alignItems: 'center',
  },

  rightActionText: {
    color: '#fff',
    fontWeight: '800',
    fontSize: 16,
  },

  emptyWrap: {
    padding: 20,
    alignItems: 'center',
  },

  emptyText: {
    color: '#777',
  },
});