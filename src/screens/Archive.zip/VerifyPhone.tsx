// src/screens/VerifyPhone.tsx
import React, { useEffect, useState } from "react";
import { View, Text, TextInput, Button, Alert, KeyboardAvoidingView, Platform } from "react-native";
import { supabase } from "../supabase";

export default function VerifyPhone({ navigation }: any) {
  const [userId, setUserId] = useState<string | null>(null);
  const [phone, setPhone] = useState("");
  const [code, setCode] = useState("");

  useEffect(() => {
    supabase.auth.getUser().then(({ data }) => setUserId(data.user?.id ?? null));
  }, []);

  const sendDev = async () => {
    if (!userId) return Alert.alert("Not signed in");
    if (!phone.trim()) return Alert.alert("Enter your phone");
    // write ONLY phone; trigger fills phone_digits
    const { error } = await supabase.from("profiles").update({ phone }).eq("id", userId);
    if (error) return Alert.alert("Send failed", error.message);
    Alert.alert("Code sent (dev)", "Use 7777777");
  };

  const verifyDev = async () => {
    if (!userId) return Alert.alert("Not signed in");
    if (code.trim() !== "7777777") return Alert.alert("Invalid code", "Use 7777777 in DEV.");
    const { error } = await supabase.from("profiles").update({ phone_verified: true }).eq("id", userId);
    if (error) return Alert.alert("Verify failed", error.message);
    Alert.alert("Verified", "Your phone is verified.", [
      { text: "OK", onPress: () => navigation.goBack() },
    ]);
  };

  return (
    <KeyboardAvoidingView behavior={Platform.OS === "ios" ? "padding" : undefined} style={{ flex: 1, padding: 16 }}>
      <Text style={{ fontSize: 26, fontWeight: "800", marginBottom: 12 }}>Verify your phone</Text>
      <TextInput
        style={{ borderWidth: 1, borderColor: "#ddd", borderRadius: 10, padding: 12, marginBottom: 10 }}
        keyboardType="phone-pad"
        placeholder="Phone"
        value={phone}
        onChangeText={setPhone}
      />
      <Button title="Send (dev mock)" onPress={sendDev} />

      <View style={{ height: 16 }} />

      <TextInput
        style={{ borderWidth: 1, borderColor: "#ddd", borderRadius: 10, padding: 12, marginBottom: 10 }}
        keyboardType="number-pad"
        placeholder="Enter code"
        value={code}
        onChangeText={setCode}
      />
      <Button title="Verify" onPress={verifyDev} />
    </KeyboardAvoidingView>
  );
}