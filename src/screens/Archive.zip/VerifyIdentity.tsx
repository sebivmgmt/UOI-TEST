// src/screens/VerifyIdentity.tsx
import React, { useEffect, useMemo, useState } from "react";
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  Alert,
  KeyboardAvoidingView,
  Platform,
  ScrollView,
  StyleSheet,
  ActivityIndicator,
} from "react-native";
import { supabase } from "../supabase";

const GREEN = "#77B777";
const GREEN_DARK = "#5F9F5F";
const RED = "#D9534F";
const BLUE = "#3B82F6";
const BG = "#F5F7F9";
const BORDER = "#E5E7EB";
const TEXT = "#111827";
const SUBTLE = "#6B7280";
const AMBER = "#B7791F";

type ProfileRow = {
  id: string;
  full_name: string | null;
  email: string | null;
  phone: string | null;
  dob?: string | null;
  address_1?: string | null;
  address_2?: string | null;
  city?: string | null;
  state?: string | null;
  postal_code?: string | null;
  ssn_last_4?: string | null;
  identity_status?: string | null;
  dwolla_customer_id?: string | null;
  dwolla_customer_status?: string | null;
};

function formatDobInput(value: string) {
  const digits = value.replace(/\D/g, "").slice(0, 8);

  if (digits.length <= 2) return digits;
  if (digits.length <= 4) return `${digits.slice(0, 2)}/${digits.slice(2)}`;
  return `${digits.slice(0, 2)}/${digits.slice(2, 4)}/${digits.slice(4)}`;
}

function formatSsnLast4(value: string) {
  return value.replace(/\D/g, "").slice(0, 4);
}

function normalizeDobToIso(value: string) {
  if (/^\d{4}-\d{2}-\d{2}$/.test(value)) return value;
  if (!/^\d{2}\/\d{2}\/\d{4}$/.test(value)) return null;

  const [mm, dd, yyyy] = value.split("/");
  return `${yyyy}-${mm}-${dd}`;
}

function formatDobForInput(value: string | null | undefined) {
  if (!value) return "";
  if (/^\d{2}\/\d{2}\/\d{4}$/.test(value)) return value;

  const iso = value.match(/^(\d{4})-(\d{2})-(\d{2})$/);
  if (!iso) return value;
  return `${iso[2]}/${iso[3]}/${iso[1]}`;
}

function isValidDob(value: string) {
  if (!/^\d{2}\/\d{2}\/\d{4}$/.test(value)) return false;

  const [mm, dd, yyyy] = value.split("/").map(Number);
  const date = new Date(yyyy, mm - 1, dd);

  if (
    date.getFullYear() !== yyyy ||
    date.getMonth() !== mm - 1 ||
    date.getDate() !== dd
  ) {
    return false;
  }

  const now = new Date();
  const minBirthDate = new Date(
    now.getFullYear() - 18,
    now.getMonth(),
    now.getDate()
  );

  return date <= minBirthDate;
}

function normalizeIdentityStatus(value?: string | null) {
  const raw = (value || "").trim().toLowerCase();

  if (raw === "verified") return "verified";
  if (raw === "retry") return "retry";
  if (raw === "document") return "document";
  if (raw === "kba") return "kba";
  if (raw === "suspended") return "suspended";
  if (raw === "deactivated") return "deactivated";
  if (
    raw === "pending" ||
    raw === "review" ||
    raw === "in_review" ||
    raw === "received" ||
    raw === "submitted"
  ) {
    return "pending";
  }

  return "unverified";
}

export default function VerifyIdentity({ navigation }: any) {
  const [userId, setUserId] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);

  const [fullName, setFullName] = useState("");
  const [dob, setDob] = useState("");
  const [address1, setAddress1] = useState("");
  const [address2, setAddress2] = useState("");
  const [city, setCity] = useState("");
  const [stateCode, setStateCode] = useState("");
  const [postalCode, setPostalCode] = useState("");
  const [ssnLast4, setSsnLast4] = useState("");

  const [email, setEmail] = useState<string | null>(null);
  const [phone, setPhone] = useState<string | null>(null);
  const [identityStatus, setIdentityStatus] = useState<string | null>(null);
  const [dwollaCustomerStatus, setDwollaCustomerStatus] = useState<string | null>(null);

  useEffect(() => {
    let active = true;

    async function load() {
      setLoading(true);

      const {
        data: { user },
      } = await supabase.auth.getUser();

      if (!active) return;

      setUserId(user?.id ?? null);

      if (!user?.id) {
        setLoading(false);
        return;
      }

      const { data, error } = await supabase
        .from("profiles")
        .select(`
          id,
          full_name,
          email,
          phone,
          dob,
          address_1,
          address_2,
          city,
          state,
          postal_code,
          ssn_last_4,
          identity_status,
          dwolla_customer_id,
          dwolla_customer_status
        `)
        .eq("id", user.id)
        .single();

      if (!active) return;

      if (error || !data) {
        setEmail(user.email ?? null);
        setLoading(false);
        return;
      }

      const profile = data as ProfileRow;

      setFullName(profile.full_name ?? "");
      setEmail(profile.email ?? user.email ?? null);
      setPhone(profile.phone ?? null);
      setDob(formatDobForInput(profile.dob));
      setAddress1(profile.address_1 ?? "");
      setAddress2(profile.address_2 ?? "");
      setCity(profile.city ?? "");
      setStateCode((profile.state ?? "").toUpperCase());
      setPostalCode(profile.postal_code ?? "");
      setSsnLast4(profile.ssn_last_4 ?? "");
      setIdentityStatus(profile.identity_status ?? null);
      setDwollaCustomerStatus(profile.dwolla_customer_status ?? null);

      setLoading(false);
    }

    void load();

    return () => {
      active = false;
    };
  }, []);

  const normalizedStatus = useMemo(() => {
    return normalizeIdentityStatus(dwollaCustomerStatus || identityStatus);
  }, [dwollaCustomerStatus, identityStatus]);

  const statusUi = useMemo(() => {
    switch (normalizedStatus) {
      case "verified":
        return {
          label: "Identity Verified",
          bg: "#EAF8EA",
          color: GREEN_DARK,
          description: "Your identity is verified and ready for live ACH setup.",
        };
      case "retry":
        return {
          label: "Retry Needed",
          bg: "#FFF7E6",
          color: AMBER,
          description:
            "Dwolla needs corrected identity information. Retry usually needs more complete information.",
        };
      case "document":
        return {
          label: "Document Required",
          bg: "#FFF7E6",
          color: AMBER,
          description:
            "Dwolla needs identity documents before the account can be verified.",
        };
      case "kba":
        return {
          label: "KBA Required",
          bg: "#FFF7E6",
          color: AMBER,
          description:
            "Additional identity verification is required before approval.",
        };
      case "suspended":
        return {
          label: "Suspended",
          bg: "#FDECEC",
          color: RED,
          description:
            "This customer is suspended. That usually needs Dwolla review before proceeding.",
        };
      case "deactivated":
        return {
          label: "Deactivated",
          bg: "#FDECEC",
          color: RED,
          description:
            "This customer is deactivated and cannot continue until reactivated.",
        };
      case "pending":
        return {
          label: "Pending Review",
          bg: "#EEF4FF",
          color: BLUE,
          description: "Identity was submitted and is waiting on review.",
        };
      default:
        return {
          label: "Not Submitted",
          bg: "#FDECEC",
          color: RED,
          description:
            "Submit identity details before enabling real money movement.",
        };
    }
  }, [normalizedStatus]);

  const validation = useMemo(() => {
    return {
      fullName: fullName.trim().length >= 2,
      dob: isValidDob(dob),
      address1: address1.trim().length >= 4,
      city: city.trim().length >= 2,
      stateCode: /^[A-Za-z]{2}$/.test(stateCode.trim()),
      postalCode: /^\d{5}(-\d{4})?$/.test(postalCode.trim()),
      ssnLast4: /^\d{4}$/.test(ssnLast4),
    };
  }, [fullName, dob, address1, city, stateCode, postalCode, ssnLast4]);

  const allValid = useMemo(() => {
    return Object.values(validation).every(Boolean);
  }, [validation]);

  async function submitIdentity() {
    if (!userId) {
      return Alert.alert("Not signed in");
    }

    if (!allValid) {
      return Alert.alert(
        "Missing info",
        "Please complete all identity fields correctly before continuing."
      );
    }

    const dobIso = normalizeDobToIso(dob);
    if (!dobIso) {
      return Alert.alert("Invalid DOB", "Use MM/DD/YYYY");
    }

    setSubmitting(true);

    try {
      const { error: saveError } = await supabase
        .from("profiles")
        .update({
          full_name: fullName.trim(),
          dob: dobIso,
          address_1: address1.trim(),
          address_2: address2.trim() || null,
          city: city.trim(),
          state: stateCode.trim().toUpperCase(),
          postal_code: postalCode.trim(),
          ssn_last_4: ssnLast4.trim(),
          identity_status: "submitted",
        })
        .eq("id", userId);

      if (saveError) {
        throw new Error(saveError.message);
      }

      const { data, error } = await supabase.functions.invoke(
        "create-dwolla-customer",
        { body: {} }
      );

      if (error) {
        throw new Error(error.message || "Function invoke failed");
      }

      const nextStatus =
        data?.identityStatus || data?.dwollaCustomerStatus || "submitted";

      setIdentityStatus(nextStatus);
      setDwollaCustomerStatus(data?.dwollaCustomerStatus || null);

      const normalizedNext = normalizeIdentityStatus(nextStatus);

      if (normalizedNext === "verified") {
        Alert.alert("Verified", "Your identity is verified.", [
          {
            text: "OK",
            onPress: () => navigation.replace("LinkBank"),
          },
        ]);
        return;
      }

      if (normalizedNext === "document") {
        Alert.alert(
          "Document required",
          "Dwolla needs identity documents next. We can add that upload flow next."
        );
        return;
      }

      if (normalizedNext === "retry") {
        Alert.alert(
          "Retry needed",
          "Dwolla needs corrected information. On retry you’ll likely need the full SSN flow next."
        );
        return;
      }

      if (normalizedNext === "pending" || normalizedNext === "kba") {
        Alert.alert(
          "Submitted",
          "Your identity was submitted and may need additional review.",
          [
            {
              text: "OK",
              onPress: () => navigation.replace("LinkBank"),
            },
          ]
        );
        return;
      }

      if (normalizedNext === "suspended" || normalizedNext === "deactivated") {
        Alert.alert(
          "Needs review",
          "This identity status needs manual review before continuing."
        );
        return;
      }

      Alert.alert("Submitted", "Identity information was submitted.", [
        {
          text: "OK",
          onPress: () => navigation.replace("LinkBank"),
        },
      ]);
    } catch (err: any) {
      Alert.alert("Submit failed", err?.message || "Unknown error");
    } finally {
      setSubmitting(false);
    }
  }

  if (loading) {
    return (
      <View style={s.center}>
        <ActivityIndicator />
      </View>
    );
  }

  if (!userId) {
    return (
      <View style={s.center}>
        <Text style={s.emptyTitle}>Not signed in</Text>
        <Text style={s.emptyText}>Sign in first to verify identity.</Text>
      </View>
    );
  }

  return (
    <KeyboardAvoidingView
      behavior={Platform.OS === "ios" ? "padding" : undefined}
      style={s.screen}
    >
      <ScrollView
        contentContainerStyle={s.content}
        showsVerticalScrollIndicator={false}
        keyboardShouldPersistTaps="handled"
      >
        <View style={s.heroCard}>
          <Text style={s.eyebrow}>Compliance</Text>
          <Text style={s.h1}>Verify your identity</Text>
          <Text style={s.heroSub}>
            This is required before live ACH and compliant money movement.
          </Text>

          <View style={s.statusRow}>
            <View style={[s.statusPill, { backgroundColor: statusUi.bg }]}>
              <Text style={[s.statusPillText, { color: statusUi.color }]}>
                {statusUi.label}
              </Text>
            </View>
          </View>

          <Text style={s.statusDescription}>{statusUi.description}</Text>
        </View>

        <View style={s.card}>
          <Text style={s.sectionTitle}>Basic info</Text>

          <Text style={s.label}>Full legal name</Text>
          <TextInput
            style={s.input}
            placeholder="Full legal name"
            value={fullName}
            onChangeText={setFullName}
            autoCapitalize="words"
          />

          <Text style={s.label}>Date of birth</Text>
          <TextInput
            style={s.input}
            placeholder="MM/DD/YYYY"
            value={dob}
            onChangeText={(v) => setDob(formatDobInput(v))}
            keyboardType="number-pad"
            maxLength={10}
          />

          <Text style={s.label}>Email</Text>
          <Text style={s.readOnlyValue}>{email ?? "No email on file"}</Text>

          <Text style={s.label}>Phone</Text>
          <Text style={s.readOnlyValue}>{phone ?? "No phone on file"}</Text>
        </View>

        <View style={s.card}>
          <Text style={s.sectionTitle}>Home address</Text>

          <Text style={s.label}>Address line 1</Text>
          <TextInput
            style={s.input}
            placeholder="Street address"
            value={address1}
            onChangeText={setAddress1}
            autoCapitalize="words"
          />

          <Text style={s.label}>Address line 2</Text>
          <TextInput
            style={s.input}
            placeholder="Apartment, suite, etc. (optional)"
            value={address2}
            onChangeText={setAddress2}
            autoCapitalize="words"
          />

          <Text style={s.label}>City</Text>
          <TextInput
            style={s.input}
            placeholder="City"
            value={city}
            onChangeText={setCity}
            autoCapitalize="words"
          />

          <View style={s.row}>
            <View style={s.colSmall}>
              <Text style={s.label}>State</Text>
              <TextInput
                style={s.input}
                placeholder="MA"
                value={stateCode}
                onChangeText={(v) =>
                  setStateCode(
                    v.replace(/[^a-zA-Z]/g, "").slice(0, 2).toUpperCase()
                  )
                }
                autoCapitalize="characters"
                maxLength={2}
              />
            </View>

            <View style={s.colLarge}>
              <Text style={s.label}>ZIP code</Text>
              <TextInput
                style={s.input}
                placeholder="02150"
                value={postalCode}
                onChangeText={setPostalCode}
                keyboardType="numbers-and-punctuation"
              />
            </View>
          </View>
        </View>

        <View style={s.card}>
          <Text style={s.sectionTitle}>Tax identity</Text>

          <Text style={s.label}>SSN last 4</Text>
          <TextInput
            style={s.input}
            placeholder="Last 4 digits"
            value={ssnLast4}
            onChangeText={(v) => setSsnLast4(formatSsnLast4(v))}
            keyboardType="number-pad"
            secureTextEntry
            maxLength={4}
          />
        </View>

        <TouchableOpacity
          style={[
            s.primaryBtn,
            (!allValid || submitting) && s.primaryBtnDisabled,
          ]}
          onPress={submitIdentity}
          disabled={!allValid || submitting}
          activeOpacity={0.9}
        >
          <Text style={s.primaryBtnText}>
            {submitting ? "Submitting..." : "Submit identity"}
          </Text>
        </TouchableOpacity>

        <TouchableOpacity
          style={s.secondaryBtn}
          onPress={() => navigation.goBack()}
          activeOpacity={0.85}
        >
          <Text style={s.secondaryBtnText}>Back</Text>
        </TouchableOpacity>
      </ScrollView>
    </KeyboardAvoidingView>
  );
}

const s = StyleSheet.create({
  screen: {
    flex: 1,
    backgroundColor: BG,
  },

  content: {
    padding: 16,
    paddingBottom: 28,
  },

  center: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
    padding: 24,
    backgroundColor: BG,
  },

  emptyTitle: {
    fontSize: 22,
    fontWeight: "800",
    color: TEXT,
  },

  emptyText: {
    marginTop: 8,
    fontSize: 15,
    color: SUBTLE,
    textAlign: "center",
  },

  heroCard: {
    backgroundColor: "#fff",
    borderRadius: 16,
    padding: 16,
    marginBottom: 14,
    borderWidth: StyleSheet.hairlineWidth,
    borderColor: BORDER,
  },

  eyebrow: {
    fontSize: 12,
    fontWeight: "800",
    textTransform: "uppercase",
    color: GREEN,
    marginBottom: 6,
    letterSpacing: 0.4,
  },

  h1: {
    fontSize: 26,
    fontWeight: "800",
    color: TEXT,
  },

  heroSub: {
    marginTop: 8,
    fontSize: 15,
    lineHeight: 22,
    color: SUBTLE,
  },

  statusRow: {
    flexDirection: "row",
    marginTop: 14,
  },

  statusPill: {
    borderRadius: 999,
    paddingHorizontal: 10,
    paddingVertical: 6,
  },

  statusPillText: {
    fontSize: 12,
    fontWeight: "800",
  },

  statusDescription: {
    marginTop: 10,
    color: SUBTLE,
    lineHeight: 20,
  },

  card: {
    backgroundColor: "#fff",
    borderRadius: 12,
    padding: 14,
    marginBottom: 14,
    borderWidth: StyleSheet.hairlineWidth,
    borderColor: BORDER,
  },

  sectionTitle: {
    fontSize: 18,
    fontWeight: "800",
    color: TEXT,
    marginBottom: 4,
  },

  label: {
    fontWeight: "800",
    color: "#333",
    marginTop: 12,
    marginBottom: 6,
  },

  input: {
    borderWidth: 1,
    borderColor: BORDER,
    borderRadius: 10,
    paddingHorizontal: 12,
    paddingVertical: 12,
    backgroundColor: "#F9FAFB",
    color: TEXT,
  },

  readOnlyValue: {
    marginTop: 2,
    color: "#444",
    fontSize: 15,
  },

  row: {
    flexDirection: "row",
    gap: 10,
  },

  colSmall: {
    flex: 0.75,
  },

  colLarge: {
    flex: 1.25,
  },

  primaryBtn: {
    marginTop: 2,
    borderRadius: 12,
    paddingVertical: 14,
    alignItems: "center",
    backgroundColor: GREEN,
  },

  primaryBtnDisabled: {
    backgroundColor: "#BFDDBF",
  },

  primaryBtnText: {
    color: "#fff",
    fontWeight: "800",
    fontSize: 15,
  },

  secondaryBtn: {
    marginTop: 10,
    borderRadius: 12,
    paddingVertical: 14,
    alignItems: "center",
    backgroundColor: "#fff",
    borderWidth: 1,
    borderColor: BORDER,
  },

  secondaryBtnText: {
    color: BLUE,
    fontWeight: "800",
    fontSize: 15,
  },
});