// src/screens/ConfirmPayment.tsx

import React, { useCallback, useEffect, useMemo, useState } from 'react';
import {
  View,
  Text,
  Alert,
  StyleSheet,
  TouchableOpacity,
  ActivityIndicator,
  ScrollView,
} from 'react-native';
import { supabase } from '../supabase';

const GREEN = '#77B777';
const GREEN_DARK = '#5F9F5F';
const BLUE = '#3b82f6';
const ORANGE = '#f59e0b';
const RED = '#D9534F';
const BG = '#F5F7F9';

const ON_TIME_REWARD = 7;
const EARLY_REWARD = 27;
const COMPLETION_REWARD = 77;

const currency = (cents: number) => `$${(cents / 100).toFixed(2)}`;

type PaymentContext = {
  payment_number?: number | null;
  due_date?: string | null;
  due_at?: string | null;
  scheduled_at?: string | null;
  iou_title?: string | null;
  total_installments?: number | null;
  status?: string | null;
  paid_at?: string | null;
  payment_method?: string | null;
};

type BankConnectionMeta = {
  linked: boolean;
  providerLabel: string | null;
  accountMask: string | null;
  rawStatus: string | null;
};

type IouPaymentConfig = {
  autopay_enabled?: boolean | null;
};

export default function ConfirmPayment({ route, navigation }: any) {
  const paymentId: string | undefined = route?.params?.paymentId;
  const amount: number = Number(route?.params?.amount ?? 0);
  const iouId: string | undefined =
    route?.params?.iouId ??
    route?.params?.iou_id ??
    route?.params?.loanId ??
    route?.params?.loan_id;

  const [submitting, setSubmitting] = useState(false);
  const [loadingMeta, setLoadingMeta] = useState(true);
  const [loadingBankMeta, setLoadingBankMeta] = useState(true);
  const [loadingIouConfig, setLoadingIouConfig] = useState(true);

  const [paymentMeta, setPaymentMeta] = useState<PaymentContext | null>(null);
  const [bankMeta, setBankMeta] = useState<BankConnectionMeta | null>(null);
  const [iouConfig, setIouConfig] = useState<IouPaymentConfig | null>(null);

  const amountLabel = useMemo(() => currency(amount || 0), [amount]);

  const dueRaw = useMemo(() => {
    return (
      paymentMeta?.due_date ??
      paymentMeta?.due_at ??
      paymentMeta?.scheduled_at ??
      null
    );
  }, [paymentMeta]);

  const dueDateObj = useMemo(() => {
    if (!dueRaw) return null;
    const date = new Date(dueRaw);
    if (Number.isNaN(date.getTime())) return null;
    return date;
  }, [dueRaw]);

  const dueLabel = useMemo(() => {
    if (!dueRaw) return '—';
    if (!dueDateObj) return String(dueRaw).slice(0, 10);
    return dueDateObj.toLocaleDateString();
  }, [dueRaw, dueDateObj]);

  const isFinalPayment = useMemo(() => {
    if (
      typeof paymentMeta?.payment_number === 'number' &&
      typeof paymentMeta?.total_installments === 'number' &&
      paymentMeta.total_installments > 0
    ) {
      return paymentMeta.payment_number >= paymentMeta.total_installments;
    }
    return false;
  }, [paymentMeta]);

  const paymentTiming = useMemo(() => {
    if (!dueDateObj) return 'unknown';

    const now = new Date();
    const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
    const due = new Date(
      dueDateObj.getFullYear(),
      dueDateObj.getMonth(),
      dueDateObj.getDate()
    );

    if (today.getTime() < due.getTime()) return 'early';
    if (today.getTime() === due.getTime()) return 'on_time';
    return 'late';
  }, [dueDateObj]);

  const autopayEnabled = useMemo(() => {
    if (typeof iouConfig?.autopay_enabled === 'boolean') {
      return iouConfig.autopay_enabled;
    }
    return true;
  }, [iouConfig]);

  const isEarlyManualOpportunity = useMemo(() => {
    return paymentTiming === 'early' && !paymentMeta?.paid_at;
  }, [paymentTiming, paymentMeta?.paid_at]);

  const scoreImpactTitle = useMemo(() => {
    return isFinalPayment ? 'Score impact + completion reward' : 'Score impact';
  }, [isFinalPayment]);

  const scoreImpactText = useMemo(() => {
    if (paymentTiming === 'early') {
      if (isFinalPayment) {
        return `If the borrower manually pays early, this payment should earn +${EARLY_REWARD} and the final payoff should also unlock +${COMPLETION_REWARD}.`;
      }
      return `If the borrower manually pays early, this payment should earn +${EARLY_REWARD}.`;
    }

    if (paymentTiming === 'on_time') {
      if (isFinalPayment) {
        return `If the scheduled payment lands on time, this payment should earn +${ON_TIME_REWARD} and final completion should unlock +${COMPLETION_REWARD}.`;
      }
      return `If the scheduled payment lands on time, this payment should earn +${ON_TIME_REWARD}.`;
    }

    if (paymentTiming === 'late') {
      if (isFinalPayment) {
        return `This payment appears late, so it should not earn the timing reward. Final completion should still unlock +${COMPLETION_REWARD} if the loan closes out.`;
      }
      return 'This payment appears late, so it should not earn the early or on-time timing reward.';
    }

    if (isFinalPayment) {
      return `If this closes the loan, the borrower should unlock +${COMPLETION_REWARD}.`;
    }

    return `If this payment lands on time, the borrower should earn +${ON_TIME_REWARD}.`;
  }, [isFinalPayment, paymentTiming]);

  const timingBadgeLabel = useMemo(() => {
    if (paymentTiming === 'early') return 'EARLY WINDOW';
    if (paymentTiming === 'on_time') return 'DUE TODAY';
    if (paymentTiming === 'late') return 'LATE';
    return 'UNKNOWN';
  }, [paymentTiming]);

  const timingBadgeStyle = useMemo(() => {
    if (paymentTiming === 'early') {
      return { backgroundColor: '#EAF8EA', color: GREEN_DARK };
    }
    if (paymentTiming === 'on_time') {
      return { backgroundColor: '#EEF4FF', color: BLUE };
    }
    if (paymentTiming === 'late') {
      return { backgroundColor: '#FFF3E0', color: ORANGE };
    }
    return { backgroundColor: '#EEF2F5', color: '#667085' };
  }, [paymentTiming]);

  const effectiveStatus = useMemo(() => {
    if (paymentMeta?.paid_at) return 'paid';
    return paymentMeta?.status ?? null;
  }, [paymentMeta]);

  const statusBadgeStyle = useMemo(() => {
    if (effectiveStatus === 'paid') {
      return { backgroundColor: '#EAF8EA', color: GREEN_DARK, label: 'PAID' };
    }
    if (effectiveStatus === 'pending_confirmation') {
      return { backgroundColor: '#EEF4FF', color: BLUE, label: 'PENDING' };
    }
    if (effectiveStatus === 'late') {
      return { backgroundColor: '#FFF3E0', color: ORANGE, label: 'LATE' };
    }
    if (effectiveStatus === 'scheduled') {
      return {
        backgroundColor: '#EEF2F5',
        color: '#475467',
        label: 'SCHEDULED',
      };
    }
    return {
      backgroundColor: '#EEF2F5',
      color: '#475467',
      label: (effectiveStatus || 'UNKNOWN').toUpperCase(),
    };
  }, [effectiveStatus]);

  const bankLinked = !!bankMeta?.linked;

  const bankStatusText = useMemo(() => {
    if (loadingBankMeta) return 'Checking bank connection…';

    if (!bankMeta?.linked) {
      return 'No linked bank account found yet.';
    }

    const provider = bankMeta.providerLabel || 'Bank';
    const mask = bankMeta.accountMask ? ` •••• ${bankMeta.accountMask}` : '';
    return `${provider}${mask}`;
  }, [bankMeta, loadingBankMeta]);

  const paymentModeTitle = useMemo(() => {
    if (!autopayEnabled) return 'Manual pay mode';
    if (isEarlyManualOpportunity) return 'AutoPay active + early pay available';
    return 'AutoPay active';
  }, [autopayEnabled, isEarlyManualOpportunity]);

  const paymentModeText = useMemo(() => {
    if (!autopayEnabled) {
      return 'AutoPay is currently off for this loan. Payments must be started manually from a linked bank account.';
    }

    if (isEarlyManualOpportunity) {
      return `AutoPay is on by default, but the borrower can still pay early for the stronger +${EARLY_REWARD} reward path.`;
    }

    return 'AutoPay is on by default for this loan. If the borrower does nothing, the scheduled payment should still be pulled automatically.';
  }, [autopayEnabled, isEarlyManualOpportunity]);

  const settlementPathText = useMemo(() => {
    if (!bankLinked) {
      return 'Bank link required before ACH can start.';
    }

    if (effectiveStatus === 'paid') {
      return 'Completed and confirmed.';
    }

    if (effectiveStatus === 'pending_confirmation') {
      return 'ACH initiated → pending lender confirmation.';
    }

    if (autopayEnabled && isEarlyManualOpportunity) {
      return 'Scheduled for AutoPay, but eligible for early manual ACH.';
    }

    if (autopayEnabled) {
      return 'Scheduled for AutoPay on the due date.';
    }

    return 'Manual ACH must be started by the borrower.';
  }, [bankLinked, effectiveStatus, autopayEnabled, isEarlyManualOpportunity]);

  const readinessChecks = useMemo(() => {
    return [
      { label: 'Payment loaded', pass: !!paymentMeta },
      { label: 'Linked loan found', pass: !!iouId },
      { label: 'Bank connection ready', pass: bankLinked },
      { label: 'AutoPay policy loaded', pass: !loadingIouConfig },
      { label: 'Payment is not already paid', pass: effectiveStatus !== 'paid' },
      {
        label: 'Payment is not already pending confirmation',
        pass: effectiveStatus !== 'pending_confirmation',
      },
    ];
  }, [paymentMeta, iouId, bankLinked, loadingIouConfig, effectiveStatus]);

  const readyCount = readinessChecks.filter((item) => item.pass).length;

  const loadPaymentMeta = useCallback(async () => {
    if (!paymentId) {
      setLoadingMeta(false);
      return;
    }

    setLoadingMeta(true);

    const selects = [
      `
        payment_number,
        due_date,
        status,
        paid_at,
        payment_method,
        ious!payments_iou_id_fkey(
          title,
          total_installments
        )
      `,
      `
        payment_number,
        due_at,
        status,
        paid_at,
        payment_method,
        ious!payments_iou_id_fkey(
          title,
          total_installments
        )
      `,
      `
        payment_number,
        scheduled_at,
        status,
        paid_at,
        payment_method,
        ious!payments_iou_id_fkey(
          title,
          total_installments
        )
      `,
      `
        payment_number,
        due_date,
        status,
        paid_at,
        ious!payments_iou_id_fkey(
          title,
          total_installments
        )
      `,
      `
        payment_number,
        due_at,
        status,
        paid_at,
        ious!payments_iou_id_fkey(
          title,
          total_installments
        )
      `,
      `
        payment_number,
        scheduled_at,
        status,
        paid_at,
        ious!payments_iou_id_fkey(
          title,
          total_installments
        )
      `,
    ];

    for (const sel of selects) {
      const { data, error } = await supabase
        .from('payments')
        .select(sel)
        .eq('id', paymentId)
        .single();

      if (!error && data) {
        setPaymentMeta({
          payment_number: (data as any).payment_number ?? null,
          due_date: (data as any).due_date ?? null,
          due_at: (data as any).due_at ?? null,
          scheduled_at: (data as any).scheduled_at ?? null,
          status: (data as any).status ?? null,
          paid_at: (data as any).paid_at ?? null,
          payment_method: (data as any).payment_method ?? null,
          iou_title: (data as any).ious?.title ?? null,
          total_installments: (data as any).ious?.total_installments ?? null,
        });
        setLoadingMeta(false);
        return;
      }
    }

    setPaymentMeta(null);
    setLoadingMeta(false);
  }, [paymentId]);

  const loadIouConfig = useCallback(async () => {
    if (!iouId) {
      setIouConfig(null);
      setLoadingIouConfig(false);
      return;
    }

    setLoadingIouConfig(true);

    const selects = [
      'autopay_enabled',
      'id',
    ];

    for (const sel of selects) {
      const { data, error } = await supabase
        .from('ious')
        .select(sel)
        .eq('id', iouId)
        .single();

      if (!error && data) {
        setIouConfig({
          autopay_enabled:
            typeof (data as any).autopay_enabled === 'boolean'
              ? (data as any).autopay_enabled
              : true,
        });
        setLoadingIouConfig(false);
        return;
      }
    }

    setIouConfig({ autopay_enabled: true });
    setLoadingIouConfig(false);
  }, [iouId]);

  const loadBankMeta = useCallback(async () => {
    setLoadingBankMeta(true);

    try {
      const { data: auth } = await supabase.auth.getUser();
      const me = auth.user?.id;
      if (!me) {
        setBankMeta(null);
        setLoadingBankMeta(false);
        return;
      }

      const selectAttempts = [
        'bank_linked, bank_provider, bank_account_mask, ach_status',
        'plaid_linked, bank_provider, bank_account_mask, ach_status',
        'bank_linked, plaid_institution_name, bank_account_mask',
        'plaid_linked, plaid_institution_name, account_mask',
      ];

      for (const sel of selectAttempts) {
        const { data, error } = await supabase
          .from('profiles')
          .select(sel)
          .eq('id', me)
          .single();

        if (!error && data) {
          const raw = data as any;

          setBankMeta({
            linked: !!(raw.bank_linked ?? raw.plaid_linked),
            providerLabel:
              raw.bank_provider ?? raw.plaid_institution_name ?? 'Bank',
            accountMask: raw.bank_account_mask ?? raw.account_mask ?? null,
            rawStatus: raw.ach_status ?? null,
          });
          setLoadingBankMeta(false);
          return;
        }
      }

      setBankMeta({
        linked: false,
        providerLabel: null,
        accountMask: null,
        rawStatus: null,
      });
    } catch {
      setBankMeta({
        linked: false,
        providerLabel: null,
        accountMask: null,
        rawStatus: null,
      });
    } finally {
      setLoadingBankMeta(false);
    }
  }, []);

  useEffect(() => {
    void loadPaymentMeta();
    void loadBankMeta();
    void loadIouConfig();
  }, [loadPaymentMeta, loadBankMeta, loadIouConfig]);

  const openFullLoan = () => {
    if (!iouId) {
      Alert.alert('Missing loan', 'No linked IOU contract was found for this payment.');
      return;
    }

    navigation.navigate('PreviewSign', {
      id: iouId,
    });
  };

  const openLoanDetail = () => {
    if (!iouId) {
      Alert.alert('Missing loan', 'No linked IOU detail screen was found for this payment.');
      return;
    }

    navigation.navigate('LoanDetail', {
      iouId,
      iou_id: iouId,
      direction: 'out',
    });
  };

  const openBankLink = () => {
    const state = navigation?.getState?.();
    const routeNames: string[] = Array.isArray(state?.routeNames)
      ? state.routeNames
      : [];

    if (routeNames.includes('LinkBank')) {
      navigation.navigate('LinkBank', { returnTo: 'ConfirmPayment', paymentId, iouId });
      return;
    }

    if (routeNames.includes('BankLink')) {
      navigation.navigate('BankLink', { returnTo: 'ConfirmPayment', paymentId, iouId });
      return;
    }

    Alert.alert(
      'Bank link screen missing',
      'Phase 4 has started here, but the LinkBank screen is not registered yet.'
    );
  };

  const handleEnableAutopay = async () => {
    if (!iouId) {
      Alert.alert('Missing loan', 'This payment is missing its linked loan.');
      return;
    }

    try {
      setSubmitting(true);

      const { error } = await supabase
        .from('ious')
        .update({ autopay_enabled: true })
        .eq('id', iouId);

      if (error) throw error;

      await loadIouConfig();

      Alert.alert(
        'AutoPay enabled',
        'This loan is now set to auto-debit by default.'
      );
    } catch (e: any) {
      Alert.alert('Update failed', e?.message ?? 'Could not enable AutoPay.');
    } finally {
      setSubmitting(false);
    }
  };

  const handleStartManualPayment = async () => {
    if (!paymentId) {
      Alert.alert('Missing payment', 'No payment was provided for this screen.');
      return;
    }

    if (!bankLinked) {
      openBankLink();
      return;
    }

    if (!autopayEnabled) {
      Alert.alert(
        'Manual payment only',
        'AutoPay is currently off, so this payment will be started manually from the linked bank account.'
      );
    }

    if (effectiveStatus === 'paid') {
      Alert.alert('Already paid', 'This payment is already marked as paid.', [
        { text: 'Open loan', onPress: openLoanDetail },
        { text: 'OK' },
      ]);
      return;
    }

    if (effectiveStatus === 'pending_confirmation') {
      Alert.alert(
        'Already pending',
        'This payment has already been started and is waiting for lender confirmation.',
        [{ text: 'Open loan', onPress: openLoanDetail }, { text: 'OK' }]
      );
      return;
    }

    try {
      setSubmitting(true);

      const { data: auth } = await supabase.auth.getUser();
      const me = auth.user?.id;
      if (!me) throw new Error('Missing signed-in user.');

      const { error: paymentMethodError } = await supabase
        .from('payments')
        .update({
          payment_method: 'manual',
          initiated_at: new Date().toISOString(),
        })
        .eq('id', paymentId);

      if (paymentMethodError) {
        // keep going if schema isn't fully there everywhere yet
      }

      const { error } = await supabase.rpc('claim_payment', {
        p_payment_id: paymentId,
        p_actor: me,
      });

      if (error) throw error;

      await loadPaymentMeta();

      Alert.alert(
        isEarlyManualOpportunity ? 'Early payment started' : 'Payment started',
        isEarlyManualOpportunity
          ? `This early manual ACH should preserve the stronger +${EARLY_REWARD} reward path once confirmed.`
          : 'This payment is now pending lender confirmation.',
        [
          {
            text: 'Open loan',
            onPress: () =>
              navigation.replace('LoanDetail', {
                iouId,
                iou_id: iouId,
                direction: 'out',
              }),
          },
        ]
      );
    } catch (e: any) {
      Alert.alert('Payment failed', e?.message ?? 'Could not start payment.');
    } finally {
      setSubmitting(false);
    }
  };

  const primaryButtonLabel = useMemo(() => {
    if (effectiveStatus === 'paid') return 'Already paid';
    if (effectiveStatus === 'pending_confirmation') return 'Already pending';
    if (!bankLinked) return 'Connect bank to continue';
    if (!autopayEnabled) return 'Enable AutoPay';
    if (isEarlyManualOpportunity) return 'Pay early now';
    return 'Start manual payment';
  }, [effectiveStatus, bankLinked, autopayEnabled, isEarlyManualOpportunity]);

  const primaryButtonIsBlue = useMemo(() => {
    return !bankLinked || !autopayEnabled;
  }, [bankLinked, autopayEnabled]);

  const onPrimaryPress = () => {
    if (!bankLinked) {
      openBankLink();
      return;
    }

    if (!autopayEnabled) {
      void handleEnableAutopay();
      return;
    }

    void handleStartManualPayment();
  };

  return (
    <ScrollView
      style={s.screen}
      contentContainerStyle={s.content}
      showsVerticalScrollIndicator={false}
    >
      <View style={s.card}>
        <Text style={s.eyebrow}>Phase 4 payment flow</Text>
        <Text style={s.title}>Confirm payment</Text>
        <Text style={s.subtitle}>
          AutoPay is the default. Early manual ACH is the rewarded option.
        </Text>

        {loadingMeta ? (
          <View style={s.metaLoadingWrap}>
            <ActivityIndicator />
            <Text style={s.metaLoadingText}>Loading payment details…</Text>
          </View>
        ) : (
          <>
            <View style={s.topBadgeRow}>
              <View
                style={[
                  s.badge,
                  { backgroundColor: timingBadgeStyle.backgroundColor },
                ]}
              >
                <Text style={[s.badgeText, { color: timingBadgeStyle.color }]}>
                  {timingBadgeLabel}
                </Text>
              </View>

              <View
                style={[
                  s.badge,
                  { backgroundColor: statusBadgeStyle.backgroundColor },
                ]}
              >
                <Text style={[s.badgeText, { color: statusBadgeStyle.color }]}>
                  {statusBadgeStyle.label}
                </Text>
              </View>
            </View>

            <View style={s.section}>
              <Text style={s.label}>Loan</Text>
              <Text style={s.value}>{paymentMeta?.iou_title || 'Loan'}</Text>
            </View>

            {typeof paymentMeta?.payment_number === 'number' && (
              <View style={s.section}>
                <Text style={s.label}>Payment number</Text>
                <Text style={s.value}>
                  #{paymentMeta.payment_number}
                  {typeof paymentMeta?.total_installments === 'number' &&
                  paymentMeta.total_installments > 0
                    ? ` of ${paymentMeta.total_installments}`
                    : ''}
                </Text>
              </View>
            )}

            <View style={s.section}>
              <Text style={s.label}>Due date</Text>
              <Text style={s.value}>{dueLabel}</Text>
            </View>
          </>
        )}

        <View style={s.section}>
          <Text style={s.label}>Amount</Text>
          <Text style={s.amount}>{amountLabel}</Text>
        </View>

        <View style={s.stateCard}>
          <Text style={s.stateCardTitle}>Payment state</Text>
          <Text style={s.stateCardText}>
            {effectiveStatus === 'paid'
              ? 'This installment is already complete.'
              : effectiveStatus === 'pending_confirmation'
                ? 'This installment has already been started and is waiting for lender confirmation.'
                : 'This screen controls the ACH path for this installment.'}
          </Text>
        </View>

        <View style={s.phase4Card}>
          <Text style={s.phase4CardTitle}>Bank connection</Text>
          <Text style={s.phase4PrimaryText}>{bankStatusText}</Text>
          <Text style={s.phase4SecondaryText}>
            {bankLinked
              ? 'A linked bank account is ready for ACH.'
              : 'Link a bank account before starting any payment.'}
          </Text>

          <TouchableOpacity
            style={[s.inlineBtn, !bankLinked ? s.inlineBtnBlue : s.inlineBtnGray]}
            onPress={openBankLink}
            activeOpacity={0.9}
          >
            <Text
              style={[
                s.inlineBtnText,
                { color: !bankLinked ? '#fff' : '#344054' },
              ]}
            >
              {!bankLinked ? 'Connect bank' : 'Manage bank link'}
            </Text>
          </TouchableOpacity>
        </View>

        <View style={s.phase4Card}>
          <Text style={s.phase4CardTitle}>Payment mode</Text>
          <Text style={s.phase4PrimaryText}>{paymentModeTitle}</Text>
          <Text style={s.phase4SecondaryText}>{paymentModeText}</Text>
        </View>

        <View style={s.phase4Card}>
          <Text style={s.phase4CardTitle}>Settlement path</Text>
          <Text style={s.phase4PrimaryText}>{settlementPathText}</Text>
          <Text style={s.phase4SecondaryText}>
            Flow: bank link → AutoPay by default → optional early manual ACH → lender confirmation → receipt.
          </Text>
        </View>

        <View style={s.readinessCard}>
          <Text style={s.readinessTitle}>Submission readiness</Text>
          <Text style={s.readinessSubtitle}>
            {readyCount} / {readinessChecks.length} checks ready
          </Text>

          <View style={s.checklistWrap}>
            {readinessChecks.map((item) => (
              <View key={item.label} style={s.checkRow}>
                <Text
                  style={[
                    s.checkIcon,
                    item.pass ? s.goodText : s.pendingText,
                  ]}
                >
                  {item.pass ? '✓' : '•'}
                </Text>
                <Text style={s.checkText}>{item.label}</Text>
              </View>
            ))}
          </View>
        </View>

        <View style={s.section}>
          <Text style={s.label}>Linked contract</Text>
          <TouchableOpacity
            style={s.contractBtn}
            onPress={openFullLoan}
            activeOpacity={0.9}
          >
            <Text style={s.contractBtnText}>View IOU contract</Text>
          </TouchableOpacity>
        </View>

        <View style={s.section}>
          <Text style={s.label}>Linked loan detail</Text>
          <TouchableOpacity
            style={s.loanBtn}
            onPress={openLoanDetail}
            activeOpacity={0.9}
          >
            <Text style={s.loanBtnText}>Open loan detail</Text>
          </TouchableOpacity>
        </View>

        <View style={s.section}>
          <Text style={s.label}>Status after action</Text>
          <Text style={s.value}>
            {!bankLinked
              ? 'Awaiting bank link'
              : effectiveStatus === 'paid'
                ? 'Completed'
                : effectiveStatus === 'pending_confirmation'
                  ? 'Pending lender confirmation'
                  : autopayEnabled
                    ? 'AutoPay remains active unless an early manual ACH is started'
                    : 'Manual ACH only until AutoPay is enabled'}
          </Text>
        </View>

        <View style={s.scoreBox}>
          <Text style={s.scoreBoxTitle}>{scoreImpactTitle}</Text>
          <Text style={s.scoreBoxText}>{scoreImpactText}</Text>
        </View>

        <View style={s.noteBox}>
          <Text style={s.noteText}>
            Product rule locked: real bank required, AutoPay by default, manual early pay available as the stronger reward path.
          </Text>
        </View>

        <TouchableOpacity
          style={[
            s.primaryBtn,
            (submitting ||
              effectiveStatus === 'paid' ||
              effectiveStatus === 'pending_confirmation') &&
              s.btnDisabled,
            primaryButtonIsBlue && s.primaryBtnBlue,
          ]}
          onPress={onPrimaryPress}
          disabled={
            submitting ||
            effectiveStatus === 'paid' ||
            effectiveStatus === 'pending_confirmation'
          }
          activeOpacity={0.9}
        >
          {submitting ? (
            <ActivityIndicator color="#fff" />
          ) : (
            <Text style={s.primaryBtnText}>{primaryButtonLabel}</Text>
          )}
        </TouchableOpacity>

        <TouchableOpacity
          style={s.secondaryBtn}
          onPress={() => navigation.goBack()}
          disabled={submitting}
        >
          <Text style={s.secondaryBtnText}>Cancel</Text>
        </TouchableOpacity>
      </View>
    </ScrollView>
  );
}

const s = StyleSheet.create({
  screen: {
    flex: 1,
    backgroundColor: BG,
  },

  content: {
    padding: 16,
    justifyContent: 'center',
    flexGrow: 1,
  },

  card: {
    backgroundColor: '#fff',
    borderRadius: 18,
    padding: 18,
    borderWidth: 1,
    borderColor: '#EAEAEA',
  },

  eyebrow: {
    fontSize: 12,
    fontWeight: '800',
    textTransform: 'uppercase',
    color: GREEN,
    letterSpacing: 0.5,
    marginBottom: 8,
  },

  title: {
    fontSize: 28,
    fontWeight: '800',
    color: '#111',
  },

  subtitle: {
    marginTop: 8,
    color: '#666',
    lineHeight: 21,
  },

  metaLoadingWrap: {
    marginTop: 18,
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 14,
  },

  metaLoadingText: {
    marginTop: 10,
    color: '#666',
  },

  topBadgeRow: {
    flexDirection: 'row',
    gap: 8,
    marginTop: 18,
  },

  badge: {
    borderRadius: 999,
    paddingHorizontal: 10,
    paddingVertical: 6,
    alignSelf: 'flex-start',
  },

  badgeText: {
    fontWeight: '800',
    fontSize: 12,
  },

  section: {
    marginTop: 18,
  },

  label: {
    fontSize: 12,
    fontWeight: '800',
    textTransform: 'uppercase',
    color: '#666',
    marginBottom: 6,
  },

  amount: {
    fontSize: 34,
    fontWeight: '800',
    color: GREEN,
  },

  value: {
    fontSize: 16,
    color: '#111',
  },

  stateCard: {
    marginTop: 18,
    backgroundColor: '#F6F8FA',
    borderWidth: 1,
    borderColor: '#E8EBEF',
    borderRadius: 14,
    padding: 14,
  },

  stateCardTitle: {
    color: '#111',
    fontWeight: '800',
    fontSize: 14,
    marginBottom: 6,
  },

  stateCardText: {
    color: '#4D4D4D',
    lineHeight: 20,
    fontSize: 14,
  },

  phase4Card: {
    marginTop: 18,
    backgroundColor: '#F8FBFF',
    borderWidth: 1,
    borderColor: '#D9E7FF',
    borderRadius: 14,
    padding: 14,
  },

  phase4CardTitle: {
    color: '#1D4ED8',
    fontWeight: '800',
    fontSize: 12,
    textTransform: 'uppercase',
    marginBottom: 8,
  },

  phase4PrimaryText: {
    color: '#111',
    fontSize: 15,
    fontWeight: '800',
  },

  phase4SecondaryText: {
    marginTop: 6,
    color: '#475467',
    lineHeight: 20,
    fontSize: 14,
  },

  inlineBtn: {
    marginTop: 12,
    alignSelf: 'flex-start',
    borderRadius: 12,
    paddingHorizontal: 14,
    paddingVertical: 10,
  },

  inlineBtnBlue: {
    backgroundColor: BLUE,
  },

  inlineBtnGray: {
    backgroundColor: '#EEF2F5',
  },

  inlineBtnText: {
    fontWeight: '800',
    fontSize: 14,
  },

  readinessCard: {
    marginTop: 18,
    backgroundColor: '#F6F8FA',
    borderWidth: 1,
    borderColor: '#E8EBEF',
    borderRadius: 14,
    padding: 14,
  },

  readinessTitle: {
    color: '#111',
    fontWeight: '800',
    fontSize: 14,
    marginBottom: 4,
  },

  readinessSubtitle: {
    color: GREEN_DARK,
    fontWeight: '800',
    fontSize: 13,
    marginBottom: 10,
  },

  checklistWrap: {
    gap: 10,
  },

  checkRow: {
    flexDirection: 'row',
    alignItems: 'center',
  },

  checkIcon: {
    width: 20,
    fontSize: 16,
    fontWeight: '900',
  },

  checkText: {
    color: '#333',
    fontSize: 14,
    fontWeight: '700',
  },

  contractBtn: {
    alignSelf: 'flex-start',
    backgroundColor: '#EEF4FF',
    borderRadius: 12,
    paddingHorizontal: 14,
    paddingVertical: 10,
  },

  contractBtnText: {
    color: BLUE,
    fontWeight: '800',
    fontSize: 14,
  },

  loanBtn: {
    alignSelf: 'flex-start',
    backgroundColor: '#EEF7EE',
    borderRadius: 12,
    paddingHorizontal: 14,
    paddingVertical: 10,
  },

  loanBtnText: {
    color: GREEN_DARK,
    fontWeight: '800',
    fontSize: 14,
  },

  scoreBox: {
    marginTop: 18,
    backgroundColor: '#F1FFF1',
    borderWidth: 1,
    borderColor: '#D8EFD8',
    borderRadius: 14,
    padding: 14,
  },

  scoreBoxTitle: {
    color: '#2E7D32',
    fontWeight: '800',
    fontSize: 12,
    textTransform: 'uppercase',
    marginBottom: 6,
  },

  scoreBoxText: {
    color: '#4D4D4D',
    lineHeight: 20,
    fontSize: 14,
  },

  noteBox: {
    marginTop: 18,
    backgroundColor: '#FFF7ED',
    borderWidth: 1,
    borderColor: '#FED7AA',
    borderRadius: 14,
    padding: 14,
  },

  noteText: {
    color: '#7C2D12',
    lineHeight: 20,
    fontSize: 14,
  },

  primaryBtn: {
    marginTop: 20,
    height: 54,
    borderRadius: 14,
    backgroundColor: GREEN,
    alignItems: 'center',
    justifyContent: 'center',
  },

  primaryBtnBlue: {
    backgroundColor: BLUE,
  },

  btnDisabled: {
    opacity: 0.7,
  },

  primaryBtnText: {
    color: '#fff',
    fontSize: 17,
    fontWeight: '800',
  },

  secondaryBtn: {
    marginTop: 10,
    height: 50,
    borderRadius: 14,
    backgroundColor: '#EEF2F5',
    alignItems: 'center',
    justifyContent: 'center',
  },

  secondaryBtnText: {
    color: '#222',
    fontSize: 16,
    fontWeight: '700',
  },

  goodText: {
    color: '#16a34a',
  },

  pendingText: {
    color: '#b45309',
  },
});