// src/screens/PreviewSign.tsx

import React, { useCallback, useEffect, useMemo, useState } from "react";
import {
  View,
  Text,
  ScrollView,
  ActivityIndicator,
  Alert,
  TouchableOpacity,
  StyleSheet,
  Share,
  TextInput,
  KeyboardAvoidingView,
  Platform,
} from "react-native";
import { supabase } from "../supabase";

type Frequency = "weekly" | "biweekly" | "monthly";

type IouRow = {
  id: string;
  lender_id: string;
  borrower_id: string;
  principal_cents: number;
  apr_bps: number;
  start_date: string | null;
  term_months: number;
  frequency: Frequency;
  status: string;
  title: string | null;
  contract_text: string | null;
  activated_at: string | null;
  exposure_points?: number | null;
};

type ProfileLite = {
  id: string;
  full_name: string | null;
  email: string | null;
};

type BorrowerTrust = {
  iou_score?: number | null;
  active_exposure_points?: number | null;
  strike_count?: number | null;
};

type PaymentPreviewRow = {
  id: string;
  amount_cents: number;
  due: string;
  status: string;
};

const GREEN = "#77B777";
const GREEN_DARK = "#5F9F5F";
const BLUE = "#3B82F6";
const RED = "#D9534F";
const BG = "#F5F7F9";

const currency = (c: number) => `$${(c / 100).toFixed(2)}`;

export default function PreviewSign({ route, navigation }: any) {
  const iouId: string | undefined = route?.params?.id;

  const [meId, setMeId] = useState<string | null>(null);
  const [iou, setIou] = useState<IouRow | null>(null);
  const [lender, setLender] = useState<ProfileLite | null>(null);
  const [borrower, setBorrower] = useState<ProfileLite | null>(null);
  const [borrowerTrust, setBorrowerTrust] = useState<BorrowerTrust | null>(null);
  const [payments, setPayments] = useState<PaymentPreviewRow[]>([]);
  const [loading, setLoading] = useState(true);
  const [activating, setActivating] = useState(false);
  const [sharing, setSharing] = useState(false);
  const [requesting, setRequesting] = useState(false);

  const [signatureName, setSignatureName] = useState("");
  const [agreedToContract, setAgreedToContract] = useState(false);

  const loadPayments = useCallback(async (nextIouId: string) => {
    const selectOptions = [
      "id, amount_cents, status, due_date",
      "id, amount_cents, status, due_at",
      "id, amount_cents, status, scheduled_at",
    ];

    for (const sel of selectOptions) {
      const orderCol = sel.includes("due_date")
        ? "due_date"
        : sel.includes("due_at")
          ? "due_at"
          : "scheduled_at";

      const { data, error } = await supabase
        .from("payments")
        .select(sel)
        .eq("iou_id", nextIouId)
        .order(orderCol as any, { ascending: true });

      if (!error) {
        const normalized = (data ?? []).map((row: any) => ({
          id: row.id,
          amount_cents: row.amount_cents ?? 0,
          status: row.status ?? "scheduled",
          due:
            row.due_date ??
            (typeof row.due_at === "string" ? row.due_at.slice(0, 10) : null) ??
            (typeof row.scheduled_at === "string"
              ? row.scheduled_at.slice(0, 10)
              : null) ??
            "",
        })) as PaymentPreviewRow[];

        setPayments(normalized);
        return;
      }
    }

    setPayments([]);
  }, []);

  const load = useCallback(async () => {
    if (!iouId) return;

    setLoading(true);

    try {
      const { data: authData } = await supabase.auth.getUser();
      const currentUserId = authData.user?.id ?? null;
      setMeId(currentUserId);

      const { data, error } = await supabase
        .from("ious")
        .select("*")
        .eq("id", iouId)
        .single();

      if (error || !data) {
        throw error ?? new Error("IOU not found");
      }

      const row = data as IouRow;
      setIou(row);

      const ids = [row.lender_id, row.borrower_id].filter(Boolean);
      if (ids.length) {
        const { data: profs, error: profError } = await supabase
          .from("profiles")
          .select("id, full_name, email")
          .in("id", ids);

        if (profError) throw profError;

        const map = new Map((profs ?? []).map((p: any) => [p.id, p]));
        const nextLender = map.get(row.lender_id) || null;
        const nextBorrower = map.get(row.borrower_id) || null;

        setLender(nextLender);
        setBorrower(nextBorrower);
      } else {
        setLender(null);
        setBorrower(null);
      }

      setSignatureName("");
      setAgreedToContract(false);

      if (row.borrower_id) {
        const { data: trustData, error: trustError } = await supabase
          .from("profiles")
          .select("iou_score, active_exposure_points, strike_count")
          .eq("id", row.borrower_id)
          .single();

        if (trustError) {
          setBorrowerTrust(null);
        } else {
          setBorrowerTrust(trustData ?? null);
        }
      } else {
        setBorrowerTrust(null);
      }

      await loadPayments(row.id);
    } catch (e: any) {
      Alert.alert("Load failed", e?.message ?? String(e));
    } finally {
      setLoading(false);
    }
  }, [iouId, loadPayments]);

  useEffect(() => {
    void load();
  }, [load]);

  const lenderName = lender?.full_name || lender?.email || "Lender";
  const borrowerName = borrower?.full_name || borrower?.email || "Borrower";

  const isLenderView = !!meId && !!iou && meId === iou.lender_id;
  const isBorrowerView = !!meId && !!iou && meId === iou.borrower_id;

  const humanFrequency = (f: Frequency) =>
    f === "weekly" ? "weekly" : f === "biweekly" ? "every two weeks" : "monthly";

  const contractPreview = useMemo(() => {
    if (!iou) return "";

    const startDate = iou.start_date
      ? new Date(iou.start_date).toLocaleDateString()
      : "the agreed start date";

    const aprPct = (iou.apr_bps / 100).toFixed(2);

    return (
      iou.contract_text ||
      [
        `This IOU is between ${lenderName} ("Lender") and ${borrowerName} ("Borrower").`,
        ``,
        `Principal: ${currency(iou.principal_cents)}`,
        `APR: ${aprPct}%`,
        `Start date: ${startDate}`,
        `Term: ${iou.term_months} month(s)`,
        `Repayment frequency: ${humanFrequency(iou.frequency)}.`,
        ``,
        `Borrower agrees to repay the loan according to the attached payment schedule`,
        `generated inside the IOU app. Payments marked as "paid" in IOU represent`,
        `Borrower’s acknowledgment that such payment was made to Lender.`,
        ``,
        `This agreement is for personal lending between people who know and trust`,
        `each other. IOU LLC is not a party to this agreement and is not responsible`,
        `for enforcing or collecting this debt.`,
      ].join("\n")
    );
  }, [iou, lenderName, borrowerName]);

  const isActivated = !!iou?.activated_at;
  const isPaid = iou?.status === "paid";
  const isLocked = isActivated || isPaid;

  const exposureImpact =
    typeof iou?.exposure_points === "number" && iou.exposure_points > 0
      ? iou.exposure_points
      : 0;

  const borrowerScore =
    typeof borrowerTrust?.iou_score === "number" ? borrowerTrust.iou_score : null;

  const borrowerTrustLabel =
    borrowerScore === null
      ? "No score yet"
      : borrowerScore >= 1000
        ? "Strong"
        : borrowerScore >= 850
          ? "Rising"
          : borrowerScore >= 700
            ? "Starter"
            : "Watch";

  const borrowerTrustColor =
    borrowerScore === null
      ? "#111"
      : borrowerScore >= 1000
        ? GREEN
        : borrowerScore >= 850
          ? BLUE
          : borrowerScore >= 700
            ? "#B7791F"
            : RED;

  const totalScheduled = useMemo(() => {
    return payments.reduce((sum, row) => sum + row.amount_cents, 0);
  }, [payments]);

  const firstDue = payments.length > 0 ? payments[0].due : null;
  const lastDue = payments.length > 0 ? payments[payments.length - 1].due : null;

  const scheduleReadiness = useMemo(() => {
    return [
      {
        label: "Borrower linked",
        pass: !!iou?.borrower_id,
      },
      {
        label: "Contract text ready",
        pass: contractPreview.trim().length > 0,
      },
      {
        label: "Payment schedule generated",
        pass: payments.length > 0,
      },
      {
        label: "Principal matches schedule roughly",
        pass: totalScheduled > 0,
      },
    ];
  }, [iou?.borrower_id, contractPreview, payments.length, totalScheduled]);

  const scheduleReadyCount = scheduleReadiness.filter((i) => i.pass).length;

  const normalizedSignatureName = useMemo(() => {
    return signatureName.replace(/\s+/g, " ").trim();
  }, [signatureName]);

  const signatureLooksLikeEmail = normalizedSignatureName.includes("@");

  const signatureParts = normalizedSignatureName
    .split(" ")
    .map((part) => part.trim())
    .filter(Boolean);

  const signatureReady = useMemo(() => {
    const hasFirstAndLast = signatureParts.length >= 2;
    return agreedToContract && hasFirstAndLast && !signatureLooksLikeEmail;
  }, [agreedToContract, signatureLooksLikeEmail, signatureParts.length]);

  const signatureErrorText = useMemo(() => {
    if (!normalizedSignatureName) return null;
    if (signatureLooksLikeEmail) return "Use your full name, not your email.";
    if (signatureParts.length < 2) return "Enter your full first and last name.";
    return null;
  }, [normalizedSignatureName, signatureLooksLikeEmail, signatureParts.length]);

  const formatActivateError = (err: any) => {
    const raw = err?.message ?? String(err) ?? "Could not activate this IOU.";
    const lower = raw.toLowerCase();

    if (
      lower.includes("maximum number of active loans") ||
      lower.includes("maximum of 10 active loans")
    ) {
      return "This borrower already has 10 active loans and cannot activate another one right now.";
    }

    if (
      lower.includes("maximum allowed exposure") ||
      lower.includes("would exceed max exposure") ||
      lower.includes("would exceed the maximum allowed exposure")
    ) {
      return "Activating this IOU would push the borrower over the current exposure limit.";
    }

    if (lower.includes("borrower is required before activation")) {
      return "Add a borrower before activating this IOU.";
    }

    return raw;
  };

  const openBorrowerProfile = () => {
    if (!iou?.borrower_id) {
      Alert.alert("Missing borrower", "This IOU does not have a borrower profile linked yet.");
      return;
    }

    navigation.navigate("Person", {
      personId: iou.borrower_id,
    });
  };

  const openLoanDetail = () => {
    if (!iouId) return;
    navigation.navigate("LoanDetail", { iouId });
  };

  const onEditSchedule = () => {
    if (!iouId) return;
    navigation.navigate("NewLoan", { id: iouId });
  };

  const onActivate = async () => {
    if (!iou || !iouId) return;

    if (isActivated) {
      Alert.alert("Already active", "This IOU has already been activated.");
      return;
    }

    if (isPaid) {
      Alert.alert("Already paid", "This IOU is already marked as paid.");
      return;
    }

    if (!isLenderView) {
      Alert.alert("Activate blocked", "Only the lender can activate this IOU.");
      return;
    }

    if (payments.length === 0) {
      Alert.alert(
        "Missing schedule",
        "This IOU needs at least one scheduled payment before it can be activated."
      );
      return;
    }

    if (!signatureReady) {
      Alert.alert(
        "Signature required",
        "Enter your full first and last name, then confirm you agree to the contract before activating."
      );
      return;
    }

    Alert.alert(
      "Activate IOU?",
      "This will lock in the schedule and formally activate this IOU.",
      [
        { text: "Cancel", style: "cancel" },
        {
          text: "Activate",
          style: "destructive",
          onPress: async () => {
            try {
              setActivating(true);

              const { error } = await supabase.rpc("activate_iou", {
                p_iou_id: iouId,
                p_contract_text: contractPreview,
              });

              if (error) throw error;

              await load();

              Alert.alert("Activated", "Your IOU is now active.", [
                {
                  text: "View loan",
                  onPress: () => navigation.replace("LoanDetail", { iouId }),
                },
              ]);
            } catch (e: any) {
              Alert.alert("Activate blocked", formatActivateError(e));
            } finally {
              setActivating(false);
            }
          },
        },
      ]
    );
  };

  const onRequestLenderToSign = async () => {
    if (!iou) return;

    if (isActivated) {
      Alert.alert("Already active", "This IOU has already been activated.");
      return;
    }

    if (isPaid) {
      Alert.alert("Already paid", "This IOU is already marked as paid.");
      return;
    }

    if (!isBorrowerView) {
      Alert.alert(
        "Request blocked",
        "Only the borrower can request lender signature from this screen."
      );
      return;
    }

    if (payments.length === 0) {
      Alert.alert(
        "Missing schedule",
        "This IOU needs a payment schedule before you request the lender to sign."
      );
      return;
    }

    if (!signatureReady) {
      Alert.alert(
        "Signature required",
        "Enter your full first and last name, then confirm you agree to the contract before requesting lender signature."
      );
      return;
    }

    setRequesting(true);

    try {
      const aprPct = (iou.apr_bps / 100).toFixed(2);
      const startDate = iou.start_date
        ? new Date(iou.start_date).toLocaleDateString()
        : "TBD";

      const messageLines = [
        `Please review and sign this IOU in the app.`,
        ``,
        `Title: ${iou.title || "Loan"}`,
        `Lender: ${lenderName}`,
        `Borrower: ${borrowerName}`,
        `Principal: ${currency(iou.principal_cents)}`,
        `APR: ${aprPct}%`,
        `Term: ${iou.term_months} month(s)`,
        `Frequency: ${humanFrequency(iou.frequency)}`,
        `Start date: ${startDate}`,
        `Scheduled payments: ${payments.length}`,
        firstDue ? `First due: ${firstDue}` : null,
        lastDue ? `Last due: ${lastDue}` : null,
        ``,
        `Borrower acknowledgment: ${normalizedSignatureName}`,
        `This IOU is ready for lender activation.`,
      ].filter(Boolean);

      await Share.share({
        message: messageLines.join("\n"),
      });

      Alert.alert(
        "Request ready",
        "Your lender signature request was prepared. Once the lender opens this IOU, they can activate it."
      );
    } catch (e: any) {
      Alert.alert("Request failed", e?.message ?? String(e));
    } finally {
      setRequesting(false);
    }
  };

  const onShare = async () => {
    if (!iou) return;

    setSharing(true);

    try {
      const aprPct = (iou.apr_bps / 100).toFixed(2);
      const startDate = iou.start_date
        ? new Date(iou.start_date).toLocaleDateString()
        : "TBD";

      const summaryLines = [
        `IOU Summary: ${iou.title || "Loan"}`,
        ``,
        `Lender: ${lenderName}`,
        `Borrower: ${borrowerName}`,
        ``,
        `Principal: ${currency(iou.principal_cents)}`,
        `APR: ${aprPct}%`,
        `Term: ${iou.term_months} month(s)`,
        `Frequency: ${humanFrequency(iou.frequency)}`,
        `Start date: ${startDate}`,
        `Scheduled payments: ${payments.length}`,
        payments.length > 0 ? `First due: ${firstDue}` : null,
        payments.length > 0 ? `Last due: ${lastDue}` : null,
        ``,
        `We'll track payments in the IOU app and mark them paid as we go.`,
      ].filter(Boolean);

      await Share.share({
        message: summaryLines.join("\n"),
      });
    } catch (e: any) {
      Alert.alert("Share failed", e?.message ?? String(e));
    } finally {
      setSharing(false);
    }
  };

  if (!iouId) {
    return (
      <View style={s.center}>
        <Text>Missing IOU id.</Text>
      </View>
    );
  }

  if (loading || !iou) {
    return (
      <View style={s.center}>
        <ActivityIndicator size="large" color={GREEN} />
      </View>
    );
  }

  const aprPct = (iou.apr_bps / 100).toFixed(2);

  return (
    <KeyboardAvoidingView
      style={s.screen}
      behavior={Platform.OS === "ios" ? "padding" : undefined}
    >
      <ScrollView
        style={s.screen}
        contentContainerStyle={s.content}
        showsVerticalScrollIndicator={false}
        keyboardShouldPersistTaps="handled"
        contentInsetAdjustmentBehavior="automatic"
      >
        <Text style={s.h1}>Preview & Sign</Text>
        <Text style={s.subtitle}>
          Review the key terms before activating this IOU. You can still go back
          and edit the schedule if needed.
        </Text>

        <TouchableOpacity
          activeOpacity={0.92}
          style={s.card}
          onPress={openBorrowerProfile}
        >
          <View style={s.cardHeaderRow}>
            <Text style={s.sectionTitle}>Borrower</Text>
            <Text style={s.inlineLinkText}>View profile →</Text>
          </View>

          <Text style={s.borrowerName}>{borrowerName}</Text>

          <View style={s.borrowerScoreRow}>
            <Text style={s.borrowerScoreLabel}>Trust snapshot</Text>
            <Text style={[s.borrowerScoreValue, { color: borrowerTrustColor }]}>
              {borrowerScore ?? "—"}{" "}
              <Text style={s.borrowerTrustInline}>
                {borrowerScore === null ? "" : `· ${borrowerTrustLabel}`}
              </Text>
            </Text>
          </View>

          <Text style={s.borrowerProfileHint}>
            Open profile for full trust details and relationship history.
          </Text>
        </TouchableOpacity>

        <View style={s.card}>
          <Text style={s.sectionTitle}>Activation readiness</Text>

          <Text style={s.readinessHeadline}>
            {scheduleReadyCount} / {scheduleReadiness.length} checks ready
          </Text>

          <View style={s.checklistWrap}>
            {scheduleReadiness.map((item) => (
              <View key={item.label} style={s.checkRow}>
                <Text
                  style={[
                    s.checkIcon,
                    item.pass ? s.goodText : s.pendingText,
                  ]}
                >
                  {item.pass ? "✓" : "•"}
                </Text>
                <Text style={s.checkText}>{item.label}</Text>
              </View>
            ))}
          </View>
        </View>

        <View style={s.card}>
          <Text style={s.sectionTitle}>Signature</Text>

          <Text style={s.signatureHelpText}>
            {isLenderView
              ? "As lender, type your full legal name and confirm the contract before activation."
              : isBorrowerView
                ? "As borrower, type your full legal name and confirm the contract before requesting lender signature."
                : "Type your full legal name and confirm the contract before continuing."}
          </Text>

          <Text style={s.label}>Typed signature</Text>
          <TextInput
            style={s.signatureInput}
            value={signatureName}
            onChangeText={setSignatureName}
            placeholder="Full legal name (First & Last)"
            placeholderTextColor="#9CA3AF"
            autoCapitalize="words"
            autoCorrect={false}
            textContentType="name"
            returnKeyType="done"
          />

          {!!signatureErrorText && (
            <Text style={s.signatureErrorText}>{signatureErrorText}</Text>
          )}

          <TouchableOpacity
            activeOpacity={0.9}
            style={s.agreeRow}
            onPress={() => setAgreedToContract((prev) => !prev)}
          >
            <View
              style={[
                s.checkbox,
                agreedToContract && s.checkboxChecked,
              ]}
            >
              {agreedToContract && <Text style={s.checkboxCheck}>✓</Text>}
            </View>

            <Text style={s.agreeText}>
              I have reviewed this IOU and agree to the contract terms shown above.
            </Text>
          </TouchableOpacity>

          <View style={s.signatureStatusRow}>
            <Text style={s.signatureStatusLabel}>Signature status</Text>
            <Text
              style={[
                s.signatureStatusValue,
                signatureReady ? s.goodText : s.pendingText,
              ]}
            >
              {signatureReady ? "Ready" : "Missing"}
            </Text>
          </View>
        </View>

        <View style={s.card}>
          <Text style={s.sectionTitle}>Schedule summary</Text>

          <View style={s.summaryRow}>
            <Text style={s.summaryLabel}>Scheduled payments</Text>
            <Text style={s.summaryValue}>{payments.length}</Text>
          </View>

          <View style={s.summaryRow}>
            <Text style={s.summaryLabel}>Total scheduled</Text>
            <Text style={s.summaryValue}>{currency(totalScheduled)}</Text>
          </View>

          <View style={s.summaryRow}>
            <Text style={s.summaryLabel}>First due</Text>
            <Text style={s.summaryValue}>{firstDue || "—"}</Text>
          </View>

          <View style={s.summaryRow}>
            <Text style={s.summaryLabel}>Last due</Text>
            <Text style={s.summaryValue}>{lastDue || "—"}</Text>
          </View>
        </View>

        <View style={s.card}>
          <View style={s.cardHeaderRow}>
            <Text style={s.sectionTitle}>Payment preview</Text>
            {payments.length > 3 && (
              <Text style={s.previewMetaText}>Showing first 3</Text>
            )}
          </View>

          {payments.length === 0 ? (
            <Text style={s.emptyText}>No payment schedule found yet.</Text>
          ) : (
            payments.slice(0, 3).map((payment, index) => (
              <View
                key={payment.id}
                style={[
                  s.paymentPreviewRow,
                  index > 0 && s.paymentPreviewRowBorder,
                ]}
              >
                <View style={{ flex: 1 }}>
                  <Text style={s.paymentPreviewTitle}>
                    Payment {index + 1}
                  </Text>
                  <Text style={s.paymentPreviewMeta}>Due {payment.due || "—"}</Text>
                </View>

                <View style={{ alignItems: "flex-end" }}>
                  <Text style={s.paymentPreviewAmount}>
                    {currency(payment.amount_cents)}
                  </Text>
                  <Text style={s.paymentPreviewStatus}>
                    {(payment.status || "scheduled").toUpperCase()}
                  </Text>
                </View>
              </View>
            ))
          )}
        </View>

        <View style={s.card}>
          <Text style={s.label}>Title</Text>
          <Text style={s.value}>{iou.title || "Loan"}</Text>

          <Text style={s.label}>Lender</Text>
          <Text style={s.value}>{lenderName}</Text>

          <Text style={s.label}>Borrower</Text>
          <TouchableOpacity activeOpacity={0.8} onPress={openBorrowerProfile}>
            <Text style={[s.value, s.linkValue]}>{borrowerName}</Text>
          </TouchableOpacity>

          <TouchableOpacity
            style={s.personBtn}
            onPress={openBorrowerProfile}
            activeOpacity={0.9}
          >
            <Text style={s.personBtnText}>View borrower profile</Text>
          </TouchableOpacity>

          <Text style={s.label}>Principal</Text>
          <Text style={s.value}>{currency(iou.principal_cents)}</Text>

          <Text style={s.label}>APR</Text>
          <Text style={s.value}>{aprPct}%</Text>

          <Text style={s.label}>Term & Frequency</Text>
          <Text style={s.value}>
            {iou.term_months} month(s) · {humanFrequency(iou.frequency)}
          </Text>

          <Text style={s.label}>Activation</Text>
          <Text style={[s.value, isActivated ? s.goodText : s.pendingText]}>
            {isActivated
              ? `Activated on ${new Date(iou.activated_at as string).toLocaleDateString()}`
              : "Not activated yet"}
          </Text>
        </View>

        <View style={s.card}>
          <Text style={s.label}>Contract text</Text>
          <Text style={s.contract}>{contractPreview}</Text>
        </View>

        {isActivated && (
          <TouchableOpacity
            style={s.openLoanBtn}
            onPress={openLoanDetail}
            activeOpacity={0.9}
          >
            <Text style={s.openLoanBtnText}>Open loan detail</Text>
          </TouchableOpacity>
        )}

        <View style={s.actionsRow}>
          <TouchableOpacity
            style={[s.btn, s.btnOutline]}
            onPress={onEditSchedule}
          >
            <Text style={s.btnOutlineTxt}>Edit schedule</Text>
          </TouchableOpacity>

          {isBorrowerView ? (
            <TouchableOpacity
              style={[s.btn, isLocked ? s.btnDisabled : s.btnBorrower]}
              onPress={onRequestLenderToSign}
              disabled={requesting || isLocked}
            >
              <Text style={s.btnTxt}>
                {requesting
                  ? "Requesting..."
                  : isPaid
                    ? "Already paid"
                    : isActivated
                      ? "Already active"
                      : "Request lender to sign"}
              </Text>
            </TouchableOpacity>
          ) : (
            <TouchableOpacity
              style={[s.btn, isLocked ? s.btnDisabled : s.btnPrimary]}
              onPress={onActivate}
              disabled={activating || isLocked}
            >
              <Text style={s.btnTxt}>
                {activating
                  ? "Activating..."
                  : isPaid
                    ? "Already paid"
                    : isActivated
                      ? "Already active"
                      : "Activate IOU"}
              </Text>
            </TouchableOpacity>
          )}
        </View>

        <TouchableOpacity
          style={[s.btn, s.btnShare]}
          onPress={onShare}
          disabled={sharing}
        >
          <Text style={s.btnTxt}>
            {sharing ? "Sharing..." : "Share summary"}
          </Text>
        </TouchableOpacity>

        {!isActivated && !isPaid && (
          <Text style={s.hint}>
            {isBorrowerView
              ? "This IOU has not been formally activated yet. Sign it, then request the lender to review and activate it."
              : "This IOU has not been formally activated yet. Once activated, payments can be managed from the Loan Detail screen."}
          </Text>
        )}

        {isActivated && !isPaid && (
          <Text style={[s.hint, { color: GREEN }]}>
            This IOU is active. Payments can be managed from the Loan Detail screen.
          </Text>
        )}

        {isPaid && (
          <Text style={[s.hint, { color: GREEN }]}>
            This IOU is fully paid. The loan can be archived or exported from the Loan Detail screen.
          </Text>
        )}
      </ScrollView>
    </KeyboardAvoidingView>
  );
}

const s = StyleSheet.create({
  screen: {
    flex: 1,
    backgroundColor: BG,
  },

  content: {
    flexGrow: 1,
    padding: 16,
    paddingBottom: 32,
  },

  center: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
  },

  h1: {
    fontSize: 24,
    fontWeight: "800",
    marginBottom: 6,
  },

  subtitle: {
    color: "#555",
    marginBottom: 12,
  },

  card: {
    backgroundColor: "#fff",
    borderRadius: 12,
    padding: 14,
    marginBottom: 14,
    borderWidth: StyleSheet.hairlineWidth,
    borderColor: "#e5e7eb",
  },

  cardHeaderRow: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    gap: 10,
  },

  sectionTitle: {
    fontSize: 18,
    fontWeight: "800",
    color: "#111",
    marginBottom: 8,
  },

  inlineLinkText: {
    color: BLUE,
    fontWeight: "800",
    fontSize: 13,
  },

  borrowerName: {
    fontSize: 18,
    fontWeight: "800",
    color: "#111",
    marginTop: 2,
  },

  borrowerScoreRow: {
    marginTop: 10,
  },

  borrowerScoreLabel: {
    fontSize: 12,
    fontWeight: "800",
    color: "#667085",
    textTransform: "uppercase",
    marginBottom: 4,
  },

  borrowerScoreValue: {
    fontSize: 28,
    fontWeight: "900",
  },

  borrowerTrustInline: {
    fontSize: 16,
    fontWeight: "800",
    color: "#667085",
  },

  borrowerProfileHint: {
    marginTop: 8,
    color: "#667085",
    fontSize: 13,
    fontWeight: "700",
  },

  readinessHeadline: {
    color: GREEN_DARK,
    fontSize: 15,
    fontWeight: "800",
    marginBottom: 8,
  },

  checklistWrap: {
    gap: 10,
    marginTop: 4,
  },

  checkRow: {
    flexDirection: "row",
    alignItems: "center",
  },

  checkIcon: {
    width: 20,
    fontSize: 16,
    fontWeight: "900",
  },

  checkText: {
    color: "#333",
    fontSize: 14,
    fontWeight: "700",
  },

  signatureHelpText: {
    color: "#555",
    fontSize: 14,
    lineHeight: 20,
    marginBottom: 10,
  },

  signatureInput: {
    borderWidth: 1,
    borderColor: "#D0D5DD",
    borderRadius: 10,
    paddingHorizontal: 12,
    paddingVertical: 12,
    fontSize: 15,
    color: "#111",
    backgroundColor: "#fff",
    marginTop: 6,
  },

  signatureErrorText: {
    marginTop: 8,
    color: RED,
    fontSize: 13,
    fontWeight: "700",
  },

  agreeRow: {
    flexDirection: "row",
    alignItems: "flex-start",
    marginTop: 14,
  },

  checkbox: {
    width: 22,
    height: 22,
    borderRadius: 6,
    borderWidth: 1.5,
    borderColor: "#CBD5E1",
    backgroundColor: "#fff",
    alignItems: "center",
    justifyContent: "center",
    marginRight: 10,
    marginTop: 1,
  },

  checkboxChecked: {
    backgroundColor: GREEN,
    borderColor: GREEN,
  },

  checkboxCheck: {
    color: "#fff",
    fontWeight: "900",
    fontSize: 13,
  },

  agreeText: {
    flex: 1,
    color: "#334155",
    fontSize: 14,
    lineHeight: 20,
    fontWeight: "600",
  },

  signatureStatusRow: {
    marginTop: 14,
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
  },

  signatureStatusLabel: {
    color: "#555",
    fontSize: 14,
    fontWeight: "700",
  },

  signatureStatusValue: {
    fontSize: 14,
    fontWeight: "900",
  },

  summaryRow: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    paddingVertical: 8,
  },

  summaryLabel: {
    color: "#555",
    fontSize: 15,
  },

  summaryValue: {
    color: "#111",
    fontSize: 15,
    fontWeight: "800",
  },

  previewMetaText: {
    color: "#667085",
    fontWeight: "700",
    fontSize: 12,
  },

  paymentPreviewRow: {
    flexDirection: "row",
    alignItems: "center",
    paddingVertical: 12,
  },

  paymentPreviewRowBorder: {
    borderTopWidth: StyleSheet.hairlineWidth,
    borderTopColor: "#E5E7EB",
  },

  paymentPreviewTitle: {
    fontSize: 15,
    fontWeight: "800",
    color: "#111",
  },

  paymentPreviewMeta: {
    marginTop: 3,
    fontSize: 13,
    color: "#666",
  },

  paymentPreviewAmount: {
    fontSize: 15,
    fontWeight: "900",
    color: "#111",
  },

  paymentPreviewStatus: {
    marginTop: 4,
    fontSize: 11,
    fontWeight: "800",
    color: "#667085",
  },

  emptyText: {
    color: "#666",
    marginTop: 4,
  },

  label: {
    fontWeight: "800",
    color: "#333",
    marginTop: 6,
  },

  value: {
    marginTop: 2,
    color: "#111",
  },

  linkValue: {
    color: BLUE,
    fontWeight: "800",
  },

  personBtn: {
    marginTop: 10,
    alignSelf: "flex-start",
    backgroundColor: "#EEF4FF",
    borderRadius: 10,
    paddingHorizontal: 14,
    paddingVertical: 10,
  },

  personBtnText: {
    color: BLUE,
    fontWeight: "800",
    fontSize: 14,
  },

  contract: {
    marginTop: 8,
    color: "#111",
    lineHeight: 20,
  },

  openLoanBtn: {
    marginBottom: 12,
    backgroundColor: "#EEF7EE",
    borderRadius: 12,
    paddingVertical: 12,
    alignItems: "center",
    justifyContent: "center",
  },

  openLoanBtnText: {
    color: GREEN_DARK,
    fontWeight: "800",
    fontSize: 15,
  },

  actionsRow: {
    flexDirection: "row",
    gap: 10,
    marginTop: 4,
    marginBottom: 8,
  },

  btn: {
    flex: 1,
    paddingVertical: 12,
    borderRadius: 10,
    alignItems: "center",
    justifyContent: "center",
  },

  btnPrimary: {
    backgroundColor: GREEN,
  },

  btnBorrower: {
    backgroundColor: BLUE,
  },

  btnDisabled: {
    backgroundColor: "#9ca3af",
  },

  btnOutline: {
    borderWidth: 1,
    borderColor: BLUE,
    backgroundColor: "#fff",
  },

  btnShare: {
    marginTop: 4,
    backgroundColor: RED,
  },

  btnTxt: {
    color: "#fff",
    fontWeight: "800",
  },

  btnOutlineTxt: {
    color: BLUE,
    fontWeight: "800",
  },

  hint: {
    color: "#6b7280",
    marginTop: 4,
  },

  goodText: {
    color: "#16a34a",
  },

  pendingText: {
    color: "#b45309",
  },
});