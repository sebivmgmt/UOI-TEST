// src/screens/Inbox.tsx
import React, {useEffect, useState} from 'react';
import {View, Text, FlatList, TouchableOpacity, Alert, ActivityIndicator} from 'react-native';
import { supabase } from '../supabase';

export default function Inbox({ navigation }: any) {
  const [rows, setRows] = useState<any[]>([]);
  const [me, setMe]   = useState<string|null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    supabase.auth.getUser().then(({data}) => setMe(data.user?.id ?? null));
  }, []);

  useEffect(() => {
    (async () => {
      if (!me) return;
      setLoading(true);
      const { data, error } = await supabase
        .from('ious')
        .select('id,title,principal_cents,borrower_signature,borrower_signed_at')
        .eq('lender_id', me)
        .eq('status', 'pending_lender');
      if (error) Alert.alert('Load failed', error.message);
      setRows(data ?? []);
      setLoading(false);
    })();
  }, [me]);

  const accept = async (id: string) => {
    // Simple: navigate to PreviewSign for lender to add *their* signature
    navigation.navigate('PreviewSign', { id });
  };

  const decline = async (id: string) => {
    const { error } = await supabase.from('ious').update({ status: 'declined' as any }).eq('id', id);
    if (error) return Alert.alert('Decline failed', error.message);
    setRows(r => r.filter(x => x.id !== id));
  };

  if (loading) return <View style={{flex:1,alignItems:'center',justifyContent:'center'}}><ActivityIndicator/></View>;

  return (
    <View style={{ flex:1, padding:16 }}>
      <Text style={{ fontWeight:'800', fontSize:18, marginBottom:12 }}>Pending IOUs</Text>
      <FlatList
        data={rows}
        keyExtractor={i => i.id}
        ItemSeparatorComponent={() => <View style={{height:10}}/>}
        renderItem={({item}) => (
          <View style={{ padding:12, borderWidth:1, borderColor:'#eee', borderRadius:10, backgroundColor:'#fff' }}>
            <Text style={{ fontWeight:'700' }}>{item.title ?? 'IOU'}</Text>
            <Text style={{ color:'#666', marginTop:4 }}>Borrower signed {item.borrower_signed_at ? new Date(item.borrower_signed_at).toLocaleString() : '—'}</Text>
            <View style={{ flexDirection:'row', gap:10, marginTop:10 }}>
              <TouchableOpacity onPress={() => accept(item.id)} style={{ backgroundColor:'#77B777', borderRadius:8, paddingVertical:8, paddingHorizontal:12 }}>
                <Text style={{ color:'#fff', fontWeight:'800' }}>Review & Accept</Text>
              </TouchableOpacity>
              <TouchableOpacity onPress={() => decline(item.id)} style={{ backgroundColor:'#ef4444', borderRadius:8, paddingVertical:8, paddingHorizontal:12 }}>
                <Text style={{ color:'#fff', fontWeight:'800' }}>Decline</Text>
              </TouchableOpacity>
            </View>
          </View>
        )}
      />
    </View>
  );
}