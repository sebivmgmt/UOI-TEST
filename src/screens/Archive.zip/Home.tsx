// src/screens/Home.tsx
import React, {
  useCallback,
  useEffect,
  useLayoutEffect,
  useMemo,
  useState,
  memo,
} from 'react';
import {
  Alert,
  FlatList,
  RefreshControl,
  Text,
  TouchableOpacity,
  View,
  ActivityIndicator,
  StyleSheet,
  Share,
} from 'react-native';
import { useFocusEffect } from '@react-navigation/native';
import Swipeable from 'react-native-gesture-handler/Swipeable';
import { RectButton } from 'react-native-gesture-handler';
import { supabase } from '../supabase';
import { useScreenGuard } from '../dev/useScreenGuard';

const SCREENS = {
  Archived: 'Archived',
  Profile: 'Profile',
  ScoreHistory: 'ScoreHistory',
  NewLoan: 'NewLoan',
  LoanDetail: 'LoanDetail',
  Receipt: 'Receipt',
  VerifyPhone: 'VerifyPhone',
  ConfirmPayment: 'ConfirmPayment',
  PreviewSign: 'PreviewSign',
} as const;

type Props = { navigation: any };
type DueCol = 'due_date' | 'due_at' | 'scheduled_at';

type UpcomingItem = {
  id: string;
  iou_id: string;
  scheduled_at: string;
  paid_at: string | null;
  amount_cents: number;
  title?: string | null;
  direction: 'in' | 'out';
  payment_status: 'scheduled' | 'pending_confirmation' | 'paid' | 'late' | string;
  iou_status?: string | null;
  progress_percent?: number | null;
  paid_installments?: number | null;
  total_installments?: number | null;
};

type ProfileScoreLite = {
  iou_score: number | null;
  active_exposure_points: number | null;
  phone_verified: boolean | null;
};

type ScoreEventLite = {
  id: string;
  event_type: string;
  delta: number;
  description: string | null;
  created_at: string;
};

type IouLite = {
  id: string;
  title: string | null;
  lender_id: string;
  borrower_id: string | null;
  archived_at: string | null;
  deleted_at: string | null;
  status: string | null;
  progress_percent: number | null;
  paid_installments: number | null;
  total_installments: number | null;
};

type PaymentLite = {
  id: string;
  iou_id: string | null;
  status: string | null;
  scheduled_at: string;
  paid_at: string | null;
  amount_cents: number;
};

const IOU_GREEN = '#77B777';
const IOU_GREEN_DARK = '#5F9F5F';
const IOU_GREEN_SOFT = '#E5F3E5';
const IOU_RED_SOFT = '#F9E4E4';
const IOU_RED_DARK = '#D78686';
const BLUE = '#3b82f6';
const ORANGE = '#f59e0b';

const currency = (cents: number) => `$${(cents / 100).toFixed(2)}`;

const isSameDay = (a: Date, b: Date) =>
  a.getFullYear() === b.getFullYear() &&
  a.getMonth() === b.getMonth() &&
  a.getDate() === b.getDate();

const dueBadge = (
  iso: string,
  paid_at: string | null,
  payment_status?: string
) => {
  if (paid_at) return 'paid';
  if (payment_status === 'pending_confirmation') return 'pending';
  const due = new Date(iso);
  const now = new Date();
  if (isSameDay(due, now)) return 'today';
  return due < now ? 'late' : 'due';
};

const badgeColorFor = (badge: string) => {
  if (badge === 'paid') return '#4CAF50';
  if (badge === 'pending') return BLUE;
  if (badge === 'late') return '#E53935';
  if (badge === 'today') return '#0288D1';
  return '#F9A825';
};

const paymentStatusBgFor = (status?: string) => {
  if (status === 'paid') return '#C8E6C9';
  if (status === 'pending_confirmation') return '#BBDEFB';
  if (status === 'late') return '#FFCDD2';
  if (status === 'scheduled') return '#E0E0E0';
  return '#E0E0E0';
};

const sortUpcoming = (items: UpcomingItem[]) => {
  return [...items].sort((a, b) => {
    const aDate = new Date(a.scheduled_at);
    const bDate = new Date(b.scheduled_at);

    const aBadge = dueBadge(a.scheduled_at, a.paid_at, a.payment_status);
    const bBadge = dueBadge(b.scheduled_at, b.paid_at, b.payment_status);

    const rank = (badge: string) => {
      if (badge === 'pending') return 0;
      if (badge === 'late') return 1;
      if (badge === 'today') return 2;
      if (badge === 'due') return 3;
      return 4;
    };

    const rankDiff = rank(aBadge) - rank(bBadge);
    if (rankDiff !== 0) return rankDiff;

    return aDate.getTime() - bDate.getTime();
  });
};

const clampProgress = (value: number) =>
  Math.max(0, Math.min(100, Math.round(value)));

const getProgressPercent = (item: UpcomingItem) => {
  if (typeof item.progress_percent === 'number') {
    return clampProgress(item.progress_percent);
  }

  if (
    typeof item.paid_installments === 'number' &&
    typeof item.total_installments === 'number' &&
    item.total_installments > 0
  ) {
    return clampProgress((item.paid_installments / item.total_installments) * 100);
  }

  return 0;
};

const getProgressLabel = (item: UpcomingItem) => {
  if (
    typeof item.paid_installments === 'number' &&
    typeof item.total_installments === 'number' &&
    item.total_installments > 0
  ) {
    return `${item.paid_installments}/${item.total_installments} paid`;
  }

  return `${getProgressPercent(item)}% complete`;
};

function activeDataSource(
  view: 'in' | 'out',
  incoming: UpcomingItem[],
  outgoing: UpcomingItem[]
) {
  return view === 'out' ? outgoing : incoming;
}

export default function Home({ navigation }: Props) {
  const [userId, setUserId] = useState<string | null>(null);
  const [phoneVerified, setPhoneVerified] = useState<boolean | null>(null);
  const [iouScore, setIouScore] = useState<number>(700);
  const [activeExposurePoints, setActiveExposurePoints] = useState<number>(0);
  const [latestScoreEvent, setLatestScoreEvent] = useState<ScoreEventLite | null>(null);

  const [incoming14, setIncoming14] = useState<UpcomingItem[]>([]);
  const [outgoing14, setOutgoing14] = useState<UpcomingItem[]>([]);
  const [showList, setShowList] = useState<'in' | 'out'>('in');

  const [loading, setLoading] = useState(false);
  const [firstLoad, setFirstLoad] = useState(true);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  useLayoutEffect(() => {
    navigation.setOptions({
      headerLeft: () => (
        <TouchableOpacity
          onPress={() => navigation.navigate(SCREENS.Archived)}
          style={{ marginLeft: 8, padding: 6 }}
        >
          <Text style={{ color: '#fff', fontWeight: '700' }}>Archived</Text>
        </TouchableOpacity>
      ),
      headerRight: () => (
        <TouchableOpacity
          onPress={() => navigation.navigate(SCREENS.Profile)}
          style={{ marginRight: 8, padding: 6 }}
        >
          <Text style={{ color: '#fff', fontWeight: '800' }}>Profile</Text>
        </TouchableOpacity>
      ),
    });
  }, [navigation]);

  useScreenGuard('Home', [
    { label: 'FAB + New IOU present', pass: true },
    { label: 'Header → Archived', pass: !!navigation },
    { label: 'Header → Profile', pass: !!navigation },
    { label: 'Incoming list loaded', pass: Array.isArray(incoming14) },
    { label: 'Outgoing list loaded', pass: Array.isArray(outgoing14) },
  ]);

  useEffect(() => {
    (async () => {
      const { data } = await supabase.auth.getUser();
      setUserId(data.user?.id ?? null);
    })();
  }, []);

  const fetchProfileMeta = useCallback(async () => {
    if (!userId) return;

    const { data, error } = await supabase
      .from('profiles')
      .select('phone_verified, iou_score, active_exposure_points')
      .eq('id', userId)
      .maybeSingle();

    if (!error && data) {
      const row = data as ProfileScoreLite;
      setPhoneVerified(!!row.phone_verified);
      setIouScore(typeof row.iou_score === 'number' ? row.iou_score : 700);
      setActiveExposurePoints(
        typeof row.active_exposure_points === 'number'
          ? row.active_exposure_points
          : 0
      );
    }
  }, [userId]);

  const fetchLatestScoreEvent = useCallback(async () => {
    if (!userId) return;

    const queries = [
      supabase
        .from('score_events')
        .select('id, event_type, delta, description, created_at')
        .eq('user_id', userId)
        .order('created_at', { ascending: false })
        .limit(1)
        .maybeSingle(),
      supabase
        .from('score_history')
        .select('id, event_type, delta, description, created_at')
        .eq('user_id', userId)
        .order('created_at', { ascending: false })
        .limit(1)
        .maybeSingle(),
    ];

    for (const query of queries) {
      const { data, error } = await query;
      if (!error) {
        setLatestScoreEvent((data as ScoreEventLite | null) ?? null);
        return;
      }
    }

    setLatestScoreEvent(null);
  }, [userId]);

  useEffect(() => {
    void fetchProfileMeta();
    void fetchLatestScoreEvent();
  }, [fetchProfileMeta, fetchLatestScoreEvent]);

  const scoreTier = useMemo(() => {
    if (iouScore >= 1400) return 'Lending';
    if (iouScore >= 1000) return 'Strong';
    if (iouScore >= 800) return 'Rising';
    if (iouScore >= 700) return 'Starter';
    if (iouScore >= 500) return 'Watch';
    return 'Critical';
  }, [iouScore]);

  const visibleTrustScore = Math.max(0, iouScore - activeExposurePoints);

  const latestScoreEventLabel = useMemo(() => {
    if (!latestScoreEvent) return 'No recent score activity yet';

    const titleMap: Record<string, string> = {
      payment_on_time: 'On-time payment',
      payment_early: 'Early payment',
      payment_late: 'Late payment',
      loan_completion: 'Loan completed',
      exposure_removed: 'Exposure removed',
      strike_1: 'Strike 1',
      strike_2: 'Strike 2',
      strike_3: 'Strike 3',
    };

    const title =
      titleMap[latestScoreEvent.event_type] ??
      latestScoreEvent.event_type.replace(/_/g, ' ');

    const delta =
      latestScoreEvent.delta > 0
        ? `+${latestScoreEvent.delta}`
        : `${latestScoreEvent.delta}`;

    return `${delta} • ${title}`;
  }, [latestScoreEvent]);

  const scoreMovementLabel = useMemo(() => {
    if (activeExposurePoints <= 0) {
      return 'No active exposure is dragging your visible trust right now.';
    }

    return `Active loans are temporarily moving visible trust from ${iouScore} to ${visibleTrustScore}.`;
  }, [activeExposurePoints, iouScore, visibleTrustScore]);

  const exposureSummaryLabel = useMemo(() => {
    if (activeExposurePoints <= 0) {
      return 'No temporary exposure';
    }

    if (activeExposurePoints === 1) {
      return '1 temporary exposure point active';
    }

    return `${activeExposurePoints} temporary exposure points active`;
  }, [activeExposurePoints]);

  const inTotal = useMemo(
    () => incoming14.reduce((s, r) => s + r.amount_cents, 0),
    [incoming14]
  );

  const outTotal = useMemo(
    () => outgoing14.reduce((s, r) => s + r.amount_cents, 0),
    [outgoing14]
  );

  const today = new Date();

  const inToday = useMemo(
    () =>
      incoming14.filter(
        (i) =>
          !i.paid_at &&
          i.payment_status !== 'pending_confirmation' &&
          isSameDay(new Date(i.scheduled_at), today)
      ).length,
    [incoming14, today]
  );

  const outToday = useMemo(
    () =>
      outgoing14.filter(
        (i) =>
          !i.paid_at &&
          i.payment_status !== 'pending_confirmation' &&
          isSameDay(new Date(i.scheduled_at), today)
      ).length,
    [outgoing14, today]
  );

  const inLate = useMemo(
    () =>
      incoming14.filter(
        (i) =>
          !i.paid_at &&
          i.payment_status !== 'pending_confirmation' &&
          new Date(i.scheduled_at) < today
      ).length,
    [incoming14, today]
  );

  const outLate = useMemo(
    () =>
      outgoing14.filter(
        (i) =>
          !i.paid_at &&
          i.payment_status !== 'pending_confirmation' &&
          new Date(i.scheduled_at) < today
      ).length,
    [outgoing14, today]
  );

  const pendingIncomingCount = useMemo(
    () =>
      incoming14.filter(
        (i) => !i.paid_at && i.payment_status === 'pending_confirmation'
      ).length,
    [incoming14]
  );

  const pendingOutgoingCount = useMemo(
    () =>
      outgoing14.filter(
        (i) => !i.paid_at && i.payment_status === 'pending_confirmation'
      ).length,
    [outgoing14]
  );

  const dueSoonCount = useMemo(
    () =>
      activeDataSource(showList, incoming14, outgoing14).filter((i) => {
        const badge = dueBadge(i.scheduled_at, i.paid_at, i.payment_status);
        return badge === 'today' || badge === 'due';
      }).length,
    [showList, incoming14, outgoing14]
  );

  const fetchScopedIous = useCallback(
    async (role: 'lender' | 'borrower') => {
      if (!userId) {
        return {
          data: [] as IouLite[],
          error: null as { message?: string } | null,
        };
      }

      const roleColumn = role === 'lender' ? 'lender_id' : 'borrower_id';

      return await supabase
        .from('ious')
        .select(
          `
            id,
            title,
            lender_id,
            borrower_id,
            archived_at,
            deleted_at,
            status,
            progress_percent,
            paid_installments,
            total_installments
          `
        )
        .eq(roleColumn, userId)
        .is('archived_at', null)
        .is('deleted_at', null);
    },
    [userId]
  );

  const fetchPaymentsByIouIds = useCallback(
    async (dueCol: DueCol, iouIds: string[]) => {
      if (!iouIds.length) {
        return {
          data: [] as PaymentLite[],
          error: null as { message?: string } | null,
        };
      }

      const from = new Date();
      const to = new Date();
      to.setDate(to.getDate() + 14);

      return await supabase
        .from('payments')
        .select(
          `
            id,
            iou_id,
            status,
            scheduled_at:${dueCol},
            paid_at,
            amount_cents
          `
        )
        .in('iou_id', iouIds)
        .gte(dueCol, from.toISOString())
        .lt(dueCol, to.toISOString())
        .order(dueCol, { ascending: true });
    },
    []
  );

  const buildUpcomingItems = useCallback(
    (
      payments: PaymentLite[],
      iouMap: Record<string, IouLite>,
      direction: 'in' | 'out'
    ): UpcomingItem[] => {
      const items: UpcomingItem[] = payments
        .filter((p) => !!p.iou_id && !!p.scheduled_at)
        .map((p) => {
          const iou = p.iou_id ? iouMap[p.iou_id] : undefined;

          return {
            id: p.id,
            iou_id: p.iou_id ?? '',
            scheduled_at: p.scheduled_at,
            paid_at: p.paid_at,
            amount_cents: p.amount_cents,
            title: iou?.title ?? null,
            direction,
            payment_status: p.status ?? 'scheduled',
            iou_status: iou?.status ?? 'draft',
            progress_percent:
              typeof iou?.progress_percent === 'number'
                ? iou.progress_percent
                : null,
            paid_installments:
              typeof iou?.paid_installments === 'number'
                ? iou.paid_installments
                : null,
            total_installments:
              typeof iou?.total_installments === 'number'
                ? iou.total_installments
                : null,
          };
        })
        .filter((item) => !!item.iou_id);

      return sortUpcoming(items);
    },
    []
  );

  const fetchUpcoming = useCallback(async () => {
    if (!userId) return;

    setLoading(true);
    setErrorMsg(null);

    const [incomingIousRes, outgoingIousRes] = await Promise.all([
      fetchScopedIous('lender'),
      fetchScopedIous('borrower'),
    ]);

    if (incomingIousRes.error || outgoingIousRes.error) {
      setErrorMsg(
        incomingIousRes.error?.message ||
          outgoingIousRes.error?.message ||
          'Failed to load IOUs.'
      );
      setIncoming14([]);
      setOutgoing14([]);
      setFirstLoad(false);
      setLoading(false);
      return;
    }

    const incomingIous = (incomingIousRes.data ?? []) as IouLite[];
    const outgoingIous = (outgoingIousRes.data ?? []) as IouLite[];

    const incomingIouIds = incomingIous.map((row) => row.id);
    const outgoingIouIds = outgoingIous.map((row) => row.id);

    const incomingIouMap: Record<string, IouLite> = Object.fromEntries(
      incomingIous.map((row) => [row.id, row])
    );

    const outgoingIouMap: Record<string, IouLite> = Object.fromEntries(
      outgoingIous.map((row) => [row.id, row])
    );

    const cols: DueCol[] = ['due_date', 'due_at', 'scheduled_at'];
    let lastErr: string | null = null;

    for (const col of cols) {
      const [inPaymentsRes, outPaymentsRes] = await Promise.all([
        fetchPaymentsByIouIds(col, incomingIouIds),
        fetchPaymentsByIouIds(col, outgoingIouIds),
      ]);

      if (!inPaymentsRes.error && !outPaymentsRes.error) {
        const safeIn = buildUpcomingItems(
          (inPaymentsRes.data ?? []) as PaymentLite[],
          incomingIouMap,
          'in'
        );

        const safeOut = buildUpcomingItems(
          (outPaymentsRes.data ?? []) as PaymentLite[],
          outgoingIouMap,
          'out'
        );

        setIncoming14(safeIn);
        setOutgoing14(safeOut);
        setFirstLoad(false);
        setLoading(false);
        return;
      }

      lastErr =
        inPaymentsRes.error?.message ||
        outPaymentsRes.error?.message ||
        'Unknown error';
    }

    setErrorMsg(lastErr ?? 'Failed to load payments.');
    setIncoming14([]);
    setOutgoing14([]);
    setFirstLoad(false);
    setLoading(false);
  }, [userId, fetchScopedIous, fetchPaymentsByIouIds, buildUpcomingItems]);

  useFocusEffect(
    useCallback(() => {
      void fetchUpcoming();
      void fetchProfileMeta();
      void fetchLatestScoreEvent();
    }, [fetchUpcoming, fetchProfileMeta, fetchLatestScoreEvent])
  );

  useEffect(() => {
    const paymentsChannel = supabase
      .channel('home-payments')
      .on(
        'postgres_changes',
        { event: '*', schema: 'public', table: 'payments' },
        () => {
          void fetchUpcoming();
          void fetchProfileMeta();
          void fetchLatestScoreEvent();
        }
      )
      .subscribe();

    const profilesChannel = userId
      ? supabase
          .channel(`home-profile-${userId}`)
          .on(
            'postgres_changes',
            {
              event: '*',
              schema: 'public',
              table: 'profiles',
              filter: `id=eq.${userId}`,
            },
            () => {
              void fetchProfileMeta();
            }
          )
          .subscribe()
      : null;

    const scoreEventsChannel = userId
      ? supabase
          .channel(`home-score-events-${userId}`)
          .on(
            'postgres_changes',
            {
              event: '*',
              schema: 'public',
              table: 'score_events',
              filter: `user_id=eq.${userId}`,
            },
            () => {
              void fetchProfileMeta();
              void fetchLatestScoreEvent();
            }
          )
          .subscribe()
      : null;

    return () => {
      supabase.removeChannel(paymentsChannel);
      if (profilesChannel) supabase.removeChannel(profilesChannel);
      if (scoreEventsChannel) supabase.removeChannel(scoreEventsChannel);
    };
  }, [fetchUpcoming, fetchProfileMeta, fetchLatestScoreEvent, userId]);

  const startPaymentFlow = (item: UpcomingItem) => {
    navigation.navigate(SCREENS.ConfirmPayment, {
      paymentId: item.id,
      amount: item.amount_cents,
      iouId: item.iou_id,
      iou_id: item.iou_id,
      loanId: item.iou_id,
      loan_id: item.iou_id,
    });
  };

  const sendReminder = async (item: UpcomingItem) => {
    try {
      const title = item.title || 'Loan';
      const amount = currency(item.amount_cents);
      const due = new Date(item.scheduled_at).toLocaleDateString();

      await Share.share({
        message: `Reminder: ${title} payment of ${amount} is due ${due} in IOU.`,
      });
    } catch (e: any) {
      Alert.alert('Reminder failed', e.message ?? 'Could not open share sheet.');
    }
  };

  const openFullLoan = (item: UpcomingItem) => {
    navigation.navigate(SCREENS.PreviewSign, {
      id: item.iou_id,
    });
  };

  const openIncomingItem = (item: UpcomingItem) => {
    if (item.paid_at) {
      navigation.navigate(SCREENS.Receipt, {
        paymentId: item.id,
        iouId: item.iou_id,
      });
      return;
    }

    if (item.payment_status === 'pending_confirmation') {
      navigation.navigate(SCREENS.LoanDetail, {
        iouId: item.iou_id,
        direction: 'in',
      });
      return;
    }

    const due = new Date(item.scheduled_at).toLocaleDateString();
    const amount = currency(item.amount_cents);
    const title = item.title || 'Loan';

    Alert.alert(
      title,
      `${amount} due ${due}\n\nStatus: ${(item.payment_status || 'scheduled').toUpperCase()}`,
      [
        { text: 'Close', style: 'cancel' },
        {
          text: 'Remind borrower',
          onPress: () => {
            void sendReminder(item);
          },
        },
        {
          text: 'View full loan',
          onPress: () => openFullLoan(item),
        },
      ]
    );
  };

  const openOutgoingItem = (item: UpcomingItem) => {
    if (item.paid_at) {
      navigation.navigate(SCREENS.Receipt, {
        paymentId: item.id,
        iouId: item.iou_id,
      });
      return;
    }

    startPaymentFlow(item);
  };

  const openPayment = (item: UpcomingItem) => {
    if (!item.iou_id) {
      Alert.alert('Error', 'This payment is missing its IOU id.');
      return;
    }

    if (item.direction === 'in') {
      openIncomingItem(item);
      return;
    }

    openOutgoingItem(item);
  };

  const activeData = showList === 'out' ? outgoing14 : incoming14;
  const nextItem = activeData.length > 0 ? activeData[0] : null;

  const summaryLabel = useMemo(() => {
    if (showList === 'out') {
      if (pendingOutgoingCount > 0) {
        return `${pendingOutgoingCount} pending confirmation`;
      }
      if (dueSoonCount > 0) {
        return `${dueSoonCount} due soon`;
      }
      if (outLate > 0) {
        return `${outLate} late`;
      }
      return 'No urgent outgoing actions';
    }

    if (pendingIncomingCount > 0) {
      return `${pendingIncomingCount} waiting for your confirmation`;
    }
    if (dueSoonCount > 0) {
      return `${dueSoonCount} incoming due soon`;
    }
    if (inLate > 0) {
      return `${inLate} incoming late`;
    }
    return 'No urgent incoming actions';
  }, [
    showList,
    pendingOutgoingCount,
    pendingIncomingCount,
    dueSoonCount,
    outLate,
    inLate,
  ]);

  const ScoreHero = memo(function ScoreHero() {
    return (
      <TouchableOpacity
        activeOpacity={0.92}
        onPress={() => navigation.navigate(SCREENS.ScoreHistory)}
        style={styles.scoreHero}
      >
        <View style={styles.scoreHeroTop}>
          <View style={styles.scoreHeroCopy}>
            <Text style={styles.scoreHeroEyebrow}>IOU Score</Text>
            <Text style={styles.scoreHeroValue}>{iouScore}</Text>
            <Text style={styles.scoreHeroSubtext}>
              Tap to open your full score breakdown
            </Text>
          </View>

          <View style={styles.scoreTierPill}>
            <Text style={styles.scoreTierText}>{scoreTier}</Text>
          </View>
        </View>

        <View style={styles.scoreMetricsRow}>
          <View style={styles.scoreMetricPill}>
            <Text style={styles.scoreMetricLabel}>Visible Trust</Text>
            <Text style={styles.scoreMetricValue}>{visibleTrustScore}</Text>
          </View>

          <View style={styles.scoreMetricPill}>
            <Text style={styles.scoreMetricLabel}>Active Exposure</Text>
            <Text
              style={[
                styles.scoreMetricValue,
                activeExposurePoints > 0
                  ? styles.scoreMetricValuePending
                  : styles.scoreMetricValueGood,
              ]}
            >
              {activeExposurePoints > 0 ? `-${activeExposurePoints}` : '0'}
            </Text>
          </View>
        </View>

        <View style={styles.scoreMovementCard}>
          <Text style={styles.scoreMovementLabel}>Trust movement</Text>
          <Text style={styles.scoreMovementValue}>{scoreMovementLabel}</Text>
          <Text style={styles.scoreMovementSubvalue}>{exposureSummaryLabel}</Text>
        </View>

        <View style={styles.scoreActivityStrip}>
          <Text style={styles.scoreActivityLabel}>Recent score activity</Text>
          <Text style={styles.scoreActivityValue}>{latestScoreEventLabel}</Text>
        </View>
      </TouchableOpacity>
    );
  });

  const StatCard = memo(function StatCard({
    label,
    total,
    todayCount,
    lateCount,
    active,
    onPress,
    bg,
    activeBg,
    border,
  }: {
    label: string;
    total: number;
    todayCount: number;
    lateCount: number;
    active: boolean;
    onPress: () => void;
    bg: string;
    activeBg: string;
    border: string;
  }) {
    return (
      <TouchableOpacity
        onPress={onPress}
        activeOpacity={0.9}
        style={[
          styles.statCard,
          active
            ? [
                styles.statCardActive,
                {
                  borderColor: border,
                  backgroundColor: activeBg,
                },
              ]
            : {
                borderColor: 'transparent',
                backgroundColor: bg,
              },
        ]}
      >
        <Text style={[styles.statLabel, active && styles.statLabelActive]}>
          {label}
        </Text>
        <Text style={[styles.statValue, active && styles.statValueActive]}>
          {currency(total)}
        </Text>
        <Text style={[styles.statMeta, active && styles.statMetaActive]}>
          Today: {todayCount} • Late: {lateCount}
        </Text>
      </TouchableOpacity>
    );
  });

  const NextUpActions = memo(function NextUpActions({
    item,
  }: {
    item: UpcomingItem;
  }) {
    if (item.paid_at) {
      return (
        <View style={styles.nextActionsRow}>
          <TouchableOpacity
            style={[styles.nextActionBtn, styles.nextActionNeutral]}
            onPress={() =>
              navigation.navigate(SCREENS.Receipt, {
                paymentId: item.id,
                iouId: item.iou_id,
              })
            }
          >
            <Text style={[styles.nextActionText, styles.nextActionTextDark]}>
              View receipt
            </Text>
          </TouchableOpacity>
        </View>
      );
    }

    if (item.direction === 'out') {
      return (
        <View style={styles.nextActionsRow}>
          <TouchableOpacity
            style={[styles.nextActionBtn, styles.nextActionBlue]}
            onPress={() => openFullLoan(item)}
          >
            <Text style={styles.nextActionText}>View full loan</Text>
          </TouchableOpacity>

          <TouchableOpacity
            style={[styles.nextActionBtn, styles.nextActionGreen]}
            onPress={() => startPaymentFlow(item)}
          >
            <Text style={styles.nextActionText}>Pay now</Text>
          </TouchableOpacity>
        </View>
      );
    }

    if (item.payment_status === 'pending_confirmation') {
      return (
        <View style={styles.nextActionsRow}>
          <TouchableOpacity
            style={[styles.nextActionBtn, styles.nextActionBlue]}
            onPress={() => openFullLoan(item)}
          >
            <Text style={styles.nextActionText}>View full loan</Text>
          </TouchableOpacity>

          <TouchableOpacity
            style={[styles.nextActionBtn, styles.nextActionConfirm]}
            onPress={() =>
              navigation.navigate(SCREENS.LoanDetail, {
                iouId: item.iou_id,
                direction: 'in',
              })
            }
          >
            <Text style={styles.nextActionText}>Confirm</Text>
          </TouchableOpacity>
        </View>
      );
    }

    return (
      <View style={styles.nextActionsRow}>
        <TouchableOpacity
          style={[styles.nextActionBtn, styles.nextActionBlue]}
          onPress={() => openFullLoan(item)}
        >
          <Text style={styles.nextActionText}>View full loan</Text>
        </TouchableOpacity>

        <TouchableOpacity
          style={[styles.nextActionBtn, styles.nextActionOrange]}
          onPress={() => {
            void sendReminder(item);
          }}
        >
          <Text style={styles.nextActionText}>Remind</Text>
        </TouchableOpacity>
      </View>
    );
  });

  const NextUpCard = memo(function NextUpCard({ item }: { item: UpcomingItem }) {
    const badge = dueBadge(item.scheduled_at, item.paid_at, item.payment_status);
    const badgeColor = badgeColorFor(badge);
    const progressPercent = getProgressPercent(item);

    return (
      <View style={styles.nextCard}>
        <View style={styles.nextHeader}>
          <Text style={styles.nextEyebrow}>
            {showList === 'in' ? 'Next incoming' : 'Next outgoing'}
          </Text>
          <View style={[styles.badge, { backgroundColor: badgeColor }]}>
            <Text style={styles.badgeText}>{badge.toUpperCase()}</Text>
          </View>
        </View>

        <Text style={styles.nextTitle}>{item.title || 'Loan'}</Text>

        <View style={styles.nextMetaRow}>
          <Text style={styles.nextAmount}>{currency(item.amount_cents)}</Text>
          <Text style={styles.nextDate}>
            Due {new Date(item.scheduled_at).toLocaleDateString()}
          </Text>
        </View>

        <View style={styles.progressSection}>
          <View style={styles.progressHeaderRow}>
            <Text style={styles.progressLabel}>Progress</Text>
            <Text style={styles.progressValue}>{progressPercent}%</Text>
          </View>
          <View style={styles.progressTrack}>
            <View
              style={[
                styles.progressFill,
                { width: `${Math.max(0, Math.min(100, progressPercent))}%` },
              ]}
            />
          </View>
          <Text style={styles.progressSubtext}>{getProgressLabel(item)}</Text>
        </View>

        <NextUpActions item={item} />
      </View>
    );
  });

  const HeaderContent = memo(function HeaderContent() {
    return (
      <>
        {phoneVerified === false && (
          <TouchableOpacity
            onPress={() => navigation.navigate(SCREENS.VerifyPhone)}
            style={styles.verifyBanner}
            activeOpacity={0.9}
          >
            <Text style={styles.verifyTitle}>Verify your phone</Text>
            <Text style={styles.verifyText}>
              You’ll need to verify your phone before creating new IOUs. Tap to verify →
            </Text>
          </TouchableOpacity>
        )}

        <View style={styles.topSection}>
          <ScoreHero />

          <View style={styles.statRow}>
            <StatCard
              label="Incoming (14d)"
              total={inTotal}
              todayCount={inToday}
              lateCount={inLate}
              active={showList === 'in'}
              onPress={() => setShowList('in')}
              bg={IOU_GREEN_SOFT}
              activeBg="#CFE8CF"
              border={IOU_GREEN_DARK}
            />
            <View style={{ width: 8 }} />
            <StatCard
              label="Outgoing (14d)"
              total={outTotal}
              todayCount={outToday}
              lateCount={outLate}
              active={showList === 'out'}
              onPress={() => setShowList('out')}
              bg={IOU_RED_SOFT}
              activeBg="#F1D0D0"
              border={IOU_RED_DARK}
            />
          </View>
        </View>

        <View style={styles.summaryStrip}>
          <Text style={styles.summaryStripText}>{summaryLabel}</Text>
        </View>

        {nextItem && (
          <View style={styles.headerNextUpWrap}>
            <NextUpCard item={nextItem} />
          </View>
        )}

        {errorMsg && (
          <View style={styles.errorBanner}>
            <Text style={styles.errorTitle}>Couldn’t load payments</Text>
            <Text style={styles.errorText}>{errorMsg}</Text>
          </View>
        )}
      </>
    );
  });

  const Row = memo(function Row({ item }: { item: UpcomingItem }) {
    const badge = dueBadge(item.scheduled_at, item.paid_at, item.payment_status);
    const isToday = badge === 'today';
    const badgeColor = badgeColorFor(badge);
    const progressPercent = getProgressPercent(item);

    const dirBg = item.direction === 'in' ? '#DDEEDD' : '#F7DDDD';
    const dirColor = item.direction === 'in' ? '#2E7D32' : '#B42318';

    const canPay =
      item.direction === 'out' &&
      !item.paid_at &&
      (item.payment_status === 'scheduled' || item.payment_status === 'late');

    const canRemind =
      item.direction === 'in' &&
      !item.paid_at &&
      item.payment_status !== 'pending_confirmation';

    const canConfirm =
      item.direction === 'in' &&
      !item.paid_at &&
      item.payment_status === 'pending_confirmation';

    const leftActions = () => {
      if (item.paid_at) return <View />;

      return (
        <RectButton onPress={() => openFullLoan(item)} style={styles.leftAction}>
          <Text style={styles.sideActionText}>Full loan</Text>
        </RectButton>
      );
    };

    const rightActions = () => {
      if (canPay) {
        return (
          <RectButton
            onPress={() => startPaymentFlow(item)}
            style={styles.rightActionPay}
          >
            <Text style={styles.sideActionText}>Pay now</Text>
          </RectButton>
        );
      }

      if (canConfirm) {
        return (
          <RectButton
            onPress={() =>
              navigation.navigate(SCREENS.LoanDetail, {
                iouId: item.iou_id,
                direction: 'in',
              })
            }
            style={styles.rightActionConfirm}
          >
            <Text style={styles.sideActionText}>Confirm</Text>
          </RectButton>
        );
      }

      if (canRemind) {
        return (
          <RectButton
            onPress={() => {
              void sendReminder(item);
            }}
            style={styles.rightActionRemind}
          >
            <Text style={styles.sideActionText}>Remind</Text>
          </RectButton>
        );
      }

      return <View />;
    };

    return (
      <Swipeable
        renderRightActions={rightActions}
        renderLeftActions={leftActions}
        overshootLeft={false}
        overshootRight={false}
      >
        <TouchableOpacity
          activeOpacity={item.paid_at || item.direction === 'in' ? 0.85 : 1}
          onPress={() => openPayment(item)}
          disabled={item.direction === 'out' && !item.paid_at}
        >
          <View
            style={[
              styles.rowCard,
              {
                backgroundColor: isToday ? '#FFFDE7' : '#fff',
              },
            ]}
          >
            <View style={styles.rowTop}>
              <Text style={styles.rowTitle}>{item.title || 'Loan'}</Text>
              <Text style={styles.rowAmount}>{currency(item.amount_cents)}</Text>
            </View>

            <View style={styles.rowMetaWrap}>
              <Text style={styles.rowDueText}>
                Due {new Date(item.scheduled_at).toLocaleDateString()}
              </Text>

              <View style={[styles.badge, { backgroundColor: badgeColor }]}>
                <Text style={styles.badgeText}>{badge.toUpperCase()}</Text>
              </View>

              <View style={[styles.badge, { backgroundColor: dirBg }]}>
                <Text style={[styles.badgeTextDark, { color: dirColor }]}>
                  {item.direction === 'in' ? 'Incoming' : 'Outgoing'}
                </Text>
              </View>

              <View
                style={[
                  styles.badge,
                  { backgroundColor: paymentStatusBgFor(item.payment_status) },
                ]}
              >
                <Text style={styles.badgeTextDark}>
                  {item.payment_status === 'pending_confirmation'
                    ? 'PENDING'
                    : item.payment_status.toUpperCase()}
                </Text>
              </View>
            </View>

            <View style={styles.progressSection}>
              <View style={styles.progressHeaderRow}>
                <Text style={styles.progressLabel}>Progress</Text>
                <Text style={styles.progressValue}>{progressPercent}%</Text>
              </View>
              <View style={styles.progressTrack}>
                <View
                  style={[
                    styles.progressFill,
                    { width: `${Math.max(0, Math.min(100, progressPercent))}%` },
                  ]}
                />
              </View>
              <Text style={styles.progressSubtext}>{getProgressLabel(item)}</Text>
            </View>

            {!item.paid_at && item.direction === 'out' && (
              <Text style={styles.swipeHintText}>
                ← Full loan info   •   Swipe   •   Pay now →
              </Text>
            )}

            {!item.paid_at &&
              item.direction === 'in' &&
              item.payment_status !== 'pending_confirmation' && (
                <Text style={styles.incomingHintText}>
                  Tap to manage incoming payment
                </Text>
              )}

            {!item.paid_at &&
              item.direction === 'in' &&
              item.payment_status === 'pending_confirmation' && (
                <Text style={styles.incomingHintText}>
                  Tap or swipe to confirm incoming payment
                </Text>
              )}
          </View>
        </TouchableOpacity>
      </Swipeable>
    );
  });

  return (
    <View style={{ flex: 1, backgroundColor: '#f7f7f7' }}>
      {firstLoad && loading ? (
        <View style={styles.centered}>
          <ActivityIndicator />
        </View>
      ) : (
        <FlatList
          data={activeData}
          keyExtractor={(i) => i.id}
          renderItem={({ item }) => <Row item={item} />}
          ListHeaderComponent={<HeaderContent />}
          refreshControl={
            <RefreshControl refreshing={loading} onRefresh={fetchUpcoming} />
          }
          contentContainerStyle={styles.listContent}
          ItemSeparatorComponent={() => <View style={{ height: 10 }} />}
          ListEmptyComponent={
            !loading ? (
              <View style={styles.emptyWrap}>
                <Text style={styles.emptyText}>
                  {showList === 'in'
                    ? 'No incoming payments in the next 14 days.'
                    : 'No outgoing payments in the next 14 days.'}
                </Text>
              </View>
            ) : null
          }
          showsVerticalScrollIndicator={false}
        />
      )}

      <TouchableOpacity
        activeOpacity={0.9}
        onPress={() => navigation.navigate(SCREENS.NewLoan)}
        style={styles.fab}
      >
        <Text style={styles.fabText}>+ New IOU</Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  centered: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
  },

  listContent: {
    paddingBottom: 120,
    paddingTop: 0,
  },

  verifyBanner: {
    margin: 12,
    marginBottom: 0,
    padding: 12,
    borderRadius: 10,
    backgroundColor: '#FFF3E0',
    borderWidth: 1,
    borderColor: '#FFCC80',
  },
  verifyTitle: {
    fontWeight: '800',
    marginBottom: 4,
  },
  verifyText: {
    opacity: 0.8,
  },

  topSection: {
    backgroundColor: '#fff',
    paddingBottom: 8,
    borderBottomWidth: 1,
    borderBottomColor: 'rgba(0,0,0,0.06)',
  },

  scoreHero: {
    marginHorizontal: 12,
    marginTop: 12,
    backgroundColor: '#F2FAF2',
    borderWidth: 1,
    borderColor: '#D7EBD7',
    borderRadius: 18,
    padding: 16,
  },
  scoreHeroTop: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    justifyContent: 'space-between',
    gap: 12,
  },
  scoreHeroCopy: {
    flex: 1,
  },
  scoreHeroEyebrow: {
    fontSize: 13,
    fontWeight: '800',
    color: IOU_GREEN_DARK,
    textTransform: 'uppercase',
    letterSpacing: 0.5,
  },
  scoreHeroValue: {
    marginTop: 4,
    fontSize: 48,
    lineHeight: 54,
    fontWeight: '900',
    color: IOU_GREEN_DARK,
  },
  scoreHeroSubtext: {
    marginTop: 6,
    fontSize: 14,
    fontWeight: '700',
    color: '#4B5B4B',
  },
  scoreTierPill: {
    backgroundColor: '#DFF0DF',
    borderRadius: 999,
    paddingHorizontal: 12,
    paddingVertical: 8,
    alignSelf: 'flex-start',
  },
  scoreTierText: {
    color: IOU_GREEN_DARK,
    fontWeight: '800',
    fontSize: 13,
  },
  scoreMetricsRow: {
    flexDirection: 'row',
    gap: 10,
    marginTop: 14,
  },
  scoreMetricPill: {
    flex: 1,
    backgroundColor: '#FFFFFF',
    borderRadius: 12,
    paddingHorizontal: 12,
    paddingVertical: 10,
    borderWidth: 1,
    borderColor: '#DDEBDD',
  },
  scoreMetricLabel: {
    fontSize: 11,
    fontWeight: '800',
    color: '#6A7A6A',
    textTransform: 'uppercase',
    marginBottom: 4,
  },
  scoreMetricValue: {
    fontSize: 20,
    fontWeight: '900',
    color: IOU_GREEN_DARK,
  },
  scoreMetricValueGood: {
    color: IOU_GREEN_DARK,
  },
  scoreMetricValuePending: {
    color: '#B45309',
  },
  scoreMovementCard: {
    marginTop: 12,
    backgroundColor: '#FFFFFF',
    borderRadius: 12,
    paddingHorizontal: 12,
    paddingVertical: 10,
    borderWidth: 1,
    borderColor: '#DDEBDD',
  },
  scoreMovementLabel: {
    fontSize: 11,
    fontWeight: '800',
    color: '#6A7A6A',
    textTransform: 'uppercase',
    marginBottom: 4,
  },
  scoreMovementValue: {
    fontSize: 14,
    fontWeight: '800',
    color: '#2F3E2F',
    lineHeight: 20,
  },
  scoreMovementSubvalue: {
    marginTop: 4,
    fontSize: 12,
    fontWeight: '700',
    color: '#667085',
  },
  scoreActivityStrip: {
    marginTop: 12,
    backgroundColor: '#FFFFFF',
    borderRadius: 12,
    paddingHorizontal: 12,
    paddingVertical: 10,
    borderWidth: 1,
    borderColor: '#DDEBDD',
  },
  scoreActivityLabel: {
    fontSize: 11,
    fontWeight: '800',
    color: '#6A7A6A',
    textTransform: 'uppercase',
    marginBottom: 4,
  },
  scoreActivityValue: {
    fontSize: 14,
    fontWeight: '800',
    color: '#2F3E2F',
  },

  statRow: {
    flexDirection: 'row',
    paddingHorizontal: 12,
    paddingTop: 10,
    paddingBottom: 4,
    backgroundColor: '#fff',
  },
  statCard: {
    flex: 1,
    padding: 12,
    borderRadius: 12,
    borderWidth: 2,
    minHeight: 92,
  },
  statCardActive: {
    shadowColor: '#000',
    shadowOpacity: 0.08,
    shadowRadius: 6,
    shadowOffset: { width: 0, height: 2 },
    elevation: 2,
  },
  statLabel: {
    fontSize: 12,
    opacity: 0.72,
    fontWeight: '700',
    color: '#334155',
  },
  statLabelActive: {
    opacity: 1,
    color: '#111827',
  },
  statValue: {
    marginTop: 4,
    fontSize: 17,
    fontWeight: '900',
    color: '#111',
  },
  statValueActive: {
    color: '#111',
  },
  statMeta: {
    marginTop: 6,
    opacity: 0.8,
    fontWeight: '600',
    color: '#475569',
  },
  statMetaActive: {
    opacity: 1,
    color: '#334155',
  },

  summaryStrip: {
    paddingHorizontal: 12,
    paddingVertical: 10,
    backgroundColor: '#fff',
    borderBottomWidth: 1,
    borderBottomColor: 'rgba(0,0,0,0.06)',
  },
  summaryStripText: {
    color: '#666',
    fontSize: 13,
    fontWeight: '700',
  },

  headerNextUpWrap: {
    paddingHorizontal: 12,
    paddingTop: 12,
  },

  nextCard: {
    backgroundColor: '#fff',
    borderRadius: 14,
    padding: 14,
    borderWidth: 1,
    borderColor: '#ECECEC',
  },
  nextHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  nextEyebrow: {
    fontSize: 12,
    fontWeight: '700',
    color: '#666',
    textTransform: 'uppercase',
  },
  nextTitle: {
    marginTop: 10,
    fontSize: 18,
    fontWeight: '800',
    color: '#111',
  },
  nextMetaRow: {
    marginTop: 8,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  nextAmount: {
    fontSize: 20,
    fontWeight: '800',
    color: IOU_GREEN,
  },
  nextDate: {
    color: '#666',
    fontWeight: '600',
  },

  progressSection: {
    marginTop: 10,
  },
  progressHeaderRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  progressLabel: {
    fontSize: 12,
    fontWeight: '800',
    color: '#444',
    textTransform: 'uppercase',
  },
  progressValue: {
    fontSize: 12,
    fontWeight: '800',
    color: IOU_GREEN,
  },
  progressTrack: {
    marginTop: 6,
    height: 8,
    borderRadius: 999,
    backgroundColor: '#EAEAEA',
    overflow: 'hidden',
  },
  progressFill: {
    height: '100%',
    borderRadius: 999,
    backgroundColor: IOU_GREEN,
  },
  progressSubtext: {
    marginTop: 6,
    color: '#666',
    fontSize: 12,
    fontWeight: '700',
  },

  nextActionsRow: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 8,
    marginTop: 14,
  },
  nextActionBtn: {
    borderRadius: 10,
    paddingHorizontal: 14,
    paddingVertical: 10,
  },
  nextActionGreen: {
    backgroundColor: IOU_GREEN,
  },
  nextActionBlue: {
    backgroundColor: BLUE,
  },
  nextActionOrange: {
    backgroundColor: ORANGE,
  },
  nextActionConfirm: {
    backgroundColor: BLUE,
  },
  nextActionNeutral: {
    backgroundColor: '#EEF2F5',
  },
  nextActionText: {
    color: '#fff',
    fontWeight: '800',
    fontSize: 14,
  },
  nextActionTextDark: {
    color: '#222',
  },

  errorBanner: {
    margin: 12,
    padding: 12,
    borderRadius: 10,
    backgroundColor: '#FFEBEE',
    borderWidth: 1,
    borderColor: '#F8BBD0',
  },
  errorTitle: {
    color: '#C62828',
    fontWeight: '700',
  },
  errorText: {
    color: '#C62828',
    marginTop: 4,
    opacity: 0.8,
  },

  rowCard: {
    marginHorizontal: 12,
    paddingVertical: 12,
    paddingHorizontal: 14,
    borderRadius: 12,
    borderWidth: 1,
    borderColor: 'rgba(0,0,0,0.05)',
  },
  rowTop: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  rowTitle: {
    fontSize: 16,
    fontWeight: '700',
    flex: 1,
    paddingRight: 12,
  },
  rowAmount: {
    fontSize: 16,
    fontWeight: '800',
  },
  rowMetaWrap: {
    marginTop: 6,
    flexDirection: 'row',
    alignItems: 'center',
    flexWrap: 'wrap',
    gap: 6,
  },
  rowDueText: {
    opacity: 0.7,
  },

  swipeHintText: {
    marginTop: 8,
    fontSize: 11,
    fontWeight: '700',
    color: '#8A8A8A',
  },
  incomingHintText: {
    marginTop: 8,
    fontSize: 11,
    fontWeight: '700',
    color: '#8A8A8A',
  },

  badge: {
    paddingHorizontal: 8,
    paddingVertical: 3,
    borderRadius: 999,
    marginTop: 4,
  },
  badgeText: {
    color: '#fff',
    fontSize: 12,
    fontWeight: '800',
  },
  badgeTextDark: {
    fontSize: 12,
    fontWeight: '700',
    color: '#222',
  },

  leftAction: {
    width: 150,
    marginVertical: 2,
    marginLeft: 8,
    borderRadius: 12,
    backgroundColor: BLUE,
    justifyContent: 'center',
    alignItems: 'center',
  },
  rightActionPay: {
    width: 150,
    marginVertical: 2,
    marginRight: 8,
    borderRadius: 12,
    backgroundColor: IOU_GREEN,
    justifyContent: 'center',
    alignItems: 'center',
  },
  rightActionRemind: {
    width: 150,
    marginVertical: 2,
    marginRight: 8,
    borderRadius: 12,
    backgroundColor: ORANGE,
    justifyContent: 'center',
    alignItems: 'center',
  },
  rightActionConfirm: {
    width: 150,
    marginVertical: 2,
    marginRight: 8,
    borderRadius: 12,
    backgroundColor: BLUE,
    justifyContent: 'center',
    alignItems: 'center',
  },
  sideActionText: {
    fontWeight: '800',
    color: '#fff',
    fontSize: 16,
  },

  emptyWrap: {
    padding: 20,
    alignItems: 'center',
  },
  emptyText: {
    opacity: 0.6,
  },

  fab: {
    position: 'absolute',
    right: 20,
    bottom: 24,
    backgroundColor: IOU_GREEN,
    borderRadius: 28,
    paddingHorizontal: 18,
    height: 56,
    alignItems: 'center',
    justifyContent: 'center',
    shadowColor: '#000',
    shadowOpacity: 0.2,
    shadowRadius: 6,
    shadowOffset: { width: 0, height: 3 },
    elevation: 6,
  },
  fabText: {
    color: '#fff',
    fontSize: 18,
    fontWeight: '800',
  },
});9